import { api } from "./api.js";
import { esc, pick, register, t } from "./i18n.js";
import { pickRandom, randInt } from "./util.js";
import { renderTools } from "./tools.js";

register({
  ru: {
    "helper.title": "Помощник за столом",
    "helper.notice": "Эту игру нельзя сыграть в браузере: ей нужны физические компоненты. Здесь собраны правила и инструменты для партии за настоящим столом.",
    "helper.back": "К каталогу",
    "helper.notFound": "Игра не найдена.",
    "helper.dice": "Кубики",
    "helper.diceCount": "Сколько кубиков",
    "helper.diceSides": "Граней",
    "helper.roll": "Бросить",
    "helper.sum": "Сумма: {n}",
    "helper.coin": "Монетка",
    "helper.flip": "Подбросить",
    "helper.heads": "Орёл",
    "helper.tails": "Решка",
    "helper.first": "Кто ходит первым",
    "helper.firstPlayers": "Игроков",
    "helper.firstGo": "Выбрать",
    "helper.firstResult": "Первым ходит игрок {n}",
    "helper.order": "Порядок хода: {list}",
    "helper.shuffle": "Случайный порядок",
  },
  en: {
    "helper.title": "Tabletop assistant",
    "helper.notice": "This game can't be played in the browser: it needs physical components. Here are the rules and tools for playing at a real table.",
    "helper.back": "Back to catalogue",
    "helper.notFound": "Game not found.",
    "helper.dice": "Dice",
    "helper.diceCount": "How many dice",
    "helper.diceSides": "Sides",
    "helper.roll": "Roll",
    "helper.sum": "Total: {n}",
    "helper.coin": "Coin",
    "helper.flip": "Flip",
    "helper.heads": "Heads",
    "helper.tails": "Tails",
    "helper.first": "Who goes first",
    "helper.firstPlayers": "Players",
    "helper.firstGo": "Pick",
    "helper.firstResult": "Player {n} goes first",
    "helper.order": "Turn order: {list}",
    "helper.shuffle": "Random order",
  },
});

function shuffledOrder(count) {
  const order = Array.from({ length: count }, (_, i) => i + 1);
  for (let i = order.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order;
}

function panelsHtml(game) {
  const defaultPlayers = Math.min(game.players_max, Math.max(game.players_min, 2));
  return `
    <div class="tools-grid">
      <section class="panel">
        <h2>${esc(t("helper.dice"))}</h2>
        <div class="form-row">
          <label class="field"><span>${esc(t("helper.diceCount"))}</span><input type="number" id="dice-count" min="1" max="10" value="2"></label>
          <label class="field"><span>${esc(t("helper.diceSides"))}</span>
            <select id="dice-sides">${[4, 6, 8, 10, 12, 20].map((n) => `<option value="${n}"${n === 6 ? " selected" : ""}>d${n}</option>`).join("")}</select>
          </label>
        </div>
        <div class="dice-result" id="dice-result" aria-live="polite">–</div>
        <p class="muted" id="dice-sum"></p>
        <button class="btn primary" id="dice-roll">${esc(t("helper.roll"))}</button>
      </section>
      <section class="panel">
        <h2>${esc(t("helper.first"))}</h2>
        <label class="field"><span>${esc(t("helper.firstPlayers"))}</span><input type="number" id="first-count" min="2" max="12" value="${defaultPlayers}"></label>
        <div class="dice-result" id="first-result" aria-live="polite">–</div>
        <p class="muted" id="first-order"></p>
        <div class="dialog-actions">
          <button class="btn primary" id="first-go">${esc(t("helper.firstGo"))}</button>
          <button class="btn" id="first-shuffle">${esc(t("helper.shuffle"))}</button>
        </div>
        <h2 class="spaced">${esc(t("helper.coin"))}</h2>
        <div class="dice-result" id="coin-result" aria-live="polite">–</div>
        <button class="btn primary" id="coin-flip">${esc(t("helper.flip"))}</button>
      </section>
    </div>
    <div id="helper-tools"></div>`;
}

function bind(root) {
  root.querySelector("#dice-roll").addEventListener("click", () => {
    const count = Math.min(10, Math.max(1, Number(root.querySelector("#dice-count").value) || 1));
    const sides = Number(root.querySelector("#dice-sides").value);
    const rolls = Array.from({ length: count }, () => 1 + randInt(sides));
    root.querySelector("#dice-result").textContent = rolls.join("  ");
    root.querySelector("#dice-sum").textContent = count > 1 ? t("helper.sum", { n: rolls.reduce((a, b) => a + b, 0) }) : "";
  });
  const readCount = () => Math.min(12, Math.max(2, Number(root.querySelector("#first-count").value) || 2));
  root.querySelector("#first-go").addEventListener("click", () => {
    root.querySelector("#first-result").textContent = t("helper.firstResult", { n: 1 + randInt(readCount()) });
    root.querySelector("#first-order").textContent = "";
  });
  root.querySelector("#first-shuffle").addEventListener("click", () => {
    const order = shuffledOrder(readCount());
    root.querySelector("#first-result").textContent = t("helper.firstResult", { n: order[0] });
    root.querySelector("#first-order").textContent = t("helper.order", { list: order.join(" → ") });
  });
  root.querySelector("#coin-flip").addEventListener("click", () => {
    root.querySelector("#coin-result").textContent = pickRandom([t("helper.heads"), t("helper.tails")]);
  });
}

export async function renderHelper(container, id) {
  container.innerHTML = "";
  let game;
  try {
    game = await api.get(id);
  } catch {
    container.innerHTML = `<p class="empty">${esc(t("helper.notFound"))}</p><p><a class="btn" href="#/">${esc(t("helper.back"))}</a></p>`;
    return;
  }
  const players = game.players_min === game.players_max ? `${game.players_min}` : `${game.players_min}–${game.players_max}`;
  container.innerHTML = `
    <div class="page-head">
      <div>
        <h1>${esc(pick(game, "name"))}</h1>
        <p class="muted">${esc(t("helper.title"))} · ${esc(t("card.players", { min: game.players_min, max: game.players_max }).replace(`${game.players_min}–${game.players_max}`, players))} · ${esc(t("card.time", { n: game.time_min }))} · ${esc(t("card.age", { n: game.age }))}</p>
      </div>
      <a class="btn" href="#/">${esc(t("helper.back"))}</a>
    </div>
    <p class="notice">${esc(t("helper.notice"))}</p>
    <div class="panel">
      <h4>${esc(t("detail.description"))}</h4>
      <p>${esc(pick(game, "description")) || "—"}</p>
      <h4>${esc(t("detail.rules"))}</h4>
      <p>${esc(pick(game, "rules")) || "—"}</p>
    </div>
    ${panelsHtml(game)}`;
  bind(container);
  renderTools(container.querySelector("#helper-tools"), true);
}
