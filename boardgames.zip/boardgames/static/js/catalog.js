import { api } from "./api.js";
import { esc, getLang, pick, t } from "./i18n.js";

const GENRES = ["abstract", "strategy", "family", "party", "cooperative", "economic", "detective", "word"];
const PLAYER_OPTIONS = [1, 2, 3, 4, 5, 6, 8, 10];
const TIME_OPTIONS = [15, 30, 60, 120];
const SORTS = ["name", "rating", "time", "players"];

const DEFAULT_FILTERS = { q: "", genre: "", players: "", max_time: "", favorites: false, playable: false, sort: "name" };
const filters = { ...DEFAULT_FILTERS };

let games = [];
let root = null;
let searchTimer = null;
let loadId = 0;

const detailDialog = () => document.getElementById("detail-dialog");
const formDialog = () => document.getElementById("form-dialog");

function option(value, label, selected) {
  return `<option value="${esc(value)}"${String(selected) === String(value) ? " selected" : ""}>${esc(label)}</option>`;
}

function stars(game) {
  return [1, 2, 3, 4, 5]
    .map((n) => `<button class="star${n <= game.rating ? " on" : ""}" data-star="${n}" aria-label="${esc(t("card.rate", { n }))}">★</button>`)
    .join("");
}

function metaItems(game) {
  const players = game.players_min === game.players_max
    ? t("card.playersSame", { n: game.players_min })
    : t("card.players", { min: game.players_min, max: game.players_max });
  return [players, t("card.time", { n: game.time_min }), t("card.age", { n: game.age })]
    .map((text) => `<li>${esc(text)}</li>`)
    .join("");
}

function cardHtml(game) {
  const favoriteLabel = game.favorite ? t("card.unfavorite") : t("card.favorite");
  const playButton = game.playable
    ? `<button class="btn small primary" data-play="${esc(game.playable)}">${esc(t("card.play"))}</button>`
    : `<button class="btn small" data-helper="${game.id}">${esc(t("card.helper"))}</button>`;
  return `
    <article class="card genre-${esc(game.genre)}" data-id="${game.id}" tabindex="0">
      <div class="card-art" aria-hidden="true">
        <span class="glyph">${esc(initial(game))}</span>
        <span class="genre">${esc(t("genre." + game.genre))}</span>
      </div>
      <div class="card-body">
        <div class="card-top">
          <h3>${esc(pick(game, "name"))}</h3>
          <button class="fav${game.favorite ? " on" : ""}" data-action="favorite" aria-label="${esc(favoriteLabel)}" title="${esc(favoriteLabel)}">${game.favorite ? "♥" : "♡"}</button>
        </div>
        <p class="desc">${esc(pick(game, "description"))}</p>
        <ul class="meta">${metaItems(game)}</ul>
        <div class="card-bottom">
          <div class="stars">${stars(game)}</div>
          ${playButton}
        </div>
      </div>
    </article>`;
}

function initial(game) {
  return (pick(game, "name") || "?").trim().charAt(0).toUpperCase();
}

function toolbarHtml() {
  const genreOptions = [option("", t("catalog.allGenres"), filters.genre)]
    .concat(GENRES.map((genre) => option(genre, t("genre." + genre), filters.genre)))
    .join("");
  const playerOptions = [option("", t("catalog.anyPlayers"), filters.players)]
    .concat(PLAYER_OPTIONS.map((n) => option(n, t("catalog.players.n", { n }), filters.players)))
    .join("");
  const timeOptions = [option("", t("catalog.anyTime"), filters.max_time)]
    .concat(TIME_OPTIONS.map((n) => option(n, t("catalog.time.n", { n }), filters.max_time)))
    .join("");
  const sortOptions = SORTS.map((sort) => option(sort, t("catalog.sort." + sort), filters.sort)).join("");

  return `
    <div class="page-head">
      <h1>${esc(t("catalog.title"))}</h1>
      <button class="btn primary" id="add-game">+ ${esc(t("catalog.add"))}</button>
    </div>
    <form class="toolbar" id="filters" autocomplete="off">
      <input type="search" name="q" value="${esc(filters.q)}" placeholder="${esc(t("catalog.search"))}" aria-label="${esc(t("catalog.search"))}">
      <select name="genre" aria-label="${esc(t("form.genre"))}">${genreOptions}</select>
      <select name="players" aria-label="${esc(t("catalog.players"))}">${playerOptions}</select>
      <select name="max_time" aria-label="${esc(t("form.time"))}">${timeOptions}</select>
      <select name="sort">${sortOptions}</select>
      <div class="checks">
        <label class="check"><input type="checkbox" name="favorites"${filters.favorites ? " checked" : ""}> ${esc(t("catalog.favorites"))}</label>
        <label class="check"><input type="checkbox" name="playable"${filters.playable ? " checked" : ""}> ${esc(t("catalog.playable"))}</label>
      </div>
    </form>
    <div class="result-line"><span id="found"></span><button class="link" id="reset-filters" type="button">${esc(t("catalog.reset"))}</button></div>
    <div class="grid" id="grid"></div>`;
}

function renderGrid() {
  root.querySelector("#found").textContent = t("catalog.found", { n: games.length });
  const grid = root.querySelector("#grid");
  grid.innerHTML = games.length
    ? games.map(cardHtml).join("")
    : `<p class="empty">${esc(t("catalog.empty"))}</p>`;
}

async function load() {
  const requestId = ++loadId;
  let result;
  try {
    result = await api.list({ ...filters, lang: getLang() });
  } catch {
    toast(t("error.generic"));
    return;
  }
  if (requestId !== loadId || !root.querySelector("#grid")) return;
  games = result;
  renderGrid();
}

export function toast(message) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove("show"), 3500);
}

function readFilters(form) {
  const data = new FormData(form);
  filters.q = data.get("q").trim();
  filters.genre = data.get("genre");
  filters.players = data.get("players");
  filters.max_time = data.get("max_time");
  filters.sort = data.get("sort");
  filters.favorites = data.has("favorites");
  filters.playable = data.has("playable");
}

function findGame(id) {
  return games.find((game) => game.id === Number(id));
}

function openDetail(game) {
  const dialog = detailDialog();
  const playButton = game.playable
    ? `<button class="btn primary" data-play="${esc(game.playable)}">${esc(t("card.play"))}</button>`
    : `<button class="btn primary" data-helper="${game.id}">${esc(t("card.helper"))}</button>`;
  const rules = pick(game, "rules");
  dialog.innerHTML = `
    <div class="dialog-body">
      <div class="card-top">
        <span class="genre genre-${esc(game.genre)}">${esc(t("genre." + game.genre))}</span>
        <div class="stars">${stars(game)}</div>
      </div>
      <h2>${esc(pick(game, "name"))}</h2>
      <ul class="meta">${metaItems(game)}</ul>
      <h4>${esc(t("detail.description"))}</h4>
      <p>${esc(pick(game, "description")) || "—"}</p>
      <h4>${esc(t("detail.rules"))}</h4>
      <p>${esc(rules) || "—"}</p>
      <div class="dialog-actions">
        ${playButton}
        <button class="btn" data-detail="edit">${esc(t("detail.edit"))}</button>
        <button class="btn danger" data-detail="delete">${esc(t("detail.delete"))}</button>
        <button class="btn ghost" data-detail="close">${esc(t("detail.close"))}</button>
      </div>
    </div>`;
  dialog.dataset.id = game.id;
  if (!dialog.open) dialog.showModal();
}

function field(name, label, value, tag = "input", extra = "") {
  const control = tag === "textarea"
    ? `<textarea name="${name}" rows="3">${esc(value)}</textarea>`
    : `<input name="${name}" value="${esc(value)}" ${extra}>`;
  return `<label class="field"><span>${esc(label)}</span>${control}</label>`;
}

function openForm(game) {
  const data = game || { name_ru: "", name_en: "", description_ru: "", description_en: "", rules_ru: "", rules_en: "", genre: "family", players_min: 2, players_max: 4, time_min: 30, age: 8 };
  const genreOptions = GENRES.map((genre) => option(genre, t("genre." + genre), data.genre)).join("");
  const dialog = formDialog();
  dialog.innerHTML = `
    <form class="dialog-body" id="game-form" method="dialog">
      <h2>${esc(game ? t("form.editTitle") : t("form.addTitle"))}</h2>
      <div class="form-grid">
        ${field("name_ru", t("form.nameRu"), data.name_ru)}
        ${field("name_en", t("form.nameEn"), data.name_en)}
        ${field("description_ru", t("form.descRu"), data.description_ru, "textarea")}
        ${field("description_en", t("form.descEn"), data.description_en, "textarea")}
        ${field("rules_ru", t("form.rulesRu"), data.rules_ru, "textarea")}
        ${field("rules_en", t("form.rulesEn"), data.rules_en, "textarea")}
      </div>
      <div class="form-row">
        <label class="field"><span>${esc(t("form.genre"))}</span><select name="genre">${genreOptions}</select></label>
        ${field("players_min", t("form.playersMin"), data.players_min, "input", 'type="number" min="1" max="99"')}
        ${field("players_max", t("form.playersMax"), data.players_max, "input", 'type="number" min="1" max="99"')}
        ${field("time_min", t("form.time"), data.time_min, "input", 'type="number" min="1" max="9999"')}
        ${field("age", t("form.age"), data.age, "input", 'type="number" min="0" max="99"')}
      </div>
      <p class="form-error" id="form-error" role="alert"></p>
      <div class="dialog-actions">
        <button class="btn primary" type="submit">${esc(t("form.save"))}</button>
        <button class="btn ghost" type="button" data-form="cancel">${esc(t("form.cancel"))}</button>
      </div>
    </form>`;
  dialog.dataset.id = game ? game.id : "";
  dialog.showModal();
}

async function submitForm(form) {
  const dialog = formDialog();
  const payload = Object.fromEntries(new FormData(form));
  try {
    if (dialog.dataset.id) await api.update(dialog.dataset.id, payload);
    else await api.create(payload);
    dialog.close();
    await load();
  } catch (error) {
    const key = "error." + error.code;
    const message = t(key) === key ? t("error.generic") : t(key);
    form.querySelector("#form-error").textContent = message;
  }
}

async function changeGame(id, changes) {
  try {
    await api.patch(id, changes);
    await load();
    return findGame(id);
  } catch {
    toast(t("error.generic"));
    return null;
  }
}

async function handleCardAction(event) {
  const target = event.target;
  const card = target.closest(".card");
  if (!card) return;
  const game = findGame(card.dataset.id);
  if (!game) return;

  const playButton = target.closest("[data-play]");
  if (playButton) {
    location.hash = "#/play/" + playButton.dataset.play;
    return;
  }
  const helperButton = target.closest("[data-helper]");
  if (helperButton) {
    location.hash = "#/helper/" + helperButton.dataset.helper;
    return;
  }
  if (target.closest("[data-action='favorite']")) {
    await changeGame(game.id, { favorite: !game.favorite });
    return;
  }
  const star = target.closest("[data-star]");
  if (star) {
    const value = Number(star.dataset.star);
    await changeGame(game.id, { rating: value === game.rating ? 0 : value });
    return;
  }
  openDetail(game);
}

async function handleDetailAction(event) {
  const dialog = detailDialog();
  const game = findGame(dialog.dataset.id);
  const target = event.target;
  if (target === dialog) {
    dialog.close();
    return;
  }
  if (!game) return;

  const playButton = target.closest("[data-play]");
  if (playButton) {
    dialog.close();
    location.hash = "#/play/" + playButton.dataset.play;
    return;
  }
  const helperButton = target.closest("[data-helper]");
  if (helperButton) {
    dialog.close();
    location.hash = "#/helper/" + helperButton.dataset.helper;
    return;
  }
  const star = target.closest("[data-star]");
  if (star) {
    const value = Number(star.dataset.star);
    const updated = await changeGame(game.id, { rating: value === game.rating ? 0 : value });
    if (updated) openDetail(updated);
    return;
  }
  const action = target.closest("[data-detail]")?.dataset.detail;
  if (action === "close") dialog.close();
  if (action === "edit") {
    dialog.close();
    openForm(game);
  }
  if (action === "delete" && confirm(t("detail.confirmDelete", { name: pick(game, "name") }))) {
    try {
      await api.remove(game.id);
      dialog.close();
      await load();
    } catch {
      toast(t("error.generic"));
    }
  }
}

function bindDialogs() {
  const detail = detailDialog();
  const form = formDialog();
  if (detail.dataset.bound) return;
  detail.dataset.bound = "1";
  detail.addEventListener("click", handleDetailAction);
  form.addEventListener("click", (event) => {
    if (event.target === form || event.target.closest("[data-form='cancel']")) form.close();
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    submitForm(event.target);
  });
}

export function renderCatalog(container) {
  root = container;
  bindDialogs();
  container.innerHTML = toolbarHtml();

  const form = container.querySelector("#filters");
  form.addEventListener("submit", (event) => event.preventDefault());
  form.addEventListener("input", (event) => {
    readFilters(form);
    clearTimeout(searchTimer);
    searchTimer = setTimeout(load, event.target.name === "q" ? 200 : 0);
  });
  container.querySelector("#reset-filters").addEventListener("click", () => {
    Object.assign(filters, DEFAULT_FILTERS);
    renderCatalog(container);
  });
  container.querySelector("#add-game").addEventListener("click", () => openForm(null));
  container.querySelector("#grid").addEventListener("click", handleCardAction);
  container.querySelector("#grid").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && event.target.classList.contains("card")) {
      const game = findGame(event.target.dataset.id);
      if (game) openDetail(game);
    }
  });
  load();
}
