import { esc, register, t } from "../i18n.js";
import { randInt, shuffle } from "../util.js";

register({
  ru: {
    "bs.intro": "Расставьте флот и потопите корабли компьютера. Попали — стреляете ещё раз.",
    "bs.shuffle": "Расставить заново",
    "bs.fight": "В бой!",
    "bs.yours": "Ваше поле",
    "bs.enemy": "Поле соперника",
    "bs.yourTurn": "Ваш ход: выберите клетку на поле соперника.",
    "bs.aiTurn": "Стреляет компьютер…",
    "bs.hit": "Попадание! Стреляйте ещё.",
    "bs.miss": "Мимо.",
    "bs.sunk": "Корабль потоплен! Стреляйте ещё.",
    "bs.aiHit": "Компьютер попал.",
    "bs.aiMiss": "Компьютер промахнулся.",
    "bs.aiSunk": "Компьютер потопил ваш корабль.",
    "bs.win": "Победа! Весь флот соперника потоплен.",
    "bs.lose": "Поражение: ваш флот потоплен.",
    "bs.again": "Новая игра",
    "bs.left": "Кораблей у соперника: {n}",
  },
  en: {
    "bs.intro": "Place your fleet and sink the computer's ships. A hit lets you shoot again.",
    "bs.shuffle": "Shuffle fleet",
    "bs.fight": "To battle!",
    "bs.yours": "Your waters",
    "bs.enemy": "Enemy waters",
    "bs.yourTurn": "Your turn: pick a cell in the enemy waters.",
    "bs.aiTurn": "The computer is firing…",
    "bs.hit": "Hit! Fire again.",
    "bs.miss": "Miss.",
    "bs.sunk": "Ship sunk! Fire again.",
    "bs.aiHit": "The computer hit a ship.",
    "bs.aiMiss": "The computer missed.",
    "bs.aiSunk": "The computer sank one of your ships.",
    "bs.win": "Victory! The whole enemy fleet is sunk.",
    "bs.lose": "Defeat: your fleet is sunk.",
    "bs.again": "New game",
    "bs.left": "Enemy ships left: {n}",
  },
});

const SIZE = 10;
const FLEET = [5, 4, 3, 3, 2];
const AI_DELAY = 550;

function placeFleet() {
  const grid = Array(SIZE * SIZE).fill(-1);
  const ships = [];
  for (const length of FLEET) {
    for (;;) {
      const horizontal = Math.random() < 0.5;
      const row = randInt(horizontal ? SIZE : SIZE - length + 1);
      const col = randInt(horizontal ? SIZE - length + 1 : SIZE);
      const cells = Array.from({ length }, (_, k) => (horizontal ? row * SIZE + col + k : (row + k) * SIZE + col));
      if (cells.some((cell) => grid[cell] !== -1)) continue;
      cells.forEach((cell) => {
        grid[cell] = ships.length;
      });
      ships.push({ cells });
      break;
    }
  }
  return { grid, ships, shots: Array(SIZE * SIZE).fill(0) };
}

function neighbors(cell) {
  const row = Math.floor(cell / SIZE);
  const col = cell % SIZE;
  return [[row - 1, col], [row + 1, col], [row, col - 1], [row, col + 1]]
    .filter(([r, c]) => r >= 0 && r < SIZE && c >= 0 && c < SIZE)
    .map(([r, c]) => r * SIZE + c);
}

function shoot(board, cell) {
  board.shots[cell] = board.grid[cell] >= 0 ? 2 : 1;
  if (board.grid[cell] < 0) return { hit: false, sunk: false };
  const ship = board.ships[board.grid[cell]];
  return { hit: true, sunk: ship.cells.every((c) => board.shots[c] === 2) };
}

function sunkCount(board) {
  return board.ships.filter((ship) => ship.cells.every((c) => board.shots[c] === 2)).length;
}

export const battleship = {
  id: "battleship",

  mount(root) {
    let player;
    let enemy;
    let phase = "place";
    let message = "";
    let aiHits = [];
    let timer = null;
    let disposed = false;

    function newGame() {
      clearTimeout(timer);
      player = placeFleet();
      enemy = placeFleet();
      aiHits = [];
      phase = "place";
      message = "";
    }

    function boardHtml(board, own) {
      const cells = [];
      for (let index = 0; index < SIZE * SIZE; index++) {
        const classes = ["bs-cell"];
        const shot = board.shots[index];
        const ship = board.grid[index] >= 0;
        if (own && ship) classes.push("ship");
        if (shot === 1) classes.push("miss");
        if (shot === 2) classes.push("hit");
        if (!own && phase === "play" && shot === 0) classes.push("playable");
        if (!own && shot === 2 && board.ships[board.grid[index]].cells.every((c) => board.shots[c] === 2)) classes.push("sunk");
        if (own && shot === 2 && board.ships[board.grid[index]].cells.every((c) => board.shots[c] === 2)) classes.push("sunk");
        const attr = own ? "" : ` data-target="${index}"`;
        cells.push(`<button class="${classes.join(" ")}"${attr}${own ? " tabindex=\"-1\"" : ""}></button>`);
      }
      return `<div class="board bs">${cells.join("")}</div>`;
    }

    function render() {
      let top = "";
      if (phase === "place") {
        top = `
          <p class="muted">${esc(t("bs.intro"))}</p>
          <div class="dialog-actions">
            <button class="btn" data-act="shuffle">${esc(t("bs.shuffle"))}</button>
            <button class="btn primary" data-act="fight">${esc(t("bs.fight"))}</button>
          </div>`;
      } else if (phase === "over") {
        top = `<div class="status finished">${esc(message)}</div><button class="btn primary" data-act="again">${esc(t("bs.again"))}</button>`;
      } else {
        top = `<div class="status">${esc(message)}</div><p class="muted">${esc(t("bs.left", { n: enemy.ships.length - sunkCount(enemy) }))}</p>`;
      }
      root.innerHTML = `
        ${top}
        <div class="bs-fields">
          <div><h4>${esc(t("bs.yours"))}</h4>${boardHtml(player, true)}</div>
          ${phase === "place" ? "" : `<div><h4>${esc(t("bs.enemy"))}</h4>${boardHtml(enemy, false)}</div>`}
        </div>`;
    }

    function chooseAiShot() {
      const free = (cell) => player.shots[cell] === 0;
      if (aiHits.length) {
        const candidates = new Set();
        const sorted = aiHits.slice().sort((a, b) => a - b);
        if (sorted.length >= 2) {
          const step = sorted[1] - sorted[0];
          for (const end of [sorted[0] - step, sorted[sorted.length - 1] + step]) {
            const adjacent = neighbors(sorted[0]).includes(end) || neighbors(sorted[sorted.length - 1]).includes(end);
            if (end >= 0 && end < SIZE * SIZE && adjacent && free(end)) candidates.add(end);
          }
        }
        if (candidates.size === 0) aiHits.forEach((hit) => neighbors(hit).filter(free).forEach((cell) => candidates.add(cell)));
        if (candidates.size) return shuffle([...candidates])[0];
      }
      const all = [];
      for (let cell = 0; cell < SIZE * SIZE; cell++) if (free(cell)) all.push(cell);
      const parity = all.filter((cell) => (Math.floor(cell / SIZE) + (cell % SIZE)) % 2 === 0);
      const pool = parity.length ? parity : all;
      return pool[randInt(pool.length)];
    }

    function aiTurn() {
      if (disposed) return;
      const cell = chooseAiShot();
      const result = shoot(player, cell);
      if (result.hit) {
        aiHits.push(cell);
        if (result.sunk) {
          const ship = player.ships[player.grid[cell]];
          aiHits = aiHits.filter((hit) => !ship.cells.includes(hit));
        }
      }
      if (sunkCount(player) === player.ships.length) {
        phase = "over";
        message = t("bs.lose");
        render();
        return;
      }
      message = result.sunk ? t("bs.aiSunk") : result.hit ? t("bs.aiHit") : t("bs.aiMiss");
      render();
      if (result.hit) timer = setTimeout(aiTurn, AI_DELAY);
      else {
        phase = "play";
        message = `${message} ${t("bs.yourTurn")}`;
        render();
      }
    }

    function fire(cell) {
      if (phase !== "play" || enemy.shots[cell] !== 0) return;
      const result = shoot(enemy, cell);
      if (sunkCount(enemy) === enemy.ships.length) {
        phase = "over";
        message = t("bs.win");
        render();
        return;
      }
      if (result.hit) {
        message = result.sunk ? t("bs.sunk") : t("bs.hit");
        render();
        return;
      }
      phase = "ai";
      message = t("bs.aiTurn");
      render();
      timer = setTimeout(aiTurn, AI_DELAY);
    }

    root.addEventListener("click", (event) => {
      const target = event.target.closest("[data-target]");
      if (target) return fire(Number(target.dataset.target));
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "shuffle") player = placeFleet();
      else if (act === "fight") {
        phase = "play";
        message = t("bs.yourTurn");
      } else if (act === "again") newGame();
      else return;
      render();
    });

    newGame();
    render();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  },
};
