const KNIGHT = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
const KING = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];
const DIAGONAL = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
const STRAIGHT = [[-1, 0], [1, 0], [0, -1], [0, 1]];
const VALUES = [0, 100, 320, 330, 500, 900, 0];
const GLYPHS = ["", "♟︎", "♞︎", "♝︎", "♜︎", "♛︎", "♚︎"];
const BACK_RANK = [4, 2, 3, 5, 6, 3, 2, 4];

const cache = new WeakMap();

function sign(player) {
  return player === 1 ? 1 : -1;
}

function onBoard(row, col) {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}

function attacked(board, square, by) {
  const row = square >> 3;
  const col = square & 7;
  const s = sign(by);
  const pawnRow = row + (by === 1 ? 1 : -1);
  for (const dc of [-1, 1]) {
    if (onBoard(pawnRow, col + dc) && board[pawnRow * 8 + col + dc] === s) return true;
  }
  for (const [dr, dc] of KNIGHT) {
    if (onBoard(row + dr, col + dc) && board[(row + dr) * 8 + col + dc] === 2 * s) return true;
  }
  for (const [dr, dc] of KING) {
    if (onBoard(row + dr, col + dc) && board[(row + dr) * 8 + col + dc] === 6 * s) return true;
  }
  for (const [dirs, first] of [[DIAGONAL, 3], [STRAIGHT, 4]]) {
    for (const [dr, dc] of dirs) {
      let r = row + dr;
      let c = col + dc;
      while (onBoard(r, c)) {
        const piece = board[r * 8 + c];
        if (piece !== 0) {
          if (piece === first * s || piece === 5 * s) return true;
          break;
        }
        r += dr;
        c += dc;
      }
    }
  }
  return false;
}

function inCheck(board, player) {
  return attacked(board, board.indexOf(6 * sign(player)), 3 - player);
}

function pseudoMoves(state) {
  const { board, turn } = state;
  const s = sign(turn);
  const list = [];
  for (let from = 0; from < 64; from++) {
    const piece = board[from];
    if (piece * s <= 0) continue;
    const type = Math.abs(piece);
    const row = from >> 3;
    const col = from & 7;
    if (type === 1) {
      const dir = turn === 1 ? -1 : 1;
      const startRow = turn === 1 ? 6 : 1;
      const lastRow = turn === 1 ? 0 : 7;
      const ahead = row + dir;
      if (board[ahead * 8 + col] === 0) {
        list.push({ from, to: ahead * 8 + col, promo: ahead === lastRow });
        if (row === startRow && board[(row + 2 * dir) * 8 + col] === 0) {
          list.push({ from, to: (row + 2 * dir) * 8 + col, double: true });
        }
      }
      for (const dc of [-1, 1]) {
        const c = col + dc;
        if (c < 0 || c > 7) continue;
        const to = ahead * 8 + c;
        if (board[to] * s < 0) list.push({ from, to, promo: ahead === lastRow });
        else if (to === state.ep) list.push({ from, to, ep: true });
      }
    } else if (type === 2 || type === 6) {
      for (const [dr, dc] of type === 2 ? KNIGHT : KING) {
        const r = row + dr;
        const c = col + dc;
        if (onBoard(r, c) && board[r * 8 + c] * s <= 0) list.push({ from, to: r * 8 + c });
      }
    } else {
      const dirs = type === 3 ? DIAGONAL : type === 4 ? STRAIGHT : [...DIAGONAL, ...STRAIGHT];
      for (const [dr, dc] of dirs) {
        let r = row + dr;
        let c = col + dc;
        while (onBoard(r, c)) {
          const target = board[r * 8 + c];
          if (target * s > 0) break;
          list.push({ from, to: r * 8 + c });
          if (target !== 0) break;
          r += dr;
          c += dc;
        }
      }
    }
  }

  const king = turn === 1 ? 60 : 4;
  const enemy = 3 - turn;
  if (board[king] === 6 * s && !attacked(board, king, enemy)) {
    const kingSide = turn === 1 ? 1 : 4;
    const queenSide = turn === 1 ? 2 : 8;
    if (
      state.castle & kingSide && board[king + 1] === 0 && board[king + 2] === 0 && board[king + 3] === 4 * s &&
      !attacked(board, king + 1, enemy) && !attacked(board, king + 2, enemy)
    ) list.push({ from: king, to: king + 2, castle: "k" });
    if (
      state.castle & queenSide && board[king - 1] === 0 && board[king - 2] === 0 && board[king - 3] === 0 &&
      board[king - 4] === 4 * s && !attacked(board, king - 1, enemy) && !attacked(board, king - 2, enemy)
    ) list.push({ from: king, to: king - 2, castle: "q" });
  }
  return list;
}

function rightsLostAt(square) {
  if (square === 60) return 3;
  if (square === 56) return 2;
  if (square === 63) return 1;
  if (square === 4) return 12;
  if (square === 0) return 8;
  if (square === 7) return 4;
  return 0;
}

function applyMove(state, move) {
  const board = state.board.slice();
  const player = state.turn;
  const piece = board[move.from];
  const captured = board[move.to] !== 0 || move.ep;
  board[move.to] = piece;
  board[move.from] = 0;
  if (move.ep) board[move.to + (player === 1 ? 8 : -8)] = 0;
  if (move.promo) board[move.to] = 5 * sign(player);
  if (move.castle === "k") {
    board[move.to - 1] = board[move.to + 1];
    board[move.to + 1] = 0;
  }
  if (move.castle === "q") {
    board[move.to + 1] = board[move.to - 2];
    board[move.to - 2] = 0;
  }
  const castle = state.castle & ~(rightsLostAt(move.from) | rightsLostAt(move.to));
  const isPawn = Math.abs(piece) === 1;
  return {
    board,
    turn: 3 - player,
    castle,
    ep: move.double ? (move.from + move.to) / 2 : -1,
    half: isPawn || captured ? 0 : state.half + 1,
    last: [move.from, move.to],
  };
}

function orderValue(state, move) {
  const target = Math.abs(state.board[move.to]);
  const mover = Math.abs(state.board[move.from]);
  return (target ? VALUES[target] * 10 - mover : 0) + (move.promo ? 800 : 0);
}

function moves(state) {
  if (cache.has(state)) return cache.get(state);
  const legal = pseudoMoves(state).filter((move) => !inCheck(applyMove(state, move).board, state.turn));
  legal.sort((a, b) => orderValue(state, b) - orderValue(state, a));
  cache.set(state, legal);
  return legal;
}

function insufficient(board) {
  const rest = board.filter((piece) => piece !== 0 && Math.abs(piece) !== 6);
  if (rest.length === 0) return true;
  return rest.length === 1 && (Math.abs(rest[0]) === 2 || Math.abs(rest[0]) === 3);
}

function result(state) {
  if (moves(state).length === 0) return inCheck(state.board, state.turn) ? 3 - state.turn : "draw";
  if (state.half >= 100 || insufficient(state.board)) return "draw";
  return null;
}

function positional(type, index, color) {
  const row = index >> 3;
  const col = index & 7;
  const rank = color === 1 ? 7 - row : row;
  const centre = 3.5 - Math.max(Math.abs(row - 3.5), Math.abs(col - 3.5));
  if (type === 1) return rank * 8 + centre * 4;
  if (type === 2) return centre * 12;
  if (type === 3) return centre * 5;
  if (type === 4) return rank === 6 ? 10 : 0;
  if (type === 5) return centre * 2;
  return -centre * 5;
}

export const chess = {
  id: "chess",
  depths: [1, 2, 3],
  names: { ru: ["Белые", "Чёрные"], en: ["White", "Black"] },

  init() {
    const board = Array(64).fill(0);
    for (let col = 0; col < 8; col++) {
      board[col] = -BACK_RANK[col];
      board[8 + col] = -1;
      board[48 + col] = 1;
      board[56 + col] = BACK_RANK[col];
    }
    return { board, turn: 1, castle: 15, ep: -1, half: 0, last: null };
  },

  moves,
  result,
  play: applyMove,

  score(state, player) {
    let total = 0;
    state.board.forEach((piece, index) => {
      if (piece === 0) return;
      const type = Math.abs(piece);
      const color = piece > 0 ? 1 : 2;
      total += sign(color) * (VALUES[type] + positional(type, index, color));
    });
    return player === 1 ? total : -total;
  },

  click(state, cell, selected) {
    const legal = moves(state);
    if (selected !== null) {
      const move = legal.find((candidate) => candidate.from === selected && candidate.to === cell);
      if (move) return { move };
    }
    return { selected: legal.some((candidate) => candidate.from === cell) ? cell : null };
  },

  stats() {
    return null;
  },

  render(state, view) {
    const legal = view.interactive ? moves(state) : [];
    const targets = view.selected === null ? [] : legal.filter((move) => move.from === view.selected).map((move) => move.to);
    const movable = view.selected === null ? legal.map((move) => move.from) : [];
    const checked = inCheck(state.board, state.turn) ? state.board.indexOf(6 * sign(state.turn)) : -1;
    const cells = [];
    for (let index = 0; index < 64; index++) {
      const row = index >> 3;
      const col = index & 7;
      const classes = ["ch-cell", (row + col) % 2 === 0 ? "light" : "dark"];
      if (state.last && state.last.includes(index)) classes.push("last");
      if (view.selected === index) classes.push("selected");
      if (targets.includes(index)) classes.push(state.board[index] !== 0 ? "capture" : "target");
      if (movable.includes(index)) classes.push("movable");
      if (checked === index) classes.push("check");
      const piece = state.board[index];
      const glyph = piece ? `<span class="ch-piece ${piece > 0 ? "p-w" : "p-b"}">${GLYPHS[Math.abs(piece)]}</span>` : "";
      const rank = col === 0 ? `<i class="coord rank">${8 - row}</i>` : "";
      const file = row === 7 ? `<i class="coord file">${"abcdefgh"[col]}</i>` : "";
      cells.push(`<button class="${classes.join(" ")}" data-cell="${index}">${glyph}${rank}${file}</button>`);
    }
    return `<div class="board ch">${cells.join("")}</div>`;
  },
};
