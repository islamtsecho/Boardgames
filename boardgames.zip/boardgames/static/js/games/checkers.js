const SIZE = 8;
const DIRECTIONS = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
const QUIET_LIMIT = 30;

const cache = new WeakMap();

function inside(row, col) {
  return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
}

function ownerOf(piece) {
  if (piece === 0) return 0;
  return piece === 1 || piece === 3 ? 1 : 2;
}

function isKing(piece) {
  return piece >= 3;
}

function promotionRow(player) {
  return player === 1 ? 0 : SIZE - 1;
}

function jumpsFrom(board, position, king, player, taken) {
  const row = Math.floor(position / SIZE);
  const col = position % SIZE;
  const options = [];
  for (const [dr, dc] of DIRECTIONS) {
    if (!king) {
      const victimRow = row + dr;
      const victimCol = col + dc;
      const landRow = row + 2 * dr;
      const landCol = col + 2 * dc;
      if (!inside(landRow, landCol)) continue;
      const victim = victimRow * SIZE + victimCol;
      const landing = landRow * SIZE + landCol;
      if (ownerOf(board[victim]) === 3 - player && !taken.includes(victim) && board[landing] === 0) {
        options.push({ victim, landings: [landing] });
      }
      continue;
    }
    let r = row + dr;
    let c = col + dc;
    while (inside(r, c) && board[r * SIZE + c] === 0) {
      r += dr;
      c += dc;
    }
    if (!inside(r, c)) continue;
    const victim = r * SIZE + c;
    if (ownerOf(board[victim]) !== 3 - player || taken.includes(victim)) continue;
    const landings = [];
    r += dr;
    c += dc;
    while (inside(r, c) && board[r * SIZE + c] === 0) {
      landings.push(r * SIZE + c);
      r += dr;
      c += dc;
    }
    if (landings.length) options.push({ victim, landings });
  }
  return options;
}

function explore(board, position, king, player, taken, path, found) {
  const options = jumpsFrom(board, position, king, player, taken);
  if (options.length === 0) {
    if (taken.length) found.push({ from: path[0], path, taken });
    return;
  }
  for (const { victim, landings } of options) {
    const nextTaken = [...taken, victim];
    const withMore = landings.filter((landing) => {
      const landedKing = king || Math.floor(landing / SIZE) === promotionRow(player);
      return jumpsFrom(board, landing, landedKing, player, nextTaken).length > 0;
    });
    for (const landing of withMore.length ? withMore : landings) {
      const landedKing = king || Math.floor(landing / SIZE) === promotionRow(player);
      explore(board, landing, landedKing, player, nextTaken, [...path, landing], found);
    }
  }
}

function captureMoves(board, from, player) {
  const work = board.slice();
  work[from] = 0;
  const found = [];
  explore(work, from, isKing(board[from]), player, [], [from], found);
  return found;
}

function quietMoves(board, from, player) {
  const row = Math.floor(from / SIZE);
  const col = from % SIZE;
  const king = isKing(board[from]);
  const forward = player === 1 ? -1 : 1;
  const result = [];
  for (const [dr, dc] of DIRECTIONS) {
    if (!king && dr !== forward) continue;
    let r = row + dr;
    let c = col + dc;
    while (inside(r, c) && board[r * SIZE + c] === 0) {
      result.push({ from, path: [from, r * SIZE + c], taken: [] });
      if (!king) break;
      r += dr;
      c += dc;
    }
  }
  return result;
}

function moves(state) {
  if (cache.has(state)) return cache.get(state);
  const own = [];
  state.board.forEach((piece, index) => {
    if (ownerOf(piece) === state.turn) own.push(index);
  });
  const captures = own.flatMap((index) => captureMoves(state.board, index, state.turn));
  const list = captures.length ? captures : own.flatMap((index) => quietMoves(state.board, index, state.turn));
  cache.set(state, list);
  return list;
}

function result(state) {
  if (state.quiet >= QUIET_LIMIT) return "draw";
  return moves(state).length === 0 ? 3 - state.turn : null;
}

function count(board, player) {
  return board.filter((piece) => ownerOf(piece) === player).length;
}

function destination(move) {
  return move.path[move.path.length - 1];
}

export const checkers = {
  id: "checkers",
  depths: [2, 4, 6],
  names: { ru: ["Белые", "Чёрные"], en: ["White", "Black"] },

  init() {
    const board = Array(SIZE * SIZE).fill(0);
    for (let row = 0; row < SIZE; row++) {
      for (let col = 0; col < SIZE; col++) {
        if ((row + col) % 2 === 0) continue;
        if (row < 3) board[row * SIZE + col] = 2;
        if (row > 4) board[row * SIZE + col] = 1;
      }
    }
    return { board, turn: 1, quiet: 0, last: null };
  },

  moves,
  result,

  play(state, move) {
    const board = state.board.slice();
    const piece = board[move.from];
    const player = state.turn;
    board[move.from] = 0;
    for (const victim of move.taken) board[victim] = 0;
    const end = destination(move);
    const promoted = !isKing(piece) && move.path.slice(1).some((cell) => Math.floor(cell / SIZE) === promotionRow(player));
    board[end] = promoted || isKing(piece) ? (player === 1 ? 3 : 4) : piece;
    const quiet = move.taken.length || !isKing(piece) ? 0 : state.quiet + 1;
    return { board, turn: 3 - player, quiet, last: end };
  },

  score(state, player) {
    let total = 0;
    state.board.forEach((piece, index) => {
      if (piece === 0) return;
      const owner = ownerOf(piece);
      const row = Math.floor(index / SIZE);
      const progress = owner === 1 ? SIZE - 1 - row : row;
      const value = isKing(piece) ? 300 : 100 + progress * 3;
      total += owner === player ? value : -value;
    });
    return total;
  },

  click(state, cell, selected) {
    const legal = moves(state);
    if (selected !== null) {
      const move = legal.find((candidate) => candidate.from === selected && destination(candidate) === cell);
      if (move) return { move };
    }
    return { selected: legal.some((candidate) => candidate.from === cell) ? cell : null };
  },

  stats(state) {
    return [count(state.board, 1), count(state.board, 2)];
  },

  render(state, view) {
    const legal = view.interactive ? moves(state) : [];
    const targets = view.selected === null ? [] : legal.filter((move) => move.from === view.selected).map(destination);
    const movable = view.selected === null ? legal.map((move) => move.from) : [];
    const cells = [];
    for (let index = 0; index < SIZE * SIZE; index++) {
      const row = Math.floor(index / SIZE);
      const col = index % SIZE;
      const dark = (row + col) % 2 === 1;
      const classes = ["ck-cell", dark ? "dark" : "light"];
      if (state.last === index) classes.push("last");
      if (view.selected === index) classes.push("selected");
      if (targets.includes(index)) classes.push("target");
      if (movable.includes(index)) classes.push("movable");
      const piece = state.board[index];
      const inner = piece ? `<span class="piece piece-${ownerOf(piece)}${isKing(piece) ? " king" : ""}"></span>` : "";
      cells.push(`<button class="${classes.join(" ")}" data-cell="${index}"${dark ? "" : " disabled"}>${inner}</button>`);
    }
    return `<div class="board ck">${cells.join("")}</div>`;
  },
};
