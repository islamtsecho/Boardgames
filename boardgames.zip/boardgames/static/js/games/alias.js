import { esc, register, t } from "../i18n.js";
import { THEME_IDS, wordsFor } from "../words.js";
import { beep, createCountdown, formatClock, shuffle } from "../util.js";

register({
  ru: {
    "alias.intro": "Команды по очереди объясняют слова, не используя однокоренные. Угаданное слово даёт очко, пропуск может отнимать очко.",
    "alias.teams": "Команд",
    "alias.seconds": "Секунд на раунд",
    "alias.target": "Играть до очков",
    "alias.theme": "Тема слов",
    "alias.theme.all": "Все темы вперемешку",
    "alias.penalty": "Штраф за пропуск (−1)",
    "alias.start": "Начать игру",
    "alias.team": "Команда {n}",
    "alias.turn": "Объясняет: {name}",
    "alias.ready": "Один игрок объясняет слова, остальные угадывают. Нажмите, когда будете готовы.",
    "alias.go": "Начать раунд",
    "alias.guessed": "Угадали",
    "alias.skip": "Пропуск",
    "alias.roundOver": "Раунд окончен: {name}",
    "alias.delta": "Очков за раунд: {n}",
    "alias.next": "Дальше",
    "alias.winner": "Победила команда: {name}",
    "alias.again": "Новая игра",
    "alias.score": "Счёт",
    "alias.noWords": "Слов за раунд не было.",
  },
  en: {
    "alias.intro": "Teams take turns explaining words without using related words. A guessed word scores a point; a skip may cost one.",
    "alias.teams": "Teams",
    "alias.seconds": "Seconds per round",
    "alias.target": "Play to points",
    "alias.theme": "Word theme",
    "alias.theme.all": "All themes mixed",
    "alias.penalty": "Skip penalty (−1)",
    "alias.start": "Start game",
    "alias.team": "Team {n}",
    "alias.turn": "Explaining: {name}",
    "alias.ready": "One player explains the words, the others guess. Press when you are ready.",
    "alias.go": "Start round",
    "alias.guessed": "Guessed",
    "alias.skip": "Skip",
    "alias.roundOver": "Round over: {name}",
    "alias.delta": "Points this round: {n}",
    "alias.next": "Next",
    "alias.winner": "Winning team: {name}",
    "alias.again": "New game",
    "alias.score": "Score",
    "alias.noWords": "No words this round.",
  },
});

const DEFAULTS = { teams: 2, seconds: 60, target: 20, theme: "all", penalty: true };

export const alias = {
  id: "alias",

  mount(root) {
    let settings = { ...DEFAULTS };
    let phase = "setup";
    let teams = [];
    let turn = 0;
    let played = 0;
    let deck = [];
    let log = [];
    let word = "";
    let clock = null;
    let clockText = "";

    const teamName = (index) => t("alias.team", { n: index + 1 });

    function stopClock() {
      if (clock) clock.stop();
      clock = null;
    }

    function nextWord() {
      if (deck.length === 0) deck = shuffle(wordsFor(settings.theme));
      word = deck.pop();
    }

    function scoreHtml() {
      return `<div class="scoreboard">${teams
        .map((team, index) => `<div class="player${phase !== "setup" && index === turn ? " active" : ""}">${esc(teamName(index))}<strong>${team.score}</strong></div>`)
        .join("")}</div>`;
    }

    function setupHtml() {
      const themes = [["all", t("alias.theme.all")], ...THEME_IDS.map((id) => [id, t("theme." + id)])]
        .map(([id, label]) => `<option value="${id}"${settings.theme === id ? " selected" : ""}>${esc(label)}</option>`)
        .join("");
      return `
        <form class="panel setup" id="alias-form">
          <p class="muted">${esc(t("alias.intro"))}</p>
          <div class="form-row">
            <label class="field"><span>${esc(t("alias.teams"))}</span><input type="number" name="teams" min="2" max="4" value="${settings.teams}"></label>
            <label class="field"><span>${esc(t("alias.seconds"))}</span><input type="number" name="seconds" min="15" max="180" step="5" value="${settings.seconds}"></label>
            <label class="field"><span>${esc(t("alias.target"))}</span><input type="number" name="target" min="5" max="100" step="5" value="${settings.target}"></label>
          </div>
          <label class="field"><span>${esc(t("alias.theme"))}</span><select name="theme">${themes}</select></label>
          <label class="check"><input type="checkbox" name="penalty"${settings.penalty ? " checked" : ""}> ${esc(t("alias.penalty"))}</label>
          <button class="btn primary" type="submit">${esc(t("alias.start"))}</button>
        </form>`;
    }

    function readyHtml() {
      return `
        ${scoreHtml()}
        <div class="panel center">
          <h2>${esc(t("alias.turn", { name: teamName(turn) }))}</h2>
          <p class="muted">${esc(t("alias.ready"))}</p>
          <button class="btn primary big" data-act="go">${esc(t("alias.go"))}</button>
        </div>`;
    }

    function roundHtml() {
      return `
        ${scoreHtml()}
        <div class="panel center">
          <div class="timer-display" id="alias-clock">${esc(clockText)}</div>
          <div class="role-card word">${esc(word)}</div>
          <div class="dialog-actions center-actions">
            <button class="btn primary big" data-act="ok">${esc(t("alias.guessed"))}</button>
            <button class="btn big" data-act="skip">${esc(t("alias.skip"))}</button>
          </div>
        </div>`;
    }

    function delta() {
      return log.reduce((sum, entry) => sum + entry.points, 0);
    }

    function summaryHtml() {
      const rows = log.length
        ? log.map((entry) => `<li class="${entry.points > 0 ? "good" : entry.points < 0 ? "bad" : ""}">${esc(entry.word)} <span>${entry.points > 0 ? "+1" : entry.points < 0 ? "−1" : "0"}</span></li>`).join("")
        : `<li>${esc(t("alias.noWords"))}</li>`;
      return `
        ${scoreHtml()}
        <div class="panel center">
          <h2>${esc(t("alias.roundOver", { name: teamName(turn) }))}</h2>
          <ul class="word-log">${rows}</ul>
          <p><strong>${esc(t("alias.delta", { n: delta() }))}</strong></p>
          <button class="btn primary" data-act="next">${esc(t("alias.next"))}</button>
        </div>`;
    }

    function overHtml() {
      const top = Math.max(...teams.map((team) => team.score));
      const winners = teams.map((team, index) => (team.score === top ? teamName(index) : null)).filter(Boolean).join(", ");
      return `
        ${scoreHtml()}
        <div class="panel center">
          <h2>${esc(t("alias.winner", { name: winners }))}</h2>
          <button class="btn primary" data-act="again">${esc(t("alias.again"))}</button>
        </div>`;
    }

    function render() {
      const views = { setup: setupHtml, ready: readyHtml, round: roundHtml, summary: summaryHtml, over: overHtml };
      root.innerHTML = views[phase]();
    }

    function startRound() {
      log = [];
      nextWord();
      clockText = formatClock(settings.seconds);
      clock = createCountdown(
        settings.seconds,
        (left) => {
          clockText = formatClock(left);
          const element = root.querySelector("#alias-clock");
          if (element) element.textContent = clockText;
        },
        () => {
          beep();
          endRound();
        },
      );
      phase = "round";
      render();
      clock.start();
    }

    function endRound() {
      stopClock();
      phase = "summary";
      render();
    }

    function answer(ok) {
      const points = ok ? 1 : settings.penalty ? -1 : 0;
      log.push({ word, points });
      nextWord();
      render();
    }

    function finishTurn() {
      teams[turn].score += delta();
      played++;
      turn = (turn + 1) % teams.length;
      const roundComplete = played % teams.length === 0;
      const top = Math.max(...teams.map((team) => team.score));
      const leaders = teams.filter((team) => team.score === top).length;
      phase = roundComplete && top >= settings.target && leaders === 1 ? "over" : "ready";
      render();
    }

    function newGame() {
      stopClock();
      teams = Array.from({ length: settings.teams }, () => ({ score: 0 }));
      turn = 0;
      played = 0;
      deck = shuffle(wordsFor(settings.theme));
      phase = "ready";
      render();
    }

    root.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      settings = {
        teams: Math.min(4, Math.max(2, Number(data.get("teams")) || 2)),
        seconds: Math.min(180, Math.max(15, Number(data.get("seconds")) || 60)),
        target: Math.min(100, Math.max(5, Number(data.get("target")) || 20)),
        theme: data.get("theme"),
        penalty: data.has("penalty"),
      };
      newGame();
    });

    root.addEventListener("click", (event) => {
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "go") startRound();
      else if (act === "ok") answer(true);
      else if (act === "skip") answer(false);
      else if (act === "next") finishTurn();
      else if (act === "again") {
        phase = "setup";
        render();
      }
    });

    render();
    return stopClock;
  },
};
