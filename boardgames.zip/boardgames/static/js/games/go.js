import { register, t } from "../i18n.js";

register({
  ru: { "go.passed": "Соперник пасует. Если вы тоже пасуете, игра закончится подсчётом очков." },
  en: { "go.passed": "Your opponent passed. If you pass too, the game ends and is scored." },
});

const N = 9;
const KOMI = 6.5;
const MAX_MOVES = 200;
const STAR_POINTS = [20, 24, 56, 60, 40];

const NEIGHBORS = Array.from({ length: N * N }, (_, i) => {
  const row = Math.floor(i / N);
  const col = i % N;
  const list = [];
  if (row > 0) list.push(i - N);
  if (row < N - 1) list.push(i + N);
  if (col > 0) list.push(i - 1);
  if (col < N - 1) list.push(i + 1);
  return list;
});

const cache = new WeakMap();

function groupOf(board, start) {
  const color = board[start];
  const stones = [start];
  const seen = new Set([start]);
  const liberties = new Set();
  for (let k = 0; k < stones.length; k++) {
    for (const next of NEIGHBORS[stones[k]]) {
      if (board[next] === 0) liberties.add(next);
      else if (board[next] === color && !seen.has(next)) {
        seen.add(next);
        stones.push(next);
      }
    }
  }
  return { stones, liberties };
}

function tryPlace(state, index) {
  if (state.board[index] !== 0 || index === state.ko) return null;
  const board = state.board.slice();
  const me = state.turn;
  const captured = [];
  board[index] = me;
  for (const next of NEIGHBORS[index]) {
    if (board[next] !== 3 - me) continue;
    const group = groupOf(board, next);
    if (group.liberties.size > 0) continue;
    for (const stone of group.stones) {
      board[stone] = 0;
      captured.push(stone);
    }
  }
  const own = groupOf(board, index);
  if (own.liberties.size === 0) return null;
  const ko = captured.length === 1 && own.stones.length === 1 && own.liberties.size === 1 ? captured[0] : -1;
  return { board, captured, ko, own };
}

function legalPoints(state) {
  const points = [];
  for (let index = 0; index < N * N; index++) {
    if (tryPlace(state, index)) points.push(index);
  }
  return points;
}

function areaScore(board) {
  const totals = [0, 0, 0];
  const seen = new Set();
  for (let start = 0; start < N * N; start++) {
    if (board[start] !== 0) {
      totals[board[start]]++;
      continue;
    }
    if (seen.has(start)) continue;
    const region = [start];
    seen.add(start);
    const borders = new Set();
    for (let k = 0; k < region.length; k++) {
      for (const next of NEIGHBORS[region[k]]) {
        if (board[next] === 0) {
          if (!seen.has(next)) {
            seen.add(next);
            region.push(next);
          }
        } else borders.add(board[next]);
      }
    }
    if (borders.size === 1) totals[[...borders][0]] += region.length;
  }
  return [totals[1], totals[2]];
}

function moves(state) {
  if (cache.has(state)) return cache.get(state);
  const list = result(state) === null ? [...legalPoints(state), "pass"] : [];
  cache.set(state, list);
  return list;
}

function result(state) {
  if (state.passes < 2 && state.count < MAX_MOVES) return null;
  const [black, white] = areaScore(state.board);
  return black > white + KOMI ? 1 : 2;
}

function isOwnEye(board, index, player) {
  return NEIGHBORS[index].every((next) => board[next] === player);
}

export const go = {
  id: "go",
  depths: [0, 0, 0],
  names: { ru: ["Чёрные", "Белые"], en: ["Black", "White"] },
  buttons: [{ id: "pass", label: "play.pass" }],

  init() {
    return { board: Array(N * N).fill(0), turn: 1, passes: 0, ko: -1, last: null, caps: [0, 0], count: 0 };
  },

  moves,
  result,

  play(state, move) {
    if (move === "pass") {
      return { ...state, turn: 3 - state.turn, passes: state.passes + 1, ko: -1, last: "pass", count: state.count + 1 };
    }
    const placed = tryPlace(state, move);
    const caps = state.caps.slice();
    caps[state.turn - 1] += placed.captured.length;
    return { board: placed.board, turn: 3 - state.turn, passes: 0, ko: placed.ko, last: move, caps, count: state.count + 1 };
  },

  ai(state, level) {
    const me = state.turn;
    const opponent = 3 - me;
    const [black, white] = areaScore(state.board);
    const mine = me === 1 ? black : white + KOMI;
    const theirs = me === 1 ? white + KOMI : black;
    if (state.passes >= 1 && mine > theirs) return "pass";

    const noise = [18, 6, 1][level];
    let best = "pass";
    let bestScore = -40;
    for (const index of legalPoints(state)) {
      if (isOwnEye(state.board, index, me)) continue;
      const trial = tryPlace(state, index);
      let score = trial.captured.length * 20;
      if (trial.own.liberties.size === 1 && trial.captured.length === 0) score -= 25;
      for (const next of NEIGHBORS[index]) {
        if (state.board[next] === opponent && groupOf(trial.board, next).liberties.size === 1) score += 8;
        if (state.board[next] === opponent) score += 1.5;
        if (state.board[next] === me) {
          score += 1;
          if (groupOf(state.board, next).liberties.size === 1 && trial.own.liberties.size >= 2) score += 14;
        }
      }
      const row = Math.floor(index / N);
      const col = index % N;
      score -= (Math.abs(row - 4) + Math.abs(col - 4)) * 1.5;
      if (state.count < 12 && (row === 0 || col === 0 || row === N - 1 || col === N - 1)) score -= 8;
      score += (Math.random() - 0.5) * 2 * noise;
      if (score > bestScore) {
        bestScore = score;
        best = index;
      }
    }
    return best;
  },

  click(state, cell) {
    if (cell === "pass") return { move: "pass" };
    return moves(state).includes(cell) ? { move: cell } : null;
  },

  stats(state) {
    const [black, white] = areaScore(state.board);
    return [black, white + KOMI];
  },

  info(state) {
    return state.passes === 1 ? t("go.passed") : "";
  },

  render(state, view) {
    const gap = 40;
    const pad = 30;
    const size = (N - 1) * gap + pad * 2;
    const at = (index) => [pad + (index % N) * gap, pad + Math.floor(index / N) * gap];
    const legal = view.interactive ? moves(state) : [];
    const parts = [`<rect x="0" y="0" width="${size}" height="${size}" rx="10" class="go-wood"/>`];
    for (let k = 0; k < N; k++) {
      const offset = pad + k * gap;
      parts.push(`<line class="go-line" x1="${pad}" y1="${offset}" x2="${size - pad}" y2="${offset}"/>`);
      parts.push(`<line class="go-line" x1="${offset}" y1="${pad}" x2="${offset}" y2="${size - pad}"/>`);
    }
    for (const index of STAR_POINTS) {
      const [x, y] = at(index);
      parts.push(`<circle class="go-star" cx="${x}" cy="${y}" r="3.5"/>`);
    }
    for (let index = 0; index < N * N; index++) {
      const [x, y] = at(index);
      const value = state.board[index];
      if (value) parts.push(`<circle class="go-stone s${value}" cx="${x}" cy="${y}" r="17"/>`);
      if (state.last === index) parts.push(`<circle class="go-last" cx="${x}" cy="${y}" r="7"/>`);
      const playable = legal.includes(index);
      parts.push(`<circle class="go-hit${playable ? " playable" : ""}" data-cell="${index}" cx="${x}" cy="${y}" r="19"/>`);
    }
    return `<svg class="board go" viewBox="0 0 ${size} ${size}">${parts.join("")}</svg>`;
  },
};
