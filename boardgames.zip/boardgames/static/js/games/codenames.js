import { esc, register, t } from "../i18n.js";
import { shuffle } from "../util.js";
import { wordsFor } from "../words.js";

register({
  ru: {
    "cn.intro": "Две команды ищут своих агентов. Капитаны видят ключ и дают подсказки из одного слова, команды открывают карточки. Нельзя открыть убийцу.",
    "cn.start": "Новая игра",
    "cn.red": "Красные",
    "cn.blue": "Синие",
    "cn.turn": "Ход: {name}",
    "cn.left": "Осталось: {name} — {n}",
    "cn.captain": "Режим капитана",
    "cn.captainOn": "Показать ключ (капитанам)",
    "cn.captainOff": "Скрыть ключ",
    "cn.captainHint": "Ключ показан. Откройте карточки после того, как капитаны отвернутся.",
    "cn.end": "Закончить ход",
    "cn.wins": "Победа: {name}",
    "cn.assassin": "Открыт убийца!",
    "cn.hint": "Нажмите на слово, чтобы открыть карточку. Открыв чужого агента или нейтрального, ход переходит.",
  },
  en: {
    "cn.intro": "Two teams look for their agents. Spymasters see the key and give one-word clues, teams reveal cards. Never reveal the assassin.",
    "cn.start": "New game",
    "cn.red": "Red",
    "cn.blue": "Blue",
    "cn.turn": "Turn: {name}",
    "cn.left": "Left: {name} — {n}",
    "cn.captain": "Spymaster mode",
    "cn.captainOn": "Show key (spymasters)",
    "cn.captainOff": "Hide key",
    "cn.captainHint": "The key is visible. Reveal cards after the spymasters look away.",
    "cn.end": "End turn",
    "cn.wins": "Winner: {name}",
    "cn.assassin": "The assassin was revealed!",
    "cn.hint": "Click a word to reveal its card. Revealing an enemy agent or a bystander ends the turn.",
  },
});

const TEAM_NAME = { red: "cn.red", blue: "cn.blue" };
const other = (team) => (team === "red" ? "blue" : "red");

export const codenames = {
  id: "codenames",

  mount(root) {
    let game = null;
    let captain = false;

    function newGame() {
      const words = shuffle(wordsFor("all")).slice(0, 25);
      const starter = Math.random() < 0.5 ? "red" : "blue";
      const key = shuffle([
        ...Array(9).fill(starter),
        ...Array(8).fill(other(starter)),
        ...Array(7).fill("neutral"),
        "assassin",
      ]);
      game = { words, key, revealed: Array(25).fill(false), turn: starter, winner: null, assassin: false };
      captain = false;
    }

    function remaining(team) {
      return game.key.filter((value, index) => value === team && !game.revealed[index]).length;
    }

    function reveal(index) {
      if (game.winner || game.revealed[index] || captain) return;
      game.revealed[index] = true;
      const color = game.key[index];
      if (color === "assassin") {
        game.assassin = true;
        game.winner = other(game.turn);
        return;
      }
      for (const team of ["red", "blue"]) {
        if (remaining(team) === 0) {
          game.winner = team;
          return;
        }
      }
      if (color !== game.turn) game.turn = other(game.turn);
    }

    function render() {
      if (!game) {
        root.innerHTML = `
          <div class="panel center">
            <p class="muted">${esc(t("cn.intro"))}</p>
            <button class="btn primary" data-act="new">${esc(t("cn.start"))}</button>
          </div>`;
        return;
      }
      const cards = game.words.map((word, index) => {
        const classes = ["cn-card"];
        if (game.revealed[index]) classes.push("revealed", "k-" + game.key[index]);
        else if (captain) classes.push("peek", "k-" + game.key[index]);
        return `<button class="${classes.join(" ")}" data-card="${index}"${game.revealed[index] ? " disabled" : ""}>${esc(word)}</button>`;
      }).join("");
      const banner = game.winner
        ? `<div class="status finished">${esc(t("cn.wins", { name: t(TEAM_NAME[game.winner]) }))}${game.assassin ? ` — ${esc(t("cn.assassin"))}` : ""}</div>`
        : `<div class="status team-${game.turn}">${esc(t("cn.turn", { name: t(TEAM_NAME[game.turn]) }))}</div>`;
      root.innerHTML = `
        <div class="cn-head">
          ${banner}
          <div class="cn-counts">
            <span class="count team-red">${esc(t("cn.left", { name: t("cn.red"), n: remaining("red") }))}</span>
            <span class="count team-blue">${esc(t("cn.left", { name: t("cn.blue"), n: remaining("blue") }))}</span>
          </div>
        </div>
        <div class="cn-grid">${cards}</div>
        <div class="dialog-actions">
          <button class="btn${captain ? " primary" : ""}" data-act="captain">${esc(captain ? t("cn.captainOff") : t("cn.captainOn"))}</button>
          <button class="btn" data-act="end"${game.winner ? " disabled" : ""}>${esc(t("cn.end"))}</button>
          <button class="btn ghost" data-act="new">${esc(t("cn.start"))}</button>
        </div>
        <p class="hint">${esc(captain ? t("cn.captainHint") : t("cn.hint"))}</p>`;
    }

    root.addEventListener("click", (event) => {
      const card = event.target.closest("[data-card]");
      if (card) {
        reveal(Number(card.dataset.card));
        render();
        return;
      }
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "new") newGame();
      else if (act === "captain") captain = !captain;
      else if (act === "end" && !game.winner) game.turn = other(game.turn);
      else return;
      render();
    });

    render();
    return () => {};
  },
};
