import { esc, register, t } from "../i18n.js";
import { randInt } from "../util.js";

register({
  ru: {
    "ld.intro": "Выведите все четыре фишки на круг, пройдите его и доведите до центра. Выйти из дома можно только на 6. Фишка соперника на вашей клетке возвращается домой, кроме клеток-убежищ. Шестёрка даёт дополнительный бросок, а в центр нужен точный бросок.",
    "ld.players": "Игроков",
    "ld.humans": "Из них людей",
    "ld.start": "Начать игру",
    "ld.color.0": "Красные",
    "ld.color.1": "Зелёные",
    "ld.color.2": "Жёлтые",
    "ld.color.3": "Синие",
    "ld.turn": "Ход: {name}",
    "ld.roll": "Бросить кубик",
    "ld.rolled": "{name} выбросил {n}.",
    "ld.pick": "Выберите фишку для хода.",
    "ld.nomove": "Ходов нет.",
    "ld.captured": "Фишка соперника отправлена домой!",
    "ld.again6": "Шестёрка: бросок ещё раз.",
    "ld.win": "Победа: {name}!",
    "ld.new": "Новая игра",
  },
  en: {
    "ld.intro": "Bring all four tokens out, run them around the track and into the centre. You can leave home only on a 6. An opponent's token on your square is sent home, except on safe squares. A six gives another roll, and you need an exact roll to reach the centre.",
    "ld.players": "Players",
    "ld.humans": "Of them humans",
    "ld.start": "Start game",
    "ld.color.0": "Red",
    "ld.color.1": "Green",
    "ld.color.2": "Yellow",
    "ld.color.3": "Blue",
    "ld.turn": "Turn: {name}",
    "ld.roll": "Roll the die",
    "ld.rolled": "{name} rolled {n}.",
    "ld.pick": "Pick a token to move.",
    "ld.nomove": "No moves available.",
    "ld.captured": "An opponent's token was sent home!",
    "ld.again6": "A six: roll again.",
    "ld.win": "Winner: {name}!",
    "ld.new": "New game",
  },
});

const COLORS = ["#d64541", "#2e8b57", "#e0a21b", "#2b6c8f"];
const FACES = ["", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
const SEATS = { 2: [0, 2], 3: [0, 1, 2], 4: [0, 1, 2, 3] };
const FINISH = 56;
const LAST_TRACK = 50;
const CELL = 36;
const YARDS = [[9, 1.5], [9, 8.5], [2, 8.5], [2, 1.5]];
const COLUMN_START = [[6, 1, 0, 1], [12, 6, -1, 0], [7, 12, 0, -1], [1, 7, 1, 0]];
const FINISH_OFFSETS = [[0, -1], [1, 0], [0, 1], [-1, 0]];
const BOT_DELAY = 650;

export function globalSquare(color, progress) {
  return (13 * color + 8 + progress) % 52;
}

export function isSafe(square) {
  return square % 13 === 8 || square % 13 === 0;
}

export function legalTokens(tokens, color, roll) {
  const list = [];
  tokens[color].forEach((progress, index) => {
    if (progress === -1) {
      if (roll === 6) list.push(index);
    } else if (progress + roll <= FINISH) list.push(index);
  });
  return list;
}

export function applyMove(tokens, color, index, roll) {
  const next = tokens.map((row) => row.slice());
  const progress = next[color][index];
  const target = progress === -1 ? 0 : progress + roll;
  next[color][index] = target;
  let captured = 0;
  if (target <= LAST_TRACK) {
    const square = globalSquare(color, target);
    if (!isSafe(square)) {
      next.forEach((row, other) => {
        if (!row || other === color) return;
        row.forEach((value, i) => {
          if (value >= 0 && value <= LAST_TRACK && globalSquare(other, value) === square) {
            row[i] = -1;
            captured++;
          }
        });
      });
    }
  }
  return { tokens: next, captured };
}

function chooseBotMove(tokens, color, roll, options) {
  let best = options[0];
  let bestScore = -Infinity;
  for (const index of options) {
    const progress = tokens[color][index];
    const result = applyMove(tokens, color, index, roll);
    const target = progress === -1 ? 0 : progress + roll;
    let score = Math.random();
    if (target === FINISH) score += 100;
    score += result.captured * 80;
    if (progress === -1) score += 50;
    if (target > LAST_TRACK) score += 30;
    if (target <= LAST_TRACK && isSafe(globalSquare(color, target))) score += 15;
    score += target / 10;
    if (score > bestScore) {
      bestScore = score;
      best = index;
    }
  }
  return best;
}

function trackPosition(square) {
  const side = Math.floor(square / 13);
  const i = square % 13;
  if (side === 0) return [i, 0];
  if (side === 1) return [13, i];
  if (side === 2) return [13 - i, 13];
  return [0, 13 - i];
}

function tokenPosition(color, index, progress) {
  if (progress === -1) {
    const [ox, oy] = YARDS[color];
    return [ox + (index % 2) * 1.6 + 0.5, oy + Math.floor(index / 2) * 1.6 + 0.5];
  }
  if (progress <= LAST_TRACK) {
    const [x, y] = trackPosition(globalSquare(color, progress));
    return [x + 0.5, y + 0.5];
  }
  if (progress < FINISH) {
    const [x, y, dx, dy] = COLUMN_START[color];
    const k = progress - 51;
    return [x + dx * k + 0.5, y + dy * k + 0.5];
  }
  const [dx, dy] = FINISH_OFFSETS[color];
  return [7 + dx * 0.9 + (index % 2) * 0.01, 7 + dy * 0.9];
}

export const ludo = {
  id: "ludo",

  mount(root) {
    let settings = { players: 4, humans: 1 };
    let game = null;
    let timer = null;
    let disposed = false;

    const colorName = (seat) => t("ld.color." + game.seats[seat]);

    function newGame() {
      clearTimeout(timer);
      const seats = SEATS[settings.players];
      const tokens = [[], [], [], []];
      seats.forEach((color) => {
        tokens[color] = [-1, -1, -1, -1];
      });
      game = {
        seats,
        tokens,
        humans: settings.humans,
        turn: 0,
        roll: 0,
        rolled: false,
        options: [],
        message: "",
        winner: null,
      };
      scheduleBot();
    }

    const isBot = () => game.turn >= game.humans;
    const colorOfTurn = () => game.seats[game.turn];

    function nextTurn() {
      game.turn = (game.turn + 1) % game.seats.length;
      game.rolled = false;
      game.options = [];
    }

    function doRoll() {
      if (game.winner !== null || game.rolled) return;
      const color = colorOfTurn();
      game.roll = 1 + randInt(6);
      game.rolled = true;
      game.options = legalTokens(game.tokens, color, game.roll);
      const lines = [t("ld.rolled", { name: colorName(game.turn), n: game.roll })];
      if (game.options.length === 0) {
        lines.push(t("ld.nomove"));
        game.message = lines.join(" ");
        render();
        timer = setTimeout(() => {
          if (disposed) return;
          nextTurn();
          render();
          scheduleBot();
        }, 900);
        return;
      }
      if (game.options.length === 1 || isBot()) {
        game.message = lines.join(" ");
        render();
        const choice = isBot() ? chooseBotMove(game.tokens, color, game.roll, game.options) : game.options[0];
        timer = setTimeout(() => move(choice), isBot() ? BOT_DELAY : 450);
        return;
      }
      lines.push(t("ld.pick"));
      game.message = lines.join(" ");
      render();
    }

    function move(index) {
      if (disposed || !game.options.includes(index)) return;
      const color = colorOfTurn();
      const result = applyMove(game.tokens, color, index, game.roll);
      game.tokens = result.tokens;
      const lines = [t("ld.rolled", { name: colorName(game.turn), n: game.roll })];
      if (result.captured) lines.push(t("ld.captured"));
      if (game.tokens[color].every((progress) => progress === FINISH)) {
        game.winner = game.turn;
        game.message = lines.join(" ");
        render();
        return;
      }
      if (game.roll === 6) {
        lines.push(t("ld.again6"));
        game.rolled = false;
        game.options = [];
      } else nextTurn();
      game.message = lines.join(" ");
      render();
      scheduleBot();
    }

    function scheduleBot() {
      if (disposed || !game || game.winner !== null || !isBot()) return;
      timer = setTimeout(doRoll, BOT_DELAY);
    }

    function boardSvg() {
      const size = 14 * CELL;
      const parts = [`<rect class="ld-board" x="0" y="0" width="${size}" height="${size}" rx="14"/>`];
      parts.push(`<circle class="ld-centre" cx="${7 * CELL}" cy="${7 * CELL}" r="${CELL * 1.4}"/>`);
      for (let square = 0; square < 52; square++) {
        const [x, y] = trackPosition(square);
        const startOf = [0, 1, 2, 3].find((color) => square === (13 * color + 8) % 52);
        const style = startOf === undefined ? "" : ` style="fill:${COLORS[startOf]}"`;
        parts.push(`<rect class="ld-cell${isSafe(square) ? " safe" : ""}" x="${x * CELL + 2}" y="${y * CELL + 2}" width="${CELL - 4}" height="${CELL - 4}" rx="6"${style}/>`);
        if (isSafe(square)) parts.push(`<text class="ld-star" x="${(x + 0.5) * CELL}" y="${(y + 0.5) * CELL + 5}">★</text>`);
      }
      game.seats.forEach((color) => {
        const [x, y, dx, dy] = COLUMN_START[color];
        for (let k = 0; k < 5; k++) {
          parts.push(`<rect class="ld-cell home" x="${(x + dx * k) * CELL + 2}" y="${(y + dy * k) * CELL + 2}" width="${CELL - 4}" height="${CELL - 4}" rx="6" style="fill:${COLORS[color]};opacity:.55"/>`);
        }
        const [yx, yy] = YARDS[color];
        parts.push(`<rect class="ld-yard" x="${yx * CELL - 6}" y="${yy * CELL - 6}" width="${CELL * 3.4}" height="${CELL * 3.4}" rx="16" style="fill:${COLORS[color]}"/>`);
      });

      const turnColor = game.winner === null ? colorOfTurn() : -1;
      game.seats.forEach((color) => {
        game.tokens[color].forEach((progress, index) => {
          const [x, y] = tokenPosition(color, index, progress);
          const stacked = game.tokens[color].slice(0, index).filter((other) => other === progress).length
            + game.seats.reduce((sum, otherColor) => (otherColor === color ? sum : sum + game.tokens[otherColor].filter((value) => value === progress && progress >= 0 && progress <= LAST_TRACK && globalSquare(otherColor, value) === globalSquare(color, progress)).length), 0);
          const offset = progress >= 0 && progress < FINISH ? stacked * 5 : 0;
          const movable = color === turnColor && game.rolled && !isBot() && game.options.includes(index);
          parts.push(`<circle class="ld-token${movable ? " movable" : ""}" data-token="${index}" cx="${x * CELL + offset}" cy="${y * CELL - offset}" r="${CELL * 0.36}" style="fill:${COLORS[color]}"/>`);
        });
      });
      return `<svg class="board ld" viewBox="0 0 ${size} ${size}">${parts.join("")}</svg>`;
    }

    function setupHtml() {
      return `
        <form class="panel setup" id="ld-form">
          <p class="muted">${esc(t("ld.intro"))}</p>
          <div class="form-row">
            <label class="field"><span>${esc(t("ld.players"))}</span><input type="number" name="players" min="2" max="4" value="${settings.players}"></label>
            <label class="field"><span>${esc(t("ld.humans"))}</span><input type="number" name="humans" min="1" max="4" value="${settings.humans}"></label>
          </div>
          <button class="btn primary" type="submit">${esc(t("ld.start"))}</button>
        </form>`;
    }

    function render() {
      if (!game) {
        root.innerHTML = setupHtml();
        return;
      }
      const status = game.winner !== null ? t("ld.win", { name: colorName(game.winner) }) : t("ld.turn", { name: colorName(game.turn) });
      const players = game.seats
        .map((color, seat) => `<div class="player${game.winner === null && seat === game.turn ? " active" : ""}"><span class="swatch" style="background:${COLORS[color]}"></span>${esc(colorName(seat))}<strong>${game.tokens[color].filter((value) => value === FINISH).length}/4</strong></div>`)
        .join("");
      const canRoll = game.winner === null && !isBot() && !game.rolled;
      root.innerHTML = `
        <div class="play-area">
          <div class="play-side">
            <div class="status${game.winner !== null ? " finished" : ""}">${esc(status)}</div>
            <div class="scoreboard">${players}</div>
            <div class="die">${FACES[game.roll] || ""}</div>
            <button class="btn primary" data-act="roll"${canRoll ? "" : " disabled"}>${esc(t("ld.roll"))}</button>
            <p class="hint">${esc(game.message)}</p>
            <button class="btn ghost" data-act="new">${esc(t("ld.new"))}</button>
          </div>
          <div class="board-holder">${boardSvg()}</div>
        </div>`;
    }

    root.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      const players = Math.min(4, Math.max(2, Number(data.get("players")) || 4));
      settings = { players, humans: Math.min(players, Math.max(1, Number(data.get("humans")) || 1)) };
      newGame();
      render();
    });

    root.addEventListener("click", (event) => {
      const token = event.target.closest("[data-token]");
      if (token && game && game.rolled && !isBot() && game.winner === null) {
        const color = colorOfTurn();
        const index = Number(token.dataset.token);
        const owner = token.getAttribute("style").includes(COLORS[color]);
        if (owner && game.options.includes(index)) move(index);
        return;
      }
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "roll" && game && !isBot()) doRoll();
      else if (act === "new") {
        clearTimeout(timer);
        game = null;
        render();
      }
    });

    render();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  },
};
