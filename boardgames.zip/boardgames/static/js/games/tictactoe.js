const LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

const MARKS = { 1: "X", 2: "O" };

function moves(state) {
  return state.board.flatMap((value, index) => (value === 0 ? [index] : []));
}

function result(state) {
  for (const [a, b, c] of LINES) {
    const value = state.board[a];
    if (value !== 0 && value === state.board[b] && value === state.board[c]) return value;
  }
  return moves(state).length === 0 ? "draw" : null;
}

function winningLine(state) {
  return LINES.find(([a, b, c]) => {
    const value = state.board[a];
    return value !== 0 && value === state.board[b] && value === state.board[c];
  });
}

export const tictactoe = {
  id: "tictactoe",
  depths: [1, 4, 9],
  names: { ru: ["Крестики", "Нолики"], en: ["Crosses", "Noughts"] },

  init() {
    return { board: Array(9).fill(0), turn: 1, last: null };
  },

  moves,
  result,

  play(state, index) {
    const board = state.board.slice();
    board[index] = state.turn;
    return { board, turn: 3 - state.turn, last: index };
  },

  score() {
    return 0;
  },

  click(state, cell) {
    return moves(state).includes(cell) ? { move: cell } : null;
  },

  stats() {
    return null;
  },

  render(state, view) {
    const line = winningLine(state) || [];
    const legal = view.interactive ? moves(state) : [];
    const cells = state.board.map((value, index) => {
      const classes = ["ttt-cell"];
      if (value) classes.push("filled", "mark-" + value);
      if (state.last === index) classes.push("last");
      if (line.includes(index)) classes.push("win");
      if (legal.includes(index)) classes.push("playable");
      return `<button class="${classes.join(" ")}" data-cell="${index}">${MARKS[value] || ""}</button>`;
    });
    return `<div class="board ttt">${cells.join("")}</div>`;
  },
};
