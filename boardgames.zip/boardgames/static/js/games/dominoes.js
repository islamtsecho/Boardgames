import { esc, register, t } from "../i18n.js";
import { shuffle } from "../util.js";

register({
  ru: {
    "dm.intro": "Выкладывайте кости так, чтобы числа на концах цепочки совпадали. Если хода нет, берите кость из базара. Побеждает тот, кто первым избавится от всех костей, а при блокировке выигрывает тот, у кого меньше очков.",
    "dm.start": "Играть против компьютера",
    "dm.yourTurn": "Ваш ход: выберите кость.",
    "dm.aiTurn": "Ходит компьютер…",
    "dm.chooseSide": "Куда положить кость?",
    "dm.left": "Слева",
    "dm.right": "Справа",
    "dm.draw": "Взять из базара",
    "dm.pass": "Пропустить ход",
    "dm.noMove": "У вас нет подходящей кости.",
    "dm.boneyard": "В базаре: {n}",
    "dm.opponent": "Костей у компьютера: {n}",
    "dm.yourHand": "Ваши кости",
    "dm.win": "Вы победили!",
    "dm.lose": "Победил компьютер.",
    "dm.blockWin": "Блокировка: у вас меньше очков, вы победили! ({you} против {ai})",
    "dm.blockLose": "Блокировка: у компьютера меньше очков. ({you} против {ai})",
    "dm.blockDraw": "Блокировка: ничья. ({you} против {ai})",
    "dm.aiDrew": "Компьютер взял кость из базара.",
    "dm.aiPassed": "Компьютер пропускает ход.",
    "dm.new": "Новая игра",
    "dm.empty": "Кости ещё не выложены.",
  },
  en: {
    "dm.intro": "Place tiles so the numbers at the ends of the chain match. If you cannot move, draw from the boneyard. The first to empty their hand wins; in a blocked game the lower pip total wins.",
    "dm.start": "Play against the computer",
    "dm.yourTurn": "Your turn: pick a tile.",
    "dm.aiTurn": "The computer is moving…",
    "dm.chooseSide": "Which end?",
    "dm.left": "Left",
    "dm.right": "Right",
    "dm.draw": "Draw from the boneyard",
    "dm.pass": "Pass",
    "dm.noMove": "You have no playable tile.",
    "dm.boneyard": "Boneyard: {n}",
    "dm.opponent": "Computer's tiles: {n}",
    "dm.yourHand": "Your tiles",
    "dm.win": "You win!",
    "dm.lose": "The computer wins.",
    "dm.blockWin": "Blocked game: you have fewer pips, you win! ({you} vs {ai})",
    "dm.blockLose": "Blocked game: the computer has fewer pips. ({you} vs {ai})",
    "dm.blockDraw": "Blocked game: a draw. ({you} vs {ai})",
    "dm.aiDrew": "The computer drew from the boneyard.",
    "dm.aiPassed": "The computer passes.",
    "dm.new": "New game",
    "dm.empty": "No tiles on the table yet.",
  },
});

const PIPS = [" ", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
const AI_DELAY = 800;

export function allTiles() {
  const tiles = [];
  for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) tiles.push([a, b]);
  return tiles;
}

export function sides(chain, tile) {
  if (chain.length === 0) return ["start"];
  const left = chain[0][0];
  const right = chain[chain.length - 1][1];
  const list = [];
  if (tile[0] === left || tile[1] === left) list.push("left");
  if (tile[0] === right || tile[1] === right) list.push("right");
  return list;
}

export function place(chain, tile, side) {
  if (side === "start") return [tile];
  if (side === "left") {
    const left = chain[0][0];
    const oriented = tile[1] === left ? tile : [tile[1], tile[0]];
    return [oriented, ...chain];
  }
  const right = chain[chain.length - 1][1];
  const oriented = tile[0] === right ? tile : [tile[1], tile[0]];
  return [...chain, oriented];
}

const pipTotal = (hand) => hand.reduce((sum, tile) => sum + tile[0] + tile[1], 0);

export const dominoes = {
  id: "dominoes",

  mount(root) {
    let game = null;
    let timer = null;
    let disposed = false;

    function newGame() {
      clearTimeout(timer);
      const deck = shuffle(allTiles());
      const hands = [deck.slice(0, 7), deck.slice(7, 14)];
      const boneyard = deck.slice(14);
      const best = (hand) => hand.filter((tile) => tile[0] === tile[1]).reduce((max, tile) => Math.max(max, tile[0]), -1);
      const doubles = [best(hands[0]), best(hands[1])];
      let starter;
      if (doubles[0] === -1 && doubles[1] === -1) {
        const top = (hand) => Math.max(...hand.map((tile) => tile[0] + tile[1]));
        starter = top(hands[0]) >= top(hands[1]) ? 0 : 1;
      } else starter = doubles[0] >= doubles[1] ? 0 : 1;
      game = { hands, boneyard, chain: [], turn: starter, passes: 0, selected: null, message: "", winner: null };
      if (starter === 0) game.message = t("dm.yourTurn");
      else game.message = t("dm.aiTurn");
      if (starter === 1) timer = setTimeout(aiMove, AI_DELAY);
    }

    function playTile(player, tileIndex, side) {
      const tile = game.hands[player][tileIndex];
      game.hands[player].splice(tileIndex, 1);
      game.chain = place(game.chain, tile, side);
      game.passes = 0;
      game.selected = null;
      if (game.hands[player].length === 0) {
        game.winner = player === 0 ? "you" : "ai";
        return;
      }
      game.turn = 1 - player;
    }

    function checkBlock() {
      if (game.passes < 2 || game.boneyard.length > 0) return;
      const you = pipTotal(game.hands[0]);
      const ai = pipTotal(game.hands[1]);
      game.winner = you < ai ? "blockWin" : you > ai ? "blockLose" : "blockDraw";
      game.pips = { you, ai };
    }

    function passTurn(player) {
      game.passes++;
      game.selected = null;
      game.turn = 1 - player;
      checkBlock();
    }

    function afterMove() {
      if (game.winner) {
        game.message = "";
        render();
        return;
      }
      if (game.turn === 1) {
        game.message = t("dm.aiTurn");
        render();
        timer = setTimeout(aiMove, AI_DELAY);
      } else {
        game.message = t("dm.yourTurn");
        render();
      }
    }

    function aiMove() {
      if (disposed || game.winner || game.turn !== 1) return;
      const hand = game.hands[1];
      const playable = () => hand.map((tile, index) => ({ tile, index, sides: sides(game.chain, tile) })).filter((entry) => entry.sides.length);
      let options = playable();
      let note = "";
      while (options.length === 0 && game.boneyard.length > 0) {
        hand.push(game.boneyard.pop());
        note = t("dm.aiDrew");
        options = playable();
      }
      if (options.length === 0) {
        passTurn(1);
        game.message = t("dm.aiPassed");
        if (game.winner) game.message = "";
        else game.message += ` ${t("dm.yourTurn")}`;
        render();
        return;
      }
      options.sort((a, b) => (b.tile[0] + b.tile[1] + (b.tile[0] === b.tile[1] ? 2 : 0)) - (a.tile[0] + a.tile[1] + (a.tile[0] === a.tile[1] ? 2 : 0)));
      const choice = options[0];
      playTile(1, choice.index, choice.sides[0]);
      afterMove();
      if (note && !game.winner) {
        game.message = `${note} ${game.message}`;
        render();
      }
    }

    function tileHtml(tile, attrs = "", cls = "") {
      return `<button class="domino ${cls}" ${attrs}><span>${PIPS[tile[0]]}</span><span>${PIPS[tile[1]]}</span></button>`;
    }

    function chainHtml() {
      if (game.chain.length === 0) return `<p class="muted">${esc(t("dm.empty"))}</p>`;
      return game.chain.map((tile) => `<div class="domino chain-tile${tile[0] === tile[1] ? " double" : ""}"><span>${PIPS[tile[0]]}</span><span>${PIPS[tile[1]]}</span></div>`).join("");
    }

    function resultText() {
      if (game.winner === "you") return t("dm.win");
      if (game.winner === "ai") return t("dm.lose");
      return t("dm." + game.winner, game.pips);
    }

    function render() {
      if (!game) {
        root.innerHTML = `
          <div class="panel center">
            <p class="muted">${esc(t("dm.intro"))}</p>
            <button class="btn primary" data-act="new">${esc(t("dm.start"))}</button>
          </div>`;
        return;
      }
      const myTurn = game.turn === 0 && !game.winner;
      const hand = game.hands[0];
      const playableIndexes = hand.map((tile, index) => (sides(game.chain, tile).length ? index : -1)).filter((index) => index >= 0);
      const stuck = myTurn && playableIndexes.length === 0;
      const tiles = hand
        .map((tile, index) => tileHtml(tile, `data-tile="${index}"${myTurn ? "" : " disabled"}`, `${playableIndexes.includes(index) && myTurn ? "playable" : ""}${game.selected === index ? " selected" : ""}`))
        .join("");

      let actions = "";
      if (game.selected !== null && myTurn) {
        const options = sides(game.chain, hand[game.selected]);
        if (options.length === 2) {
          actions = `<span class="muted">${esc(t("dm.chooseSide"))}</span>
            <button class="btn" data-side="left">${esc(t("dm.left"))}</button>
            <button class="btn" data-side="right">${esc(t("dm.right"))}</button>`;
        }
      }
      if (stuck) {
        actions = game.boneyard.length > 0
          ? `<span class="muted">${esc(t("dm.noMove"))}</span><button class="btn primary" data-act="draw">${esc(t("dm.draw"))}</button>`
          : `<span class="muted">${esc(t("dm.noMove"))}</span><button class="btn primary" data-act="pass">${esc(t("dm.pass"))}</button>`;
      }

      root.innerHTML = `
        <div class="status${game.winner ? " finished" : ""}">${esc(game.winner ? resultText() : game.message)}</div>
        <p class="muted">${esc(t("dm.opponent", { n: game.hands[1].length }))} · ${esc(t("dm.boneyard", { n: game.boneyard.length }))}</p>
        <div class="dm-chain">${chainHtml()}</div>
        <h4>${esc(t("dm.yourHand"))}</h4>
        <div class="dm-hand">${tiles}</div>
        <div class="dialog-actions">${actions}<button class="btn ghost" data-act="new">${esc(t("dm.new"))}</button></div>`;
    }

    root.addEventListener("click", (event) => {
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "new") {
        newGame();
        return render();
      }
      if (!game || game.winner || game.turn !== 0) return;

      if (act === "draw" && game.boneyard.length > 0) {
        game.hands[0].push(game.boneyard.pop());
        return render();
      }
      if (act === "pass") {
        passTurn(0);
        return afterMove();
      }
      const side = event.target.closest("[data-side]")?.dataset.side;
      if (side && game.selected !== null) {
        playTile(0, game.selected, side);
        return afterMove();
      }
      const tileButton = event.target.closest("[data-tile]");
      if (tileButton) {
        const index = Number(tileButton.dataset.tile);
        const options = sides(game.chain, game.hands[0][index]);
        if (options.length === 0) return;
        if (options.length === 1) {
          playTile(0, index, options[0]);
          return afterMove();
        }
        game.selected = game.selected === index ? null : index;
        render();
      }
    });

    render();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  },
};
