import { esc, register, t } from "../i18n.js";
import { randInt } from "../util.js";

register({
  ru: {
    "jg.intro": "Осторожно вытаскивайте бруски из нижних уровней и кладите их на верх башни. Проигрывает тот, при ком башня рухнула. Чем меньше опоры у уровня, тем выше риск.",
    "jg.players": "Игроков",
    "jg.bots": "Из них компьютеров",
    "jg.start": "Начать игру",
    "jg.player": "Игрок {n}",
    "jg.bot": "Компьютер {n}",
    "jg.turnPull": "{name}: вытащите брусок",
    "jg.turnPlace": "{name}: положите брусок наверх",
    "jg.hint": "Тянуть можно из любого уровня, кроме двух верхних. Грани брусков видны то с одной, то с другой стороны, поэтому башню можно поворачивать.",
    "jg.placeHere": "Куда положить брусок?",
    "jg.rotate": "Повернуть башню",
    "jg.stability": "Устойчивость",
    "jg.stab.high": "Башня устойчива",
    "jg.stab.mid": "Башня шатается",
    "jg.stab.low": "Вот-вот рухнет",
    "jg.pulls": "Вытащено: {n}",
    "jg.levels": "Уровней: {n}",
    "jg.pulledMsg": "{name} вытащил брусок.",
    "jg.fell": "Башня рухнула! Проиграл: {name}.",
    "jg.others": "Остальные игроки победили.",
    "jg.new": "Новая игра",
    "jg.slot": "Положить сюда",
  },
  en: {
    "jg.intro": "Carefully pull blocks from the lower levels and stack them on top. Whoever makes the tower fall loses. The less support a level has, the higher the risk.",
    "jg.players": "Players",
    "jg.bots": "Of them computers",
    "jg.start": "Start game",
    "jg.player": "Player {n}",
    "jg.bot": "Computer {n}",
    "jg.turnPull": "{name}: pull a block",
    "jg.turnPlace": "{name}: place the block on top",
    "jg.hint": "You may pull from any level except the top two. Block faces are visible from one side at a time, so you can rotate the tower.",
    "jg.placeHere": "Where to put the block?",
    "jg.rotate": "Rotate the tower",
    "jg.stability": "Stability",
    "jg.stab.high": "The tower is stable",
    "jg.stab.mid": "The tower is wobbling",
    "jg.stab.low": "About to fall",
    "jg.pulls": "Pulled: {n}",
    "jg.levels": "Levels: {n}",
    "jg.pulledMsg": "{name} pulled a block.",
    "jg.fell": "The tower fell! Loser: {name}.",
    "jg.others": "The other players win.",
    "jg.new": "New game",
    "jg.slot": "Place here",
  },
});

const LEVELS = 18;
const BLOCK_W = 54;
const BLOCK_H = 32;
const BOT_DELAY = 900;

export function newTower() {
  return Array.from({ length: LEVELS }, () => [true, true, true]);
}

export function axisOf(level) {
  return level % 2 === 0 ? "x" : "y";
}

function presentSlots(row) {
  return [0, 1, 2].filter((slot) => row[slot]);
}

function centreOf(level, slot) {
  return axisOf(level) === "x" ? [slot - 1, 0] : [0, slot - 1];
}

function contactBox(lowerLevel, lowerRow, upperLevel, upperRow) {
  const lower = presentSlots(lowerRow);
  const upper = presentSlots(upperRow);
  if (!lower.length || !upper.length) return null;
  const lowerAlongX = axisOf(lowerLevel) === "x";
  const xs = lowerAlongX ? lower : upper;
  const ys = lowerAlongX ? upper : lower;
  return {
    xmin: Math.min(...xs) - 1.5,
    xmax: Math.max(...xs) - 0.5,
    ymin: Math.min(...ys) - 1.5,
    ymax: Math.max(...ys) - 0.5,
  };
}

function groundBox(row) {
  const slots = presentSlots(row);
  if (!slots.length) return null;
  return { xmin: Math.min(...slots) - 1.5, xmax: Math.max(...slots) - 0.5, ymin: -1.5, ymax: 1.5 };
}

export function stability(tower) {
  let top = tower.length - 1;
  while (top >= 0 && presentSlots(tower[top]).length === 0) top--;
  if (top < 0) return -1;
  const sums = [];
  let sx = 0;
  let sy = 0;
  let count = 0;
  for (let level = top; level >= 0; level--) {
    for (const slot of presentSlots(tower[level])) {
      const [x, y] = centreOf(level, slot);
      sx += x;
      sy += y;
      count++;
    }
    sums[level] = [sx / count, sy / count];
  }
  let margin = Infinity;
  for (let level = 0; level <= top; level++) {
    const box = level === 0 ? groundBox(tower[0]) : contactBox(level - 1, tower[level - 1], level, tower[level]);
    if (!box) return -1;
    const [cx, cy] = sums[level];
    margin = Math.min(margin, cx - box.xmin, box.xmax - cx, cy - box.ymin, box.ymax - cy);
  }
  return margin;
}

export function collapseChance(margin) {
  if (margin < 0) return 1;
  if (margin >= 0.5) return 0.01;
  return 0.01 + (0.5 - margin) * 0.9;
}

export function allowedBlocks(tower) {
  const top = tower.length - 1;
  const blocked = tower[top].every(Boolean) ? [top] : [top, top - 1];
  const list = [];
  tower.forEach((row, level) => {
    if (blocked.includes(level)) return;
    row.forEach((present, slot) => {
      if (present) list.push({ level, slot });
    });
  });
  return list;
}

export function placementTarget(tower) {
  const top = tower.length - 1;
  const row = tower[top];
  if (row.every(Boolean)) return { level: top + 1, free: [0, 1, 2], fresh: true };
  return { level: top, free: [0, 1, 2].filter((slot) => !row[slot]), fresh: false };
}

export function placeBlock(tower, slot) {
  const target = placementTarget(tower);
  const next = tower.map((row) => row.slice());
  if (target.fresh) next.push([false, false, false]);
  next[target.level][slot] = true;
  return next;
}

function pickRandom(items) {
  return items[randInt(items.length)];
}

export function botPull(tower) {
  const options = allowedBlocks(tower).map(({ level, slot }) => {
    const next = tower.map((row) => row.slice());
    next[level][slot] = false;
    return { level, slot, margin: stability(next) };
  });
  if (options.length === 0) return null;
  const best = Math.max(...options.map((option) => option.margin));
  return pickRandom(options.filter((option) => option.margin >= best - 0.3));
}

export function botPlace(tower) {
  const target = placementTarget(tower);
  const options = target.free.map((slot) => ({ slot, margin: stability(placeBlock(tower, slot)) }));
  const best = Math.max(...options.map((option) => option.margin));
  return pickRandom(options.filter((option) => option.margin >= best - 0.01)).slot;
}

export const jenga = {
  id: "jenga",

  mount(root) {
    let settings = { players: 2, bots: 1 };
    let game = null;
    let timer = null;
    let disposed = false;

    const name = (index) => (game.players[index].bot ? t("jg.bot", { n: index + 1 }) : t("jg.player", { n: index + 1 }));
    const isBot = () => game.players[game.turn].bot;

    function newGame() {
      clearTimeout(timer);
      game = {
        tower: newTower(),
        players: Array.from({ length: settings.players }, (_, index) => ({ bot: index >= settings.players - settings.bots, pulls: 0 })),
        turn: 0,
        phase: "pull",
        view: 0,
        message: "",
        loser: null,
        fall: null,
        fallShown: false,
      };
      scheduleBot();
    }

    function collapse() {
      game.phase = "over";
      game.loser = game.turn;
      game.fall = {};
      game.tower.forEach((row, level) => {
        for (const slot of [0, 1, 2, "strip"]) {
          game.fall[`${level}-${slot}`] = {
            dx: (Math.random() - 0.5) * 170,
            dy: Math.random() * 6,
            rotate: (Math.random() - 0.5) * 120,
          };
        }
      });
      render();
    }

    function pull(level, slot) {
      if (game.phase !== "pull" || !allowedBlocks(game.tower).some((block) => block.level === level && block.slot === slot)) return;
      game.tower[level][slot] = false;
      game.players[game.turn].pulls++;
      if (Math.random() < collapseChance(stability(game.tower))) return collapse();
      game.phase = "place";
      game.message = t("jg.pulledMsg", { name: name(game.turn) });
      render();
      schedulePlacement();
    }

    function place(slot) {
      if (game.phase !== "place" || !placementTarget(game.tower).free.includes(slot)) return;
      game.tower = placeBlock(game.tower, slot);
      if (stability(game.tower) < 0) return collapse();
      game.turn = (game.turn + 1) % game.players.length;
      game.phase = "pull";
      render();
      scheduleBot();
    }

    function scheduleBot() {
      if (disposed || !game || game.phase !== "pull" || !isBot()) return;
      timer = setTimeout(() => {
        if (disposed) return;
        const choice = botPull(game.tower);
        if (!choice) return collapse();
        pull(choice.level, choice.slot);
      }, BOT_DELAY);
    }

    function schedulePlacement() {
      if (disposed || game.phase !== "place") return;
      const free = placementTarget(game.tower).free;
      if (isBot()) timer = setTimeout(() => place(botPlace(game.tower)), BOT_DELAY / 2);
      else if (free.length === 1) timer = setTimeout(() => place(free[0]), 450);
    }

    function woodColor(level, slot) {
      return `hsl(33 52% ${42 + ((level * 7 + slot * 13) % 10)}%)`;
    }

    function towerSvg() {
      const rows = game.tower.length;
      const width = BLOCK_W * 3 + 4;
      const height = (rows + 3) * BLOCK_H + 14;
      const floor = height - 10;
      const canPull = game.phase === "pull" && !isBot();
      const allowed = new Set(allowedBlocks(game.tower).map((block) => `${block.level}-${block.slot}`));
      const parts = [`<rect class="jg-floor" x="0" y="${floor}" width="${width}" height="10"/>`];
      const fallStyle = (key, y) => {
        const f = game.fall && game.fall[key];
        if (!f) return "";
        const drop = floor - (y + BLOCK_H) + f.dy;
        return ` style="--dx:${f.dx.toFixed(0)}px;--dy:${drop.toFixed(0)}px;--r:${f.rotate.toFixed(0)}deg"`;
      };
      const fallClass = game.fallShown ? " fall" : "";
      game.tower.forEach((row, level) => {
        const y = floor - (level + 1) * BLOCK_H;
        const facing = (axisOf(level) === "x") === (game.view === 0);
        if (facing) {
          for (const slot of [0, 1, 2]) {
            const x = 2 + slot * BLOCK_W;
            if (!row[slot]) {
              parts.push(`<rect class="jg-hole" x="${x + 1}" y="${y + 1}" width="${BLOCK_W - 2}" height="${BLOCK_H - 2}" rx="3"/>`);
              continue;
            }
            const key = `${level}-${slot}`;
            const clickable = canPull && allowed.has(key);
            parts.push(`<rect class="jg-block${clickable ? " pullable" : ""}${fallClass}" data-block="${key}" x="${x + 1}" y="${y + 1}" width="${BLOCK_W - 2}" height="${BLOCK_H - 2}" rx="3" fill="${woodColor(level, slot)}"${fallStyle(key, y)}/>`);
          }
        } else if (presentSlots(row).length) {
          const front = row[0];
          parts.push(`<rect class="jg-block strip${front ? "" : " deep"}${fallClass}" x="3" y="${y + 1}" width="${BLOCK_W * 3 - 2}" height="${BLOCK_H - 2}" rx="3" fill="${woodColor(level, 1)}"${fallStyle(`${level}-strip`, y)}/>`);
        }
      });
      return `<svg class="jg-tower" viewBox="0 0 ${width} ${height}" aria-label="tower">${parts.join("")}</svg>`;
    }

    function placeHtml() {
      const target = placementTarget(game.tower);
      const row = game.tower[target.level] || [false, false, false];
      const vertical = axisOf(target.level) === "y";
      const cells = [0, 1, 2].map((slot) => (row[slot]
        ? `<div class="jg-slot filled"></div>`
        : `<button class="jg-slot free" data-place="${slot}" aria-label="${esc(t("jg.slot"))}">+</button>`)).join("");
      return `
        <div class="jg-place">
          <p class="muted">${esc(t("jg.placeHere"))}</p>
          <div class="jg-top ${vertical ? "rows" : "cols"}">${cells}</div>
        </div>`;
    }

    function stabilityHtml() {
      const margin = stability(game.tower);
      const level = margin >= 1.2 ? "high" : margin >= 0.5 ? "mid" : "low";
      return `<div class="jg-meter ${level}"><span>${esc(t("jg.stability"))}</span><strong>${esc(t("jg.stab." + level))}</strong></div>`;
    }

    function setupHtml() {
      return `
        <form class="panel setup" id="jg-form">
          <p class="muted">${esc(t("jg.intro"))}</p>
          <div class="form-row">
            <label class="field"><span>${esc(t("jg.players"))}</span><input type="number" name="players" min="2" max="6" value="${settings.players}"></label>
            <label class="field"><span>${esc(t("jg.bots"))}</span><input type="number" name="bots" min="0" max="5" value="${settings.bots}"></label>
          </div>
          <button class="btn primary" type="submit">${esc(t("jg.start"))}</button>
        </form>`;
    }

    function render() {
      if (!game) {
        root.innerHTML = setupHtml();
        return;
      }
      const over = game.phase === "over";
      let status;
      if (over) status = t("jg.fell", { name: name(game.loser) });
      else status = t(game.phase === "pull" ? "jg.turnPull" : "jg.turnPlace", { name: name(game.turn) });
      const list = game.players
        .map((player, index) => `<div class="player${!over && index === game.turn ? " active" : ""}${over && index === game.loser ? " loser" : ""}">${esc(name(index))}<strong>${player.pulls}</strong></div>`)
        .join("");
      const showPlace = !over && game.phase === "place" && !isBot() && placementTarget(game.tower).free.length > 1;
      root.innerHTML = `
        <div class="play-area">
          <div class="play-side">
            <div class="status${over ? " finished" : ""}">${esc(status)}</div>
            ${over ? `<p>${esc(t("jg.others"))}</p>` : stabilityHtml()}
            <div class="scoreboard" title="${esc(t("jg.pulls", { n: "" }))}">${list}</div>
            <p class="muted">${esc(t("jg.levels", { n: game.tower.length }))} · ${esc(t("jg.pulls", { n: game.players.reduce((sum, player) => sum + player.pulls, 0) }))}</p>
            ${showPlace ? placeHtml() : ""}
            <p class="hint">${esc(game.message || t("jg.hint"))}</p>
            <div class="side-buttons">
              <button class="btn" data-act="rotate">${esc(t("jg.rotate"))}</button>
              <button class="btn ghost" data-act="new">${esc(t("jg.new"))}</button>
            </div>
          </div>
          <div class="board-holder jg-holder">${towerSvg()}</div>
        </div>`;
      if (over && !game.fallShown) {
        setTimeout(() => {
          if (disposed || !game) return;
          game.fallShown = true;
          root.querySelectorAll(".jg-block").forEach((element) => element.classList.add("fall"));
        }, 60);
      }
    }

    root.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      const players = Math.min(6, Math.max(2, Number(data.get("players")) || 2));
      settings = { players, bots: Math.min(players - 1, Math.max(0, Number(data.get("bots")) || 0)) };
      newGame();
      render();
    });

    root.addEventListener("click", (event) => {
      if (!game) return;
      const block = event.target.closest("[data-block]");
      if (block && !isBot()) {
        const [level, slot] = block.dataset.block.split("-").map(Number);
        return pull(level, slot);
      }
      const slotButton = event.target.closest("[data-place]");
      if (slotButton && !isBot()) return place(Number(slotButton.dataset.place));
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "rotate") {
        game.view = 1 - game.view;
        render();
      } else if (act === "new") {
        clearTimeout(timer);
        game = null;
        render();
      }
    });

    render();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  },
};
