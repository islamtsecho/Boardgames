import { esc, register, t } from "../i18n.js";
import { shuffle } from "../util.js";

register({
  ru: {
    "mf.intro": "Устройство работает как ведущий. Сначала каждый игрок тайно узнаёт свою роль, затем ведущий (любой из игроков) проводит ночи и дни.",
    "mf.players": "Игроков",
    "mf.roles": "Состав: мафия — {m}, комиссар — 1, доктор — {d}, мирные — {c}.",
    "mf.showRole": "Показывать роль исключённого",
    "mf.start": "Раздать роли",
    "mf.player": "Игрок {n}",
    "mf.pass": "Передайте устройство:",
    "mf.show": "Показать роль",
    "mf.hide": "Скрыть и передать дальше",
    "mf.hideLast": "Скрыть и начать игру",
    "mf.role.mafia": "Мафия",
    "mf.role.citizen": "Мирный житель",
    "mf.role.detective": "Комиссар",
    "mf.role.doctor": "Доктор",
    "mf.desc.mafia": "Ночью вы вместе выбираете жертву. Днём притворяйтесь мирными.",
    "mf.desc.citizen": "Днём ищите мафию и голосуйте.",
    "mf.desc.detective": "Каждую ночь проверяете одного игрока: мафия он или нет.",
    "mf.desc.doctor": "Каждую ночь можете спасти одного игрока от убийства.",
    "mf.mates": "Ваши сообщники: {names}",
    "mf.night": "Ночь {n}",
    "mf.dayN": "День {n}",
    "mf.step.mafia": "Просыпается мафия и выбирает жертву.",
    "mf.step.doctor": "Просыпается доктор и выбирает, кого лечить.",
    "mf.step.detective": "Просыпается комиссар и проверяет игрока.",
    "mf.choose": "Нажмите на игрока",
    "mf.confirm": "Подтвердить",
    "mf.skip": "Пропустить",
    "mf.checkResult": "{name}: {answer}",
    "mf.isMafia": "мафия",
    "mf.notMafia": "не мафия",
    "mf.morning": "Город просыпается",
    "mf.killed": "Ночью погиб: {name}.",
    "mf.noKill": "Этой ночью никто не погиб.",
    "mf.vote": "Обсуждение и голосование: кого исключить?",
    "mf.exclude": "Исключить",
    "mf.noExclude": "Никого не исключать",
    "mf.excluded": "Исключён: {name}.",
    "mf.excludedRole": "Исключён: {name}, роль — {role}.",
    "mf.nobody": "Никого не исключили.",
    "mf.nextNight": "Наступает ночь",
    "mf.toDay": "К обсуждению",
    "mf.townWins": "Победа мирных жителей!",
    "mf.mafiaWins": "Победа мафии!",
    "mf.again": "Новая игра",
    "mf.alive": "Живые: {n}",
    "mf.roles.show": "Роли (для ведущего)",
    "mf.roles.hide": "Скрыть роли",
    "mf.dead": "выбыл",
  },
  en: {
    "mf.intro": "The device is the moderator. First every player secretly learns their role, then a moderator (any player) runs the nights and days.",
    "mf.players": "Players",
    "mf.roles": "Roles: mafia — {m}, detective — 1, doctor — {d}, citizens — {c}.",
    "mf.showRole": "Reveal the role of the excluded player",
    "mf.start": "Deal roles",
    "mf.player": "Player {n}",
    "mf.pass": "Pass the device to:",
    "mf.show": "Show role",
    "mf.hide": "Hide and pass on",
    "mf.hideLast": "Hide and start the game",
    "mf.role.mafia": "Mafia",
    "mf.role.citizen": "Citizen",
    "mf.role.detective": "Detective",
    "mf.role.doctor": "Doctor",
    "mf.desc.mafia": "At night you pick a victim together. By day pretend to be a citizen.",
    "mf.desc.citizen": "By day look for the mafia and vote.",
    "mf.desc.detective": "Every night you check one player: mafia or not.",
    "mf.desc.doctor": "Every night you may save one player from being killed.",
    "mf.mates": "Your accomplices: {names}",
    "mf.night": "Night {n}",
    "mf.dayN": "Day {n}",
    "mf.step.mafia": "The mafia wakes up and picks a victim.",
    "mf.step.doctor": "The doctor wakes up and picks who to heal.",
    "mf.step.detective": "The detective wakes up and checks a player.",
    "mf.choose": "Tap a player",
    "mf.confirm": "Confirm",
    "mf.skip": "Skip",
    "mf.checkResult": "{name}: {answer}",
    "mf.isMafia": "mafia",
    "mf.notMafia": "not mafia",
    "mf.morning": "The town wakes up",
    "mf.killed": "Killed in the night: {name}.",
    "mf.noKill": "Nobody died tonight.",
    "mf.vote": "Discuss and vote: who is excluded?",
    "mf.exclude": "Exclude",
    "mf.noExclude": "Exclude nobody",
    "mf.excluded": "Excluded: {name}.",
    "mf.excludedRole": "Excluded: {name}, role — {role}.",
    "mf.nobody": "Nobody was excluded.",
    "mf.nextNight": "Night falls",
    "mf.toDay": "To the discussion",
    "mf.townWins": "The citizens win!",
    "mf.mafiaWins": "The mafia wins!",
    "mf.again": "New game",
    "mf.alive": "Alive: {n}",
    "mf.roles.show": "Roles (moderator only)",
    "mf.roles.hide": "Hide roles",
    "mf.dead": "out",
  },
});

function composition(count) {
  const mafia = Math.max(1, Math.floor(count / 3));
  const doctor = count >= 6 ? 1 : 0;
  return { mafia, doctor, citizens: count - mafia - doctor - 1 };
}

export const mafia = {
  id: "mafia",

  mount(root) {
    let count = 7;
    let showRole = true;
    let phase = "setup";
    let players = [];
    let current = 0;
    let shown = false;
    let nightNo = 0;
    let night = null;
    let picked = null;
    let message = "";
    let rolesOpen = false;
    let winner = null;

    const name = (index) => t("mf.player", { n: index + 1 });
    const roleName = (role) => t("mf.role." + role);
    const alive = () => players.filter((player) => player.alive);
    const aliveMafia = () => alive().filter((player) => player.role === "mafia").length;

    function checkWinner() {
      const bad = aliveMafia();
      const good = alive().length - bad;
      if (bad === 0) winner = "town";
      else if (bad >= good) winner = "mafia";
      return winner !== null;
    }

    function dealRoles() {
      const { mafia: m, doctor, citizens } = composition(count);
      const roles = shuffle([...Array(m).fill("mafia"), "detective", ...Array(doctor).fill("doctor"), ...Array(citizens).fill("citizen")]);
      players = roles.map((role) => ({ role, alive: true }));
      current = 0;
      shown = false;
      nightNo = 0;
      winner = null;
      phase = "reveal";
    }

    function steps() {
      const list = ["mafia"];
      if (alive().some((player) => player.role === "doctor")) list.push("doctor");
      if (alive().some((player) => player.role === "detective")) list.push("detective");
      return list;
    }

    function startNight() {
      nightNo++;
      night = { steps: steps(), index: 0, victim: null, saved: null, checked: null };
      picked = null;
      message = "";
      phase = "night";
    }

    function setupHtml() {
      const comp = composition(count);
      return `
        <form class="panel setup" id="mf-form">
          <p class="muted">${esc(t("mf.intro"))}</p>
          <label class="field"><span>${esc(t("mf.players"))}</span><input type="number" name="count" min="5" max="16" value="${count}" id="mf-count"></label>
          <p class="muted" id="mf-comp">${esc(t("mf.roles", { m: comp.mafia, d: comp.doctor, c: comp.citizens }))}</p>
          <label class="check"><input type="checkbox" name="showRole"${showRole ? " checked" : ""}> ${esc(t("mf.showRole"))}</label>
          <button class="btn primary" type="submit">${esc(t("mf.start"))}</button>
        </form>`;
    }

    function revealHtml() {
      const player = players[current];
      const last = current === players.length - 1;
      let card = `<button class="btn primary big" data-act="show">${esc(t("mf.show"))}</button>`;
      if (shown) {
        const mates = player.role === "mafia"
          ? players.map((other, index) => (other.role === "mafia" && index !== current ? name(index) : null)).filter(Boolean)
          : [];
        card = `
          <div class="role-card ${player.role === "mafia" ? "spy" : ""}">${esc(roleName(player.role))}</div>
          <p class="muted">${esc(t("mf.desc." + player.role))}</p>
          ${mates.length ? `<p>${esc(t("mf.mates", { names: mates.join(", ") }))}</p>` : ""}
          <button class="btn primary" data-act="hide">${esc(last ? t("mf.hideLast") : t("mf.hide"))}</button>`;
      }
      return `
        <div class="panel center">
          <p class="muted">${esc(t("mf.pass"))}</p>
          <h2>${esc(name(current))}</h2>
          ${card}
        </div>`;
    }

    function playersListHtml(selectable) {
      const items = players.map((player, index) => {
        const classes = ["mf-player"];
        if (!player.alive) classes.push("dead");
        if (picked === index) classes.push("picked");
        const role = rolesOpen ? `<small>${esc(roleName(player.role))}</small>` : "";
        const status = player.alive ? "" : `<small>${esc(t("mf.dead"))}</small>`;
        const clickable = selectable && player.alive;
        return `<button class="${classes.join(" ")}" ${clickable ? `data-pick="${index}"` : "disabled"}>${esc(name(index))}${role}${status}</button>`;
      }).join("");
      return `<div class="mf-grid">${items}</div>`;
    }

    function rolesToggleHtml() {
      return `<button class="btn ghost small" data-act="roles">${esc(rolesOpen ? t("mf.roles.hide") : t("mf.roles.show"))}</button>`;
    }

    function nightHtml() {
      const step = night.steps[night.index];
      const extra = step === "detective" && night.checked !== null
        ? `<p class="status">${esc(t("mf.checkResult", { name: name(night.checked), answer: players[night.checked].role === "mafia" ? t("mf.isMafia") : t("mf.notMafia") }))}</p>`
        : "";
      const done = step === "detective" && night.checked !== null;
      return `
        <div class="panel center">
          <h2>${esc(t("mf.night", { n: nightNo }))}</h2>
          <p>${esc(t("mf.step." + step))}</p>
          ${playersListHtml(!done)}
          ${extra}
          <div class="dialog-actions center-actions">
            ${done
              ? `<button class="btn primary" data-act="confirm">${esc(t("mf.confirm"))}</button>`
              : `<button class="btn primary" data-act="confirm"${picked === null ? " disabled" : ""}>${esc(step === "detective" ? t("mf.confirm") : t("mf.confirm"))}</button>`}
            ${step !== "mafia" ? `<button class="btn" data-act="skipstep">${esc(t("mf.skip"))}</button>` : ""}
          </div>
          ${rolesToggleHtml()}
        </div>`;
    }

    function morningHtml() {
      return `
        <div class="panel center">
          <h2>${esc(t("mf.morning"))}</h2>
          <p class="status">${esc(message)}</p>
          <p class="muted">${esc(t("mf.alive", { n: alive().length }))}</p>
          ${playersListHtml(false)}
          <button class="btn primary" data-act="toDay">${esc(t("mf.toDay"))}</button>
          ${rolesToggleHtml()}
        </div>`;
    }

    function dayHtml() {
      return `
        <div class="panel center">
          <h2>${esc(t("mf.dayN", { n: nightNo }))}</h2>
          <p>${esc(t("mf.vote"))}</p>
          ${playersListHtml(true)}
          <div class="dialog-actions center-actions">
            <button class="btn primary" data-act="exclude"${picked === null ? " disabled" : ""}>${esc(t("mf.exclude"))}</button>
            <button class="btn" data-act="nobody">${esc(t("mf.noExclude"))}</button>
          </div>
          ${rolesToggleHtml()}
        </div>`;
    }

    function resultHtml() {
      return `
        <div class="panel center">
          <p class="status">${esc(message)}</p>
          <button class="btn primary" data-act="nextNight">${esc(t("mf.nextNight"))}</button>
          ${rolesToggleHtml()}
        </div>`;
    }

    function overHtml() {
      return `
        <div class="panel center">
          <h2>${esc(winner === "town" ? t("mf.townWins") : t("mf.mafiaWins"))}</h2>
          <p class="status">${esc(message)}</p>
          ${playersListHtml(false).replace(/<small>.*?<\/small>/g, "")}
          <ul class="word-log">${players.map((player, index) => `<li>${esc(name(index))} <span>${esc(roleName(player.role))}${player.alive ? "" : " ✝"}</span></li>`).join("")}</ul>
          <button class="btn primary" data-act="again">${esc(t("mf.again"))}</button>
        </div>`;
    }

    function render() {
      const views = { setup: setupHtml, reveal: revealHtml, night: nightHtml, morning: morningHtml, day: dayHtml, result: resultHtml, over: overHtml };
      root.innerHTML = views[phase]();
    }

    function confirmStep() {
      const step = night.steps[night.index];
      if (step === "mafia") night.victim = picked;
      if (step === "doctor") night.saved = picked;
      if (step === "detective" && night.checked === null) {
        night.checked = picked;
        render();
        return;
      }
      advanceStep();
    }

    function advanceStep() {
      night.index++;
      picked = null;
      if (night.index < night.steps.length) return render();
      const victim = night.victim;
      if (victim !== null && victim !== night.saved) {
        players[victim].alive = false;
        message = t("mf.killed", { name: name(victim) });
      } else message = t("mf.noKill");
      phase = checkWinner() ? "over" : "morning";
      render();
    }

    function excludePlayer(index) {
      if (index === null) message = t("mf.nobody");
      else {
        players[index].alive = false;
        message = showRole
          ? t("mf.excludedRole", { name: name(index), role: roleName(players[index].role) })
          : t("mf.excluded", { name: name(index) });
      }
      picked = null;
      phase = checkWinner() ? "over" : "result";
      render();
    }

    root.addEventListener("input", (event) => {
      if (event.target.id !== "mf-count") return;
      count = Math.min(16, Math.max(5, Number(event.target.value) || 5));
      const comp = composition(count);
      root.querySelector("#mf-comp").textContent = t("mf.roles", { m: comp.mafia, d: comp.doctor, c: comp.citizens });
    });

    root.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      count = Math.min(16, Math.max(5, Number(data.get("count")) || 7));
      showRole = data.has("showRole");
      dealRoles();
      render();
    });

    root.addEventListener("click", (event) => {
      const pick = event.target.closest("[data-pick]");
      if (pick) {
        picked = Number(pick.dataset.pick);
        render();
        return;
      }
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (!act) return;
      if (act === "show") {
        shown = true;
        render();
      } else if (act === "hide") {
        shown = false;
        if (current === players.length - 1) {
          startNight();
        } else current++;
        render();
      } else if (act === "roles") {
        rolesOpen = !rolesOpen;
        render();
      } else if (act === "confirm") {
        if (picked !== null || night.checked !== null) confirmStep();
      } else if (act === "skipstep") {
        advanceStep();
      } else if (act === "toDay") {
        picked = null;
        phase = "day";
        render();
      } else if (act === "exclude") {
        if (picked !== null) excludePlayer(picked);
      } else if (act === "nobody") excludePlayer(null);
      else if (act === "nextNight") {
        startNight();
        render();
      } else if (act === "again") {
        phase = "setup";
        render();
      }
    });

    render();
    return () => {};
  },
};
