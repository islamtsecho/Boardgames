import { esc, register, t } from "../i18n.js";
import { beep, createCountdown, formatClock, shuffle } from "../util.js";
import { wordsFor } from "../words.js";

register({
  ru: {
    "pic.intro": "Один игрок из команды рисует слово на экране, не говоря ни слова. Команда угадывает до конца времени.",
    "pic.teams": "Команд",
    "pic.seconds": "Секунд на рисунок",
    "pic.target": "Играть до очков",
    "pic.start": "Начать игру",
    "pic.team": "Команда {n}",
    "pic.turn": "Рисует команда: {name}",
    "pic.ready": "Художник нажимает кнопку и смотрит на слово. Остальные не должны его видеть.",
    "pic.reveal": "Показать слово художнику",
    "pic.word": "Слово: {word}",
    "pic.begin": "Начать рисовать",
    "pic.guessed": "Угадали! (+1)",
    "pic.skip": "Другое слово",
    "pic.clear": "Очистить",
    "pic.eraser": "Ластик",
    "pic.color": "Цвет",
    "pic.timeUp": "Время вышло, очко не засчитано.",
    "pic.next": "Следующая команда",
    "pic.winner": "Победила команда: {name}",
    "pic.again": "Новая игра",
    "pic.wordWas": "Загаданное слово: {word}",
  },
  en: {
    "pic.intro": "One player from the team draws a word on screen without speaking. The team guesses before time runs out.",
    "pic.teams": "Teams",
    "pic.seconds": "Seconds per drawing",
    "pic.target": "Play to points",
    "pic.start": "Start game",
    "pic.team": "Team {n}",
    "pic.turn": "Drawing team: {name}",
    "pic.ready": "The artist presses the button and looks at the word. Nobody else should see it.",
    "pic.reveal": "Show the word to the artist",
    "pic.word": "Word: {word}",
    "pic.begin": "Start drawing",
    "pic.guessed": "Guessed! (+1)",
    "pic.skip": "Another word",
    "pic.clear": "Clear",
    "pic.eraser": "Eraser",
    "pic.color": "Colour",
    "pic.timeUp": "Time is up, no point awarded.",
    "pic.next": "Next team",
    "pic.winner": "Winning team: {name}",
    "pic.again": "New game",
    "pic.wordWas": "The word was: {word}",
  },
});

const DEFAULTS = { teams: 2, seconds: 60, target: 5 };
const COLORS = ["#1b1b1b", "#d64541", "#2b6c8f", "#2e8b57", "#e0a21b", "#8e44ad"];
const CANVAS_WIDTH = 640;
const CANVAS_HEIGHT = 420;

export const pictionary = {
  id: "pictionary",

  mount(root) {
    let settings = { ...DEFAULTS };
    let phase = "setup";
    let teams = [];
    let turn = 0;
    let deck = [];
    let word = "";
    let clock = null;
    let clockText = "";
    let color = COLORS[0];
    let erasing = false;
    let timedOut = false;

    const teamName = (index) => t("pic.team", { n: index + 1 });

    function stopClock() {
      if (clock) clock.stop();
      clock = null;
    }

    function nextWord() {
      if (deck.length === 0) deck = shuffle(wordsFor("all"));
      word = deck.pop();
    }

    function scoreHtml() {
      return `<div class="scoreboard">${teams
        .map((team, index) => `<div class="player${phase !== "setup" && index === turn ? " active" : ""}">${esc(teamName(index))}<strong>${team.score}</strong></div>`)
        .join("")}</div>`;
    }

    function paletteHtml() {
      const swatches = COLORS.map((value) => `<button class="swatch-btn${!erasing && color === value ? " on" : ""}" data-color="${value}" style="background:${value}" aria-label="${esc(t("pic.color"))}"></button>`).join("");
      return `<div class="palette">${swatches}
        <button class="btn small${erasing ? " primary" : ""}" data-act="eraser">${esc(t("pic.eraser"))}</button>
        <button class="btn small" data-act="clear">${esc(t("pic.clear"))}</button></div>`;
    }

    function setupHtml() {
      return `
        <form class="panel setup" id="pic-form">
          <p class="muted">${esc(t("pic.intro"))}</p>
          <div class="form-row">
            <label class="field"><span>${esc(t("pic.teams"))}</span><input type="number" name="teams" min="2" max="4" value="${settings.teams}"></label>
            <label class="field"><span>${esc(t("pic.seconds"))}</span><input type="number" name="seconds" min="20" max="180" step="5" value="${settings.seconds}"></label>
            <label class="field"><span>${esc(t("pic.target"))}</span><input type="number" name="target" min="1" max="30" value="${settings.target}"></label>
          </div>
          <button class="btn primary" type="submit">${esc(t("pic.start"))}</button>
        </form>`;
    }

    function readyHtml() {
      return `
        ${scoreHtml()}
        <div class="panel center">
          <h2>${esc(t("pic.turn", { name: teamName(turn) }))}</h2>
          <p class="muted">${esc(t("pic.ready"))}</p>
          <button class="btn primary big" data-act="reveal">${esc(t("pic.reveal"))}</button>
        </div>`;
    }

    function seenHtml() {
      return `
        ${scoreHtml()}
        <div class="panel center">
          <div class="role-card word">${esc(word)}</div>
          <button class="btn primary big" data-act="begin">${esc(t("pic.begin"))}</button>
        </div>`;
    }

    function drawHtml() {
      return `
        ${scoreHtml()}
        <div class="panel center">
          <div class="draw-head">
            <span class="muted">${esc(t("pic.word", { word }))}</span>
            <div class="timer-display small" id="pic-clock">${esc(clockText)}</div>
          </div>
          <canvas id="pic-canvas" width="${CANVAS_WIDTH}" height="${CANVAS_HEIGHT}"></canvas>
          ${paletteHtml()}
          <div class="dialog-actions center-actions">
            <button class="btn primary" data-act="ok">${esc(t("pic.guessed"))}</button>
            <button class="btn" data-act="skip">${esc(t("pic.skip"))}</button>
          </div>
        </div>`;
    }

    function betweenHtml() {
      return `
        ${scoreHtml()}
        <div class="panel center">
          <p class="timer-note">${esc(t("pic.timeUp"))}</p>
          <p class="muted">${esc(t("pic.wordWas", { word }))}</p>
          <button class="btn primary" data-act="next">${esc(t("pic.next"))}</button>
        </div>`;
    }

    function overHtml() {
      const top = Math.max(...teams.map((team) => team.score));
      const winners = teams.map((team, index) => (team.score === top ? teamName(index) : null)).filter(Boolean).join(", ");
      return `
        ${scoreHtml()}
        <div class="panel center">
          <h2>${esc(t("pic.winner", { name: winners }))}</h2>
          <button class="btn primary" data-act="again">${esc(t("pic.again"))}</button>
        </div>`;
    }

    function render() {
      const views = { setup: setupHtml, ready: readyHtml, seen: seenHtml, draw: drawHtml, between: betweenHtml, over: overHtml };
      root.innerHTML = views[phase]();
      if (phase === "draw") setupCanvas();
    }

    function setupCanvas() {
      const canvas = root.querySelector("#pic-canvas");
      const context = canvas.getContext("2d");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.lineCap = "round";
      context.lineJoin = "round";
      let drawing = false;
      let last = null;

      const point = (event) => {
        const box = canvas.getBoundingClientRect();
        return [((event.clientX - box.left) / box.width) * canvas.width, ((event.clientY - box.top) / box.height) * canvas.height];
      };
      const stroke = (from, to) => {
        context.strokeStyle = erasing ? "#ffffff" : color;
        context.lineWidth = erasing ? 24 : 4;
        context.beginPath();
        context.moveTo(from[0], from[1]);
        context.lineTo(to[0], to[1]);
        context.stroke();
      };

      canvas.addEventListener("pointerdown", (event) => {
        drawing = true;
        last = point(event);
        canvas.setPointerCapture(event.pointerId);
        stroke(last, [last[0] + 0.01, last[1]]);
      });
      canvas.addEventListener("pointermove", (event) => {
        if (!drawing) return;
        const next = point(event);
        stroke(last, next);
        last = next;
      });
      const stop = () => {
        drawing = false;
      };
      canvas.addEventListener("pointerup", stop);
      canvas.addEventListener("pointercancel", stop);
    }

    function startDrawing() {
      clockText = formatClock(settings.seconds);
      clock = createCountdown(
        settings.seconds,
        (left) => {
          clockText = formatClock(left);
          const element = root.querySelector("#pic-clock");
          if (element) element.textContent = clockText;
        },
        () => {
          beep();
          timedOut = true;
          phase = "between";
          render();
        },
      );
      erasing = false;
      color = COLORS[0];
      phase = "draw";
      render();
      clock.start();
    }

    function advanceTurn() {
      stopClock();
      turn = (turn + 1) % teams.length;
      phase = "ready";
      render();
    }

    function newGame() {
      stopClock();
      teams = Array.from({ length: settings.teams }, () => ({ score: 0 }));
      turn = 0;
      deck = shuffle(wordsFor("all"));
      phase = "ready";
      render();
    }

    root.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      settings = {
        teams: Math.min(4, Math.max(2, Number(data.get("teams")) || 2)),
        seconds: Math.min(180, Math.max(20, Number(data.get("seconds")) || 60)),
        target: Math.min(30, Math.max(1, Number(data.get("target")) || 5)),
      };
      newGame();
    });

    root.addEventListener("click", (event) => {
      const swatch = event.target.closest("[data-color]");
      if (swatch) {
        color = swatch.dataset.color;
        erasing = false;
        root.querySelectorAll(".swatch-btn").forEach((item) => item.classList.toggle("on", item === swatch));
        root.querySelector("[data-act=eraser]").classList.remove("primary");
        return;
      }
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "reveal") {
        nextWord();
        phase = "seen";
        render();
      } else if (act === "begin") startDrawing();
      else if (act === "eraser") {
        erasing = !erasing;
        event.target.closest("[data-act]").classList.toggle("primary", erasing);
        root.querySelectorAll(".swatch-btn").forEach((item) => item.classList.toggle("on", !erasing && item.dataset.color === color));
      } else if (act === "clear") {
        const canvas = root.querySelector("#pic-canvas");
        const context = canvas.getContext("2d");
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
      } else if (act === "skip") {
        nextWord();
        root.querySelector(".draw-head .muted").textContent = t("pic.word", { word });
      } else if (act === "ok") {
        stopClock();
        teams[turn].score++;
        if (teams[turn].score >= settings.target) {
          phase = "over";
          render();
        } else advanceTurn();
      } else if (act === "next") advanceTurn();
      else if (act === "again") {
        phase = "setup";
        render();
      }
    });

    render();
    return stopClock;
  },
};
