const SIZE = 8;
const DIRECTIONS = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];

const WEIGHTS = [
  100, -20, 10, 5, 5, 10, -20, 100,
  -20, -50, -2, -2, -2, -2, -50, -20,
  10, -2, 1, 1, 1, 1, -2, 10,
  5, -2, 1, 0, 0, 1, -2, 5,
  5, -2, 1, 0, 0, 1, -2, 5,
  10, -2, 1, 1, 1, 1, -2, 10,
  -20, -50, -2, -2, -2, -2, -50, -20,
  100, -20, 10, 5, 5, 10, -20, 100,
];

function flipsFor(board, index, player) {
  if (board[index] !== 0) return [];
  const row = Math.floor(index / SIZE);
  const col = index % SIZE;
  const flips = [];
  for (const [dr, dc] of DIRECTIONS) {
    const line = [];
    let r = row + dr;
    let c = col + dc;
    while (r >= 0 && r < SIZE && c >= 0 && c < SIZE && board[r * SIZE + c] === 3 - player) {
      line.push(r * SIZE + c);
      r += dr;
      c += dc;
    }
    if (line.length && r >= 0 && r < SIZE && c >= 0 && c < SIZE && board[r * SIZE + c] === player) {
      flips.push(...line);
    }
  }
  return flips;
}

function legalMoves(board, player) {
  const result = [];
  for (let index = 0; index < SIZE * SIZE; index++) {
    if (flipsFor(board, index, player).length) result.push(index);
  }
  return result;
}

function count(board, player) {
  return board.filter((value) => value === player).length;
}

function moves(state) {
  return state.over ? [] : legalMoves(state.board, state.turn);
}

function result(state) {
  if (!state.over) return null;
  const black = count(state.board, 1);
  const white = count(state.board, 2);
  if (black === white) return "draw";
  return black > white ? 1 : 2;
}

export const reversi = {
  id: "reversi",
  depths: [1, 3, 4],
  names: { ru: ["Чёрные", "Белые"], en: ["Black", "White"] },

  init() {
    const board = Array(SIZE * SIZE).fill(0);
    board[3 * SIZE + 3] = 2;
    board[4 * SIZE + 4] = 2;
    board[3 * SIZE + 4] = 1;
    board[4 * SIZE + 3] = 1;
    return { board, turn: 1, over: false, last: null };
  },

  moves,
  result,

  play(state, index) {
    const board = state.board.slice();
    for (const flipped of flipsFor(board, index, state.turn)) board[flipped] = state.turn;
    board[index] = state.turn;
    const opponent = 3 - state.turn;
    if (legalMoves(board, opponent).length) return { board, turn: opponent, over: false, last: index };
    if (legalMoves(board, state.turn).length) return { board, turn: state.turn, over: false, last: index };
    return { board, turn: opponent, over: true, last: index };
  },

  score(state, player) {
    let total = 0;
    state.board.forEach((value, index) => {
      if (value === player) total += WEIGHTS[index];
      else if (value !== 0) total -= WEIGHTS[index];
    });
    const mine = legalMoves(state.board, player).length;
    const theirs = legalMoves(state.board, 3 - player).length;
    return total + (mine - theirs) * 5;
  },

  click(state, cell) {
    return moves(state).includes(cell) ? { move: cell } : null;
  },

  stats(state) {
    return [count(state.board, 1), count(state.board, 2)];
  },

  render(state, view) {
    const legal = view.interactive ? moves(state) : [];
    const cells = state.board.map((value, index) => {
      const classes = ["rv-cell"];
      if (state.last === index) classes.push("last");
      if (legal.includes(index)) classes.push("playable");
      const disc = value ? `<span class="disc disc-${value}"></span>` : "";
      return `<button class="${classes.join(" ")}" data-cell="${index}">${disc}</button>`;
    });
    return `<div class="board rv">${cells.join("")}</div>`;
  },
};
