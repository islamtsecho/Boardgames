import { esc, register, t } from "../i18n.js";
import { randInt } from "../util.js";

register({
  ru: {
    "mm.intro": "Компьютер загадал код из четырёх цветов (цвета могут повторяться). У вас 10 попыток. Чёрная точка: цвет угадан и стоит на своём месте, белая: цвет есть в коде, но стоит не там.",
    "mm.check": "Проверить",
    "mm.attempt": "Попытка {n} из {max}",
    "mm.win": "Код разгадан за {n} поп.!",
    "mm.lose": "Попытки закончились. Вот загаданный код:",
    "mm.again": "Новая игра",
    "mm.clear": "Сбросить ряд",
    "mm.pick": "Выберите цвет, затем нажимайте на ячейки ряда. Нажатие на заполненную ячейку очищает её.",
    "mm.secret": "Загаданный код",
  },
  en: {
    "mm.intro": "The computer has set a code of four colours (colours may repeat). You have 10 attempts. A black peg: right colour in the right place; a white peg: the colour is in the code but in the wrong place.",
    "mm.check": "Check",
    "mm.attempt": "Attempt {n} of {max}",
    "mm.win": "Code cracked in {n} attempts!",
    "mm.lose": "Out of attempts. The secret code was:",
    "mm.again": "New game",
    "mm.clear": "Clear row",
    "mm.pick": "Pick a colour, then click the cells of the row. Clicking a filled cell clears it.",
    "mm.secret": "Secret code",
  },
});

const COLORS = ["#d64541", "#f0c030", "#2e8b57", "#2b6c8f", "#8e44ad", "#e67e22"];
const LENGTH = 4;
const MAX_ATTEMPTS = 10;

export function feedback(secret, guess) {
  let exact = 0;
  const secretLeft = [];
  const guessLeft = [];
  for (let i = 0; i < LENGTH; i++) {
    if (secret[i] === guess[i]) exact++;
    else {
      secretLeft.push(secret[i]);
      guessLeft.push(guess[i]);
    }
  }
  let colour = 0;
  for (const value of guessLeft) {
    const found = secretLeft.indexOf(value);
    if (found >= 0) {
      colour++;
      secretLeft.splice(found, 1);
    }
  }
  return { exact, colour };
}

export const mastermind = {
  id: "mastermind",

  mount(root) {
    let secret;
    let history;
    let row;
    let selected;
    let status;

    function newGame() {
      secret = Array.from({ length: LENGTH }, () => randInt(COLORS.length));
      history = [];
      row = Array(LENGTH).fill(null);
      selected = 0;
      status = "playing";
    }

    function pegsHtml(result) {
      const pegs = [...Array(result.exact).fill("black"), ...Array(result.colour).fill("white"), ...Array(LENGTH - result.exact - result.colour).fill("none")];
      return `<div class="pegs">${pegs.map((peg) => `<i class="peg ${peg}"></i>`).join("")}</div>`;
    }

    function dots(code, cls = "") {
      return code.map((value) => `<i class="mm-dot ${cls}" style="background:${COLORS[value]}"></i>`).join("");
    }

    function render() {
      const past = history.map((entry) => `<div class="mm-row">${dots(entry.guess)}${pegsHtml(entry.result)}</div>`).join("");
      const palette = COLORS.map((color, index) => `<button class="mm-pick${selected === index ? " on" : ""}" data-color="${index}" style="background:${color}" aria-label="${index + 1}"></button>`).join("");
      let footer;
      if (status === "playing") {
        const ready = row.every((value) => value !== null);
        const slots = row.map((value, index) => `<button class="mm-slot" data-slot="${index}"${value !== null ? ` style="background:${COLORS[value]}"` : ""}></button>`).join("");
        footer = `
          <p class="status">${esc(t("mm.attempt", { n: history.length + 1, max: MAX_ATTEMPTS }))}</p>
          <div class="mm-row current">${slots}
            <button class="btn primary small" data-act="check"${ready ? "" : " disabled"}>${esc(t("mm.check"))}</button>
          </div>
          <div class="mm-palette">${palette}<button class="btn small" data-act="clear">${esc(t("mm.clear"))}</button></div>
          <p class="hint">${esc(t("mm.pick"))}</p>`;
      } else {
        const text = status === "won" ? t("mm.win", { n: history.length }) : t("mm.lose");
        footer = `
          <p class="status${status === "won" ? " finished" : ""}">${esc(text)}</p>
          <div class="mm-row secret">${dots(secret)}</div>
          <button class="btn primary" data-act="again">${esc(t("mm.again"))}</button>`;
      }
      root.innerHTML = `
        <div class="panel center mind">
          <p class="muted">${esc(t("mm.intro"))}</p>
          <div class="mm-history">${past}</div>
          ${footer}
        </div>`;
    }

    root.addEventListener("click", (event) => {
      const color = event.target.closest("[data-color]");
      if (color) {
        selected = Number(color.dataset.color);
        render();
        return;
      }
      const slot = event.target.closest("[data-slot]");
      if (slot && status === "playing") {
        const index = Number(slot.dataset.slot);
        row[index] = row[index] === null ? selected : null;
        render();
        return;
      }
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "clear") row = Array(LENGTH).fill(null);
      else if (act === "again") newGame();
      else if (act === "check" && row.every((value) => value !== null)) {
        const result = feedback(secret, row);
        history.push({ guess: row, result });
        if (result.exact === LENGTH) status = "won";
        else if (history.length >= MAX_ATTEMPTS) status = "lost";
        row = Array(LENGTH).fill(null);
      } else return;
      render();
    });

    newGame();
    render();
    return () => {};
  },
};
