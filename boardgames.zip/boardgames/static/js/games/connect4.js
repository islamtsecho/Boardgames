const ROWS = 6;
const COLS = 7;
const COLUMN_ORDER = [3, 2, 4, 1, 5, 0, 6];
const DIRECTIONS = [[0, 1], [1, 0], [1, 1], [1, -1]];

function lowestFreeRow(board, col) {
  for (let row = ROWS - 1; row >= 0; row--) {
    if (board[row * COLS + col] === 0) return row;
  }
  return -1;
}

function moves(state) {
  return COLUMN_ORDER.filter((col) => state.board[col] === 0);
}

function findWinner(board) {
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const value = board[row * COLS + col];
      if (value === 0) continue;
      for (const [dr, dc] of DIRECTIONS) {
        const cells = [[row, col]];
        for (let step = 1; step < 4; step++) {
          const r = row + dr * step;
          const c = col + dc * step;
          if (r < 0 || r >= ROWS || c < 0 || c >= COLS || board[r * COLS + c] !== value) break;
          cells.push([r, c]);
        }
        if (cells.length === 4) return { player: value, cells: cells.map(([r, c]) => r * COLS + c) };
      }
    }
  }
  return null;
}

function result(state) {
  const winner = findWinner(state.board);
  if (winner) return winner.player;
  return moves(state).length === 0 ? "draw" : null;
}

function score(state, player) {
  const opponent = 3 - player;
  const board = state.board;
  let total = 0;
  for (let row = 0; row < ROWS; row++) {
    if (board[row * COLS + 3] === player) total += 3;
    if (board[row * COLS + 3] === opponent) total -= 3;
  }
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      for (const [dr, dc] of DIRECTIONS) {
        const endRow = row + dr * 3;
        const endCol = col + dc * 3;
        if (endRow < 0 || endRow >= ROWS || endCol < 0 || endCol >= COLS) continue;
        let mine = 0;
        let theirs = 0;
        for (let step = 0; step < 4; step++) {
          const value = board[(row + dr * step) * COLS + col + dc * step];
          if (value === player) mine++;
          else if (value === opponent) theirs++;
        }
        if (mine > 0 && theirs > 0) continue;
        if (mine === 3) total += 5;
        else if (mine === 2) total += 2;
        if (theirs === 3) total -= 5;
        else if (theirs === 2) total -= 2;
      }
    }
  }
  return total;
}

export const connect4 = {
  id: "connect4",
  depths: [2, 4, 6],
  names: { ru: ["Красные", "Жёлтые"], en: ["Red", "Yellow"] },

  init() {
    return { board: Array(ROWS * COLS).fill(0), turn: 1, last: null };
  },

  moves,
  result,
  score,

  play(state, col) {
    const board = state.board.slice();
    const row = lowestFreeRow(board, col);
    board[row * COLS + col] = state.turn;
    return { board, turn: 3 - state.turn, last: row * COLS + col };
  },

  click(state, cell) {
    const col = cell % COLS;
    return moves(state).includes(col) ? { move: col } : null;
  },

  stats() {
    return null;
  },

  render(state, view) {
    const winner = findWinner(state.board);
    const winCells = winner ? winner.cells : [];
    const legal = view.interactive ? moves(state) : [];
    const cells = state.board.map((value, index) => {
      const classes = ["c4-cell"];
      if (value) classes.push("disc-" + value);
      if (state.last === index) classes.push("last");
      if (winCells.includes(index)) classes.push("win");
      if (legal.includes(index % COLS)) classes.push("playable");
      return `<button class="${classes.join(" ")}" data-cell="${index}" aria-label="${index % COLS + 1}"></button>`;
    });
    return `<div class="board c4">${cells.join("")}</div>`;
  },
};
