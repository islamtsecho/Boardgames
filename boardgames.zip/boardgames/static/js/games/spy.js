import { esc, register, t } from "../i18n.js";
import { THEME_IDS, parseCustomWords, wordsFor } from "../words.js";
import { beep, createCountdown, formatClock, pickRandom, randInt, shuffle } from "../util.js";

register({
  ru: {
    "spy.intro": "Все получают одно секретное слово, кроме шпионов. Задавайте друг другу вопросы и вычисляйте шпиона, а шпион пытается не выдать себя и угадать слово.",
    "spy.players": "Игроков",
    "spy.spies": "Шпионов",
    "spy.minutes": "Время обсуждения, мин",
    "spy.theme": "Тема слов",
    "spy.theme.all": "Все темы вперемешку",
    "spy.theme.custom": "Своя тема",
    "spy.customName": "Название своей темы",
    "spy.customWords": "Свои слова (через запятую или с новой строки)",
    "spy.customDefault": "Моя тема",
    "spy.spyKnows": "Шпион знает тему",
    "spy.start": "Начать игру",
    "spy.errCustom": "Введите хотя бы два разных слова.",
    "spy.player": "Игрок {n}",
    "spy.pass": "Передайте устройство:",
    "spy.progress": "{n} из {total}",
    "spy.show": "Показать роль",
    "spy.hide": "Скрыть и передать дальше",
    "spy.hideLast": "Скрыть и начать игру",
    "spy.youSpy": "Ты — шпион",
    "spy.spyHintTheme": "Тема: {theme}. Слово тебе неизвестно: слушай и постарайся не выдать себя.",
    "spy.spyHint": "Тема и слово тебе неизвестны: слушай и постарайся не выдать себя.",
    "spy.secretWord": "Секретное слово",
    "spy.themeIs": "Тема: {theme}",
    "spy.first": "Первым задаёт вопрос: {name}",
    "spy.discuss": "Задавайте вопросы по очереди и отвечайте так, чтобы не выдать слово шпиону. Когда будете готовы, голосуйте.",
    "spy.timeUp": "Время вышло! Голосуйте за шпиона.",
    "spy.timerStart": "Запустить таймер",
    "spy.timerPause": "Пауза",
    "spy.reveal": "Показать ответ",
    "spy.again": "Новый раунд",
    "spy.settings": "Настройки",
    "spy.spiesWere": "Шпионы: {names}",
    "spy.wordWas": "Слово: {word}",
    "spy.themeWas": "Тема: {theme}",
  },
  en: {
    "spy.intro": "Everyone gets the same secret word except the spies. Ask each other questions to find the spy, while the spy tries to blend in and guess the word.",
    "spy.players": "Players",
    "spy.spies": "Spies",
    "spy.minutes": "Discussion time, min",
    "spy.theme": "Word theme",
    "spy.theme.all": "All themes mixed",
    "spy.theme.custom": "Custom theme",
    "spy.customName": "Custom theme name",
    "spy.customWords": "Your words (comma or new line separated)",
    "spy.customDefault": "My theme",
    "spy.spyKnows": "Spy knows the theme",
    "spy.start": "Start game",
    "spy.errCustom": "Enter at least two different words.",
    "spy.player": "Player {n}",
    "spy.pass": "Pass the device to:",
    "spy.progress": "{n} of {total}",
    "spy.show": "Show role",
    "spy.hide": "Hide and pass on",
    "spy.hideLast": "Hide and start the game",
    "spy.youSpy": "You are the spy",
    "spy.spyHintTheme": "Theme: {theme}. You don't know the word: listen and try not to give yourself away.",
    "spy.spyHint": "You know neither the theme nor the word: listen and try not to give yourself away.",
    "spy.secretWord": "Secret word",
    "spy.themeIs": "Theme: {theme}",
    "spy.first": "Asks the first question: {name}",
    "spy.discuss": "Take turns asking questions, answering without giving the word away to the spy. When you are ready, vote.",
    "spy.timeUp": "Time is up! Vote for the spy.",
    "spy.timerStart": "Start timer",
    "spy.timerPause": "Pause",
    "spy.reveal": "Show the answer",
    "spy.again": "New round",
    "spy.settings": "Settings",
    "spy.spiesWere": "Spies: {names}",
    "spy.wordWas": "Word: {word}",
    "spy.themeWas": "Theme: {theme}",
  },
});

const DEFAULTS = { players: 5, spies: 1, minutes: 8, theme: "places", customName: "", customWords: "", spyKnows: true };

function themeLabel(settings, themeId) {
  if (themeId === "custom") return settings.customName || t("spy.customDefault");
  return t("theme." + themeId);
}

function pickRound(settings) {
  let themeId = settings.theme;
  let words;
  if (themeId === "custom") words = parseCustomWords(settings.customWords);
  else {
    if (themeId === "all") themeId = pickRandom(THEME_IDS);
    words = wordsFor(themeId);
  }
  const spies = new Set(shuffle([...Array(settings.players).keys()]).slice(0, settings.spies));
  return {
    word: pickRandom(words),
    themeId,
    spies,
    first: randInt(settings.players),
  };
}

export const spy = {
  id: "spy",

  mount(root) {
    let settings = { ...DEFAULTS };
    let round = null;
    let phase = "setup";
    let current = 0;
    let shown = false;
    let error = "";
    let clock = null;
    let clockText = "";
    let timeUp = false;

    const name = (index) => t("spy.player", { n: index + 1 });

    function stopClock() {
      if (clock) clock.stop();
      clock = null;
    }

    function themeOptions() {
      const options = THEME_IDS.map((id) => [id, t("theme." + id)]);
      options.push(["all", t("spy.theme.all")], ["custom", t("spy.theme.custom")]);
      return options
        .map(([id, label]) => `<option value="${id}"${settings.theme === id ? " selected" : ""}>${esc(label)}</option>`)
        .join("");
    }

    function setupHtml() {
      const custom = settings.theme === "custom";
      return `
        <form class="panel setup" id="spy-form">
          <p class="muted">${esc(t("spy.intro"))}</p>
          <div class="form-row">
            <label class="field"><span>${esc(t("spy.players"))}</span><input type="number" name="players" min="3" max="12" value="${settings.players}"></label>
            <label class="field"><span>${esc(t("spy.spies"))}</span><input type="number" name="spies" min="1" max="3" value="${settings.spies}"></label>
            <label class="field"><span>${esc(t("spy.minutes"))}</span><input type="number" name="minutes" min="1" max="30" value="${settings.minutes}"></label>
          </div>
          <label class="field"><span>${esc(t("spy.theme"))}</span><select name="theme" id="spy-theme">${themeOptions()}</select></label>
          <div class="custom-theme"${custom ? "" : " hidden"}>
            <label class="field"><span>${esc(t("spy.customName"))}</span><input name="customName" value="${esc(settings.customName)}"></label>
            <label class="field"><span>${esc(t("spy.customWords"))}</span><textarea name="customWords" rows="4">${esc(settings.customWords)}</textarea></label>
          </div>
          <label class="check"><input type="checkbox" name="spyKnows"${settings.spyKnows ? " checked" : ""}> ${esc(t("spy.spyKnows"))}</label>
          <p class="form-error" role="alert">${esc(error)}</p>
          <button class="btn primary" type="submit">${esc(t("spy.start"))}</button>
        </form>`;
    }

    function revealHtml() {
      const isSpy = round.spies.has(current);
      const last = current === settings.players - 1;
      let card;
      if (!shown) {
        card = `<button class="btn primary big" data-act="show">${esc(t("spy.show"))}</button>`;
      } else if (isSpy) {
        const hint = settings.spyKnows ? t("spy.spyHintTheme", { theme: themeLabel(settings, round.themeId) }) : t("spy.spyHint");
        card = `
          <div class="role-card spy">${esc(t("spy.youSpy"))}</div>
          <p class="muted">${esc(hint)}</p>
          <button class="btn primary" data-act="hide">${esc(last ? t("spy.hideLast") : t("spy.hide"))}</button>`;
      } else {
        card = `
          <div class="role-card"><small>${esc(t("spy.secretWord"))}</small>${esc(round.word)}</div>
          <p class="muted">${esc(t("spy.themeIs", { theme: themeLabel(settings, round.themeId) }))}</p>
          <button class="btn primary" data-act="hide">${esc(last ? t("spy.hideLast") : t("spy.hide"))}</button>`;
      }
      return `
        <div class="panel center">
          <p class="muted">${esc(t("spy.pass"))}</p>
          <h2>${esc(name(current))}</h2>
          <p class="muted">${esc(t("spy.progress", { n: current + 1, total: settings.players }))}</p>
          ${card}
        </div>`;
    }

    function playHtml() {
      const running = clock && clock.isRunning();
      return `
        <div class="panel center">
          <p>${esc(t("spy.first", { name: name(round.first) }))}</p>
          <div class="timer-display${timeUp ? " finished" : ""}" id="spy-clock">${esc(clockText)}</div>
          <p class="timer-note" id="spy-note">${timeUp ? esc(t("spy.timeUp")) : ""}</p>
          <p class="muted">${esc(t("spy.discuss"))}</p>
          <div class="dialog-actions center-actions">
            <button class="btn" data-act="clock">${esc(running ? t("spy.timerPause") : t("spy.timerStart"))}</button>
            <button class="btn primary" data-act="reveal">${esc(t("spy.reveal"))}</button>
          </div>
        </div>`;
    }

    function resultHtml() {
      const names = [...round.spies].sort((a, b) => a - b).map(name).join(", ");
      return `
        <div class="panel center">
          <h2>${esc(t("spy.spiesWere", { names }))}</h2>
          <div class="role-card"><small>${esc(t("spy.themeWas", { theme: themeLabel(settings, round.themeId) }))}</small>${esc(round.word)}</div>
          <div class="dialog-actions center-actions">
            <button class="btn primary" data-act="again">${esc(t("spy.again"))}</button>
            <button class="btn" data-act="settings">${esc(t("spy.settings"))}</button>
          </div>
        </div>`;
    }

    function render() {
      const views = { setup: setupHtml, reveal: revealHtml, play: playHtml, result: resultHtml };
      root.innerHTML = views[phase]();
    }

    function startRound() {
      stopClock();
      round = pickRound(settings);
      current = 0;
      shown = false;
      timeUp = false;
      phase = "reveal";
      render();
    }

    function startDiscussion() {
      clockText = formatClock(settings.minutes * 60);
      clock = createCountdown(
        settings.minutes * 60,
        (left) => {
          clockText = formatClock(left);
          const element = root.querySelector("#spy-clock");
          if (element) element.textContent = clockText;
        },
        () => {
          timeUp = true;
          beep();
          if (phase === "play") render();
        },
      );
      phase = "play";
      render();
    }

    function readSettings(form) {
      const data = new FormData(form);
      const players = Math.min(12, Math.max(3, Number(data.get("players")) || DEFAULTS.players));
      const maxSpies = Math.max(1, Math.min(3, Math.floor((players - 1) / 2)));
      settings = {
        players,
        spies: Math.min(maxSpies, Math.max(1, Number(data.get("spies")) || 1)),
        minutes: Math.min(30, Math.max(1, Number(data.get("minutes")) || DEFAULTS.minutes)),
        theme: data.get("theme"),
        customName: String(data.get("customName") || "").trim(),
        customWords: String(data.get("customWords") || ""),
        spyKnows: data.has("spyKnows"),
      };
    }

    function onSubmit(event) {
      event.preventDefault();
      readSettings(event.target);
      if (settings.theme === "custom" && parseCustomWords(settings.customWords).length < 2) {
        error = t("spy.errCustom");
        render();
        return;
      }
      error = "";
      startRound();
    }

    function onChange(event) {
      if (event.target.id !== "spy-theme") return;
      root.querySelector(".custom-theme").hidden = event.target.value !== "custom";
    }

    function onClick(event) {
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (!act) return;
      if (act === "show") {
        shown = true;
        render();
      } else if (act === "hide") {
        shown = false;
        if (current === settings.players - 1) startDiscussion();
        else {
          current++;
          render();
        }
      } else if (act === "clock") {
        if (clock.isRunning()) clock.stop();
        else clock.start();
        render();
      } else if (act === "reveal") {
        stopClock();
        phase = "result";
        render();
      } else if (act === "again") startRound();
      else if (act === "settings") {
        stopClock();
        phase = "setup";
        render();
      }
    }

    root.addEventListener("submit", onSubmit);
    root.addEventListener("change", onChange);
    root.addEventListener("click", onClick);
    render();
    return () => stopClock();
  },
};
