import { esc, register, t } from "../i18n.js";
import { randInt } from "../util.js";

register({
  ru: {
    "sl.intro": "Бросайте кубик и двигайтесь к клетке 100. Лестницы поднимают, змеи сбрасывают вниз. До 100 нужно дойти точным броском, а выпавшая шестёрка даёт ещё один бросок.",
    "sl.players": "Игроков",
    "sl.bots": "Из них компьютеров",
    "sl.start": "Начать игру",
    "sl.player": "Игрок {n}",
    "sl.bot": "Компьютер {n}",
    "sl.turn": "Ход: {name}",
    "sl.roll": "Бросить кубик",
    "sl.rolled": "{name} выбросил {n}.",
    "sl.moved": "Фишка идёт на клетку {to}.",
    "sl.stay": "Нужен точный бросок, остаётся на {to}.",
    "sl.ladder": "Лестница! {from} → {to}.",
    "sl.snake": "Змея! {from} → {to}.",
    "sl.again6": "Шестёрка: бросок ещё раз.",
    "sl.win": "Победил: {name}!",
    "sl.new": "Новая игра",
  },
  en: {
    "sl.intro": "Roll the die and race to square 100. Ladders lift you up, snakes slide you down. You need an exact roll to land on 100, and a six gives another roll.",
    "sl.players": "Players",
    "sl.bots": "Of them computers",
    "sl.start": "Start game",
    "sl.player": "Player {n}",
    "sl.bot": "Computer {n}",
    "sl.turn": "Turn: {name}",
    "sl.roll": "Roll the die",
    "sl.rolled": "{name} rolled {n}.",
    "sl.moved": "The token moves to square {to}.",
    "sl.stay": "An exact roll is needed, staying on {to}.",
    "sl.ladder": "Ladder! {from} → {to}.",
    "sl.snake": "Snake! {from} → {to}.",
    "sl.again6": "A six: roll again.",
    "sl.win": "Winner: {name}!",
    "sl.new": "New game",
  },
});

const JUMPS = {
  4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91,
  17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78,
};
const COLORS = ["#d64541", "#2b6c8f", "#2e8b57", "#e0a21b", "#8e44ad", "#e67e22"];
const FACES = ["", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
const BOT_DELAY = 800;

export function step(position, roll) {
  const target = position + roll;
  if (target > 100) return { to: position, stayed: true, jump: null };
  const jumped = JUMPS[target];
  return { to: jumped ?? target, stayed: false, jump: jumped === undefined ? null : { from: target, to: jumped } };
}

function cellNumber(visualRow, col) {
  const rowFromBottom = 9 - visualRow;
  return rowFromBottom * 10 + (rowFromBottom % 2 === 0 ? col + 1 : 10 - col);
}

export const snakes = {
  id: "snakes",

  mount(root) {
    let settings = { players: 2, bots: 1 };
    let game = null;
    let timer = null;
    let disposed = false;

    const name = (index) => (game.players[index].bot
      ? t("sl.bot", { n: index + 1 })
      : t("sl.player", { n: index + 1 }));

    function newGame() {
      clearTimeout(timer);
      const humans = settings.players - settings.bots;
      game = {
        players: Array.from({ length: settings.players }, (_, index) => ({ position: 0, bot: index >= humans })),
        turn: 0,
        die: 0,
        message: "",
        winner: null,
      };
      scheduleBot();
    }

    function boardHtml() {
      const rows = [];
      for (let row = 0; row < 10; row++) {
        for (let col = 0; col < 10; col++) {
          const number = cellNumber(row, col);
          const jump = JUMPS[number];
          const classes = ["sl-cell"];
          if (jump !== undefined) classes.push(jump > number ? "ladder" : "snake");
          const tokens = game.players
            .map((player, index) => (player.position === number ? `<i class="sl-token" style="background:${COLORS[index]}"></i>` : ""))
            .join("");
          const badge = jump === undefined ? "" : `<small>${jump > number ? "▲" : "▼"} ${jump}</small>`;
          rows.push(`<div class="${classes.join(" ")}"><span>${number}</span>${badge}<div class="sl-tokens">${tokens}</div></div>`);
        }
      }
      return `<div class="board sl">${rows.join("")}</div>`;
    }

    function setupHtml() {
      return `
        <form class="panel setup" id="sl-form">
          <p class="muted">${esc(t("sl.intro"))}</p>
          <div class="form-row">
            <label class="field"><span>${esc(t("sl.players"))}</span><input type="number" name="players" min="2" max="6" value="${settings.players}"></label>
            <label class="field"><span>${esc(t("sl.bots"))}</span><input type="number" name="bots" min="0" max="5" value="${settings.bots}"></label>
          </div>
          <button class="btn primary" type="submit">${esc(t("sl.start"))}</button>
        </form>`;
    }

    function render() {
      if (!game) {
        root.innerHTML = setupHtml();
        return;
      }
      const current = game.players[game.turn];
      const list = game.players
        .map((player, index) => `<div class="player${!game.winner && index === game.turn ? " active" : ""}"><span class="swatch" style="background:${COLORS[index]}"></span>${esc(name(index))}<strong>${player.position || "–"}</strong></div>`)
        .join("");
      const status = game.winner !== null ? t("sl.win", { name: name(game.winner) }) : t("sl.turn", { name: name(game.turn) });
      const canRoll = game.winner === null && !current.bot;
      root.innerHTML = `
        <div class="play-area">
          <div class="play-side">
            <div class="status${game.winner !== null ? " finished" : ""}">${esc(status)}</div>
            <div class="scoreboard">${list}</div>
            <div class="die" aria-live="polite">${FACES[game.die] || ""}</div>
            <button class="btn primary" data-act="roll"${canRoll ? "" : " disabled"}>${esc(t("sl.roll"))}</button>
            <p class="hint">${esc(game.message)}</p>
            <button class="btn ghost" data-act="new">${esc(t("sl.new"))}</button>
          </div>
          <div class="board-holder">${boardHtml()}</div>
        </div>`;
    }

    function roll() {
      if (game.winner !== null) return;
      const value = 1 + randInt(6);
      const player = game.players[game.turn];
      const outcome = step(player.position, value);
      const lines = [t("sl.rolled", { name: name(game.turn), n: value })];
      if (outcome.stayed) lines.push(t("sl.stay", { to: player.position || 1 }));
      else if (outcome.jump) {
        lines.push(t(outcome.jump.to > outcome.jump.from ? "sl.ladder" : "sl.snake", outcome.jump));
      } else lines.push(t("sl.moved", { to: outcome.to }));
      player.position = outcome.to;
      game.die = value;
      if (player.position === 100) {
        game.winner = game.turn;
      } else if (value === 6) {
        lines.push(t("sl.again6"));
      } else {
        game.turn = (game.turn + 1) % game.players.length;
      }
      game.message = lines.join(" ");
      render();
      scheduleBot();
    }

    function scheduleBot() {
      if (disposed || !game || game.winner !== null || !game.players[game.turn].bot) return;
      timer = setTimeout(roll, BOT_DELAY);
    }

    root.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      const players = Math.min(6, Math.max(2, Number(data.get("players")) || 2));
      settings = { players, bots: Math.min(players - 1, Math.max(0, Number(data.get("bots")) || 0)) };
      newGame();
      render();
    });

    root.addEventListener("click", (event) => {
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "roll" && game && !game.players[game.turn].bot) roll();
      else if (act === "new") {
        clearTimeout(timer);
        game = null;
        render();
      }
    });

    render();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  },
};
