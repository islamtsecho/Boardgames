import { renderCatalog } from "./catalog.js";
import { getLang, setLang, t } from "./i18n.js";
import { renderHelper } from "./helper.js";
import { leavePlay, renderPlay } from "./play.js";
import { renderTools } from "./tools.js";

const app = document.getElementById("app");

function parseRoute() {
  const [, page = "", param = ""] = location.hash.replace(/^#/, "").split("/");
  return { page, param };
}

function applyStaticText() {
  document.title = t("app.title");
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    element.textContent = t(element.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-label]").forEach((element) => {
    element.setAttribute("aria-label", t(element.dataset.i18nLabel));
    element.title = t(element.dataset.i18nLabel);
  });
  document.getElementById("lang-toggle").textContent = getLang() === "ru" ? "EN" : "RU";
}

function render() {
  const { page, param } = parseRoute();
  document.querySelectorAll(".nav a").forEach((link) => {
    const on = link.dataset.page === (page || "catalog") || (page === "helper" && link.dataset.page === "play");
    link.classList.toggle("active", on);
    if (on) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  applyStaticText();
  if (page !== "play") leavePlay();
  if (page === "play") renderPlay(app, param);
  else if (page === "tools") renderTools(app);
  else if (page === "helper") renderHelper(app, param);
  else renderCatalog(app);
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try {
    localStorage.setItem("theme", theme);
  } catch {}
}

document.getElementById("theme-toggle").addEventListener("click", () => {
  const current = document.documentElement.dataset.theme;
  applyTheme(current === "dark" ? "light" : "dark");
});

document.getElementById("lang-toggle").addEventListener("click", () => {
  setLang(getLang() === "ru" ? "en" : "ru");
  render();
});

window.addEventListener("hashchange", render);
render();
