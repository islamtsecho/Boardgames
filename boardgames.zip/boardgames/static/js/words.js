import { getLang, register } from "./i18n.js";

const THEMES = {
  places: {
    ru: ["Аэропорт", "Больница", "Библиотека", "Кинотеатр", "Школа", "Цирк", "Музей", "Банк", "Пляж", "Вокзал", "Ресторан", "Стадион", "Зоопарк", "Университет", "Супермаркет", "Театр", "Парк аттракционов", "Космодром", "Подводная лодка", "Замок"],
    en: ["Airport", "Hospital", "Library", "Cinema", "School", "Circus", "Museum", "Bank", "Beach", "Train station", "Restaurant", "Stadium", "Zoo", "University", "Supermarket", "Theatre", "Amusement park", "Spaceport", "Submarine", "Castle"],
  },
  food: {
    ru: ["Пицца", "Борщ", "Суши", "Блины", "Шоколад", "Мороженое", "Пельмени", "Салат Цезарь", "Бургер", "Омлет", "Шашлык", "Лазанья", "Тирамису", "Плов", "Круассан", "Паста", "Хот-дог", "Чизкейк", "Окрошка", "Гречка"],
    en: ["Pizza", "Borscht", "Sushi", "Pancakes", "Chocolate", "Ice cream", "Dumplings", "Caesar salad", "Burger", "Omelette", "Kebab", "Lasagna", "Tiramisu", "Pilaf", "Croissant", "Pasta", "Hot dog", "Cheesecake", "Cold soup", "Buckwheat"],
  },
  professions: {
    ru: ["Врач", "Пожарный", "Учитель", "Программист", "Пилот", "Повар", "Космонавт", "Архитектор", "Журналист", "Юрист", "Художник", "Электрик", "Продавец", "Полицейский", "Фермер", "Водитель", "Режиссёр", "Ветеринар", "Музыкант", "Строитель"],
    en: ["Doctor", "Firefighter", "Teacher", "Programmer", "Pilot", "Chef", "Astronaut", "Architect", "Journalist", "Lawyer", "Painter", "Electrician", "Shop assistant", "Police officer", "Farmer", "Driver", "Film director", "Vet", "Musician", "Builder"],
  },
  animals: {
    ru: ["Слон", "Жираф", "Пингвин", "Крокодил", "Медведь", "Дельфин", "Кенгуру", "Сова", "Волк", "Акула", "Хамелеон", "Панда", "Лиса", "Верблюд", "Попугай", "Бегемот", "Ёж", "Осьминог", "Лев", "Черепаха"],
    en: ["Elephant", "Giraffe", "Penguin", "Crocodile", "Bear", "Dolphin", "Kangaroo", "Owl", "Wolf", "Shark", "Chameleon", "Panda", "Fox", "Camel", "Parrot", "Hippo", "Hedgehog", "Octopus", "Lion", "Turtle"],
  },
  countries: {
    ru: ["Россия", "Япония", "Бразилия", "Египет", "Италия", "Канада", "Индия", "Австралия", "Испания", "Мексика", "Норвегия", "Турция", "Китай", "Греция", "Швейцария", "Аргентина", "Куба", "Исландия", "Таиланд", "Казахстан"],
    en: ["Russia", "Japan", "Brazil", "Egypt", "Italy", "Canada", "India", "Australia", "Spain", "Mexico", "Norway", "Turkey", "China", "Greece", "Switzerland", "Argentina", "Cuba", "Iceland", "Thailand", "Kazakhstan"],
  },
  transport: {
    ru: ["Самолёт", "Метро", "Велосипед", "Трамвай", "Вертолёт", "Теплоход", "Самокат", "Такси", "Поезд", "Автобус", "Мотоцикл", "Воздушный шар", "Ракета", "Подводная лодка", "Канатная дорога", "Паром", "Грузовик", "Скейтборд", "Электричка", "Яхта"],
    en: ["Aeroplane", "Subway", "Bicycle", "Tram", "Helicopter", "Steamship", "Scooter", "Taxi", "Train", "Bus", "Motorbike", "Hot-air balloon", "Rocket", "Submarine", "Cable car", "Ferry", "Truck", "Skateboard", "Commuter train", "Yacht"],
  },
  sports: {
    ru: ["Футбол", "Хоккей", "Теннис", "Плавание", "Бокс", "Гимнастика", "Баскетбол", "Лыжи", "Шахматы", "Волейбол", "Фигурное катание", "Серфинг", "Стрельба из лука", "Бадминтон", "Регби", "Сноуборд", "Прыжки с шестом", "Гольф", "Фехтование", "Биатлон"],
    en: ["Football", "Ice hockey", "Tennis", "Swimming", "Boxing", "Gymnastics", "Basketball", "Skiing", "Chess", "Volleyball", "Figure skating", "Surfing", "Archery", "Badminton", "Rugby", "Snowboarding", "Pole vault", "Golf", "Fencing", "Biathlon"],
  },
  tech: {
    ru: ["Смартфон", "Роутер", "Клавиатура", "Монитор", "Наушники", "Принтер", "Дрон", "Видеокарта", "Флешка", "Планшет", "Умные часы", "Робот-пылесос", "Сервер", "Микрофон", "Веб-камера", "Мышка", "Колонка", "Игровая приставка", "Электронная книга", "Квадрокоптер"],
    en: ["Smartphone", "Router", "Keyboard", "Monitor", "Headphones", "Printer", "Drone", "Graphics card", "USB stick", "Tablet", "Smartwatch", "Robot vacuum", "Server", "Microphone", "Webcam", "Mouse", "Speaker", "Game console", "E-reader", "Quadcopter"],
  },
  nature: {
    ru: ["Вулкан", "Водопад", "Пустыня", "Радуга", "Гора", "Пещера", "Океан", "Лес", "Остров", "Гроза", "Ледник", "Болото", "Озеро", "Торнадо", "Северное сияние", "Саванна", "Утёс", "Река", "Туман", "Коралловый риф"],
    en: ["Volcano", "Waterfall", "Desert", "Rainbow", "Mountain", "Cave", "Ocean", "Forest", "Island", "Thunderstorm", "Glacier", "Swamp", "Lake", "Tornado", "Northern lights", "Savanna", "Cliff", "River", "Fog", "Coral reef"],
  },
  objects: {
    ru: ["Зонт", "Холодильник", "Часы", "Зеркало", "Чайник", "Ножницы", "Пылесос", "Рюкзак", "Свеча", "Ключи", "Диван", "Лампа", "Очки", "Утюг", "Телескоп", "Гитара", "Молоток", "Компас", "Весы", "Шкаф"],
    en: ["Umbrella", "Fridge", "Clock", "Mirror", "Kettle", "Scissors", "Vacuum cleaner", "Backpack", "Candle", "Keys", "Sofa", "Lamp", "Glasses", "Iron", "Telescope", "Guitar", "Hammer", "Compass", "Scales", "Wardrobe"],
  },
};

export const THEME_IDS = Object.keys(THEMES);

const labels = {
  ru: { places: "Места", food: "Еда", professions: "Профессии", animals: "Животные", countries: "Страны", transport: "Транспорт", sports: "Спорт", tech: "Техника", nature: "Природа", objects: "Предметы" },
  en: { places: "Places", food: "Food", professions: "Professions", animals: "Animals", countries: "Countries", transport: "Transport", sports: "Sports", tech: "Tech", nature: "Nature", objects: "Objects" },
};

register({
  ru: Object.fromEntries(Object.entries(labels.ru).map(([id, label]) => [`theme.${id}`, label])),
  en: Object.fromEntries(Object.entries(labels.en).map(([id, label]) => [`theme.${id}`, label])),
});

export function wordsFor(themeId) {
  const lang = getLang();
  if (themeId === "all") return THEME_IDS.flatMap((id) => THEMES[id][lang]);
  return (THEMES[themeId] || THEMES.places)[lang].slice();
}

export function parseCustomWords(text) {
  return [...new Set(text.split(/[,\n;]/).map((word) => word.trim()).filter(Boolean))];
}
