async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || "generic");
    error.code = data.error || "generic";
    throw error;
  }
  return data;
}

export const api = {
  get(id) {
    return request(`/api/games/${id}`);
  },
  list(params) {
    const query = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== "" && value !== null && value !== false && value !== undefined) {
        query.set(key, value === true ? "1" : value);
      }
    }
    return request(`/api/games?${query}`);
  },
  create(game) {
    return request("/api/games", { method: "POST", body: JSON.stringify(game) });
  },
  update(id, game) {
    return request(`/api/games/${id}`, { method: "PUT", body: JSON.stringify(game) });
  },
  patch(id, changes) {
    return request(`/api/games/${id}`, { method: "PATCH", body: JSON.stringify(changes) });
  },
  remove(id) {
    return request(`/api/games/${id}`, { method: "DELETE" });
  },
};
