function shuffled(items) {
  const copy = items.slice();
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function search(game, state, depth, alpha, beta, ai) {
  const result = game.result(state);
  if (result !== null) {
    if (result === "draw") return 0;
    return result === ai ? 10000 + depth : -10000 - depth;
  }
  if (depth === 0) return game.score(state, ai);

  const maximizing = state.turn === ai;
  let best = maximizing ? -Infinity : Infinity;
  for (const move of game.moves(state)) {
    const value = search(game, game.play(state, move), depth - 1, alpha, beta, ai);
    if (maximizing) {
      best = Math.max(best, value);
      alpha = Math.max(alpha, best);
    } else {
      best = Math.min(best, value);
      beta = Math.min(beta, best);
    }
    if (beta <= alpha) break;
  }
  return best;
}

export function bestMove(game, state, depth) {
  const ai = state.turn;
  let best = null;
  let bestValue = -Infinity;
  for (const move of shuffled(game.moves(state))) {
    const value = search(game, game.play(state, move), depth - 1, -Infinity, Infinity, ai);
    if (value > bestValue) {
      bestValue = value;
      best = move;
    }
  }
  return best;
}
