import { esc, t } from "./i18n.js";

const STORAGE_KEY = "boardgames.scoreboard";

const timer = {
  mode: "countdown",
  minutes: 5,
  seconds: 0,
  running: false,
  elapsed: 0,
  startedAt: 0,
  finished: false,
};

let players = loadPlayers();
let root = null;
let tickHandle = null;

function loadPlayers() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(saved) && saved.length) return saved;
  } catch {}
  return [{ name: "", score: 0 }, { name: "", score: 0 }];
}

function savePlayers() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(players));
  } catch {}
}

function totalMs() {
  return (timer.minutes * 60 + timer.seconds) * 1000;
}

function elapsedMs() {
  return timer.elapsed + (timer.running ? performance.now() - timer.startedAt : 0);
}

function displayMs() {
  if (timer.mode === "stopwatch") return elapsedMs();
  return Math.max(0, totalMs() - elapsedMs());
}

function formatTime(ms) {
  const totalSeconds = timer.mode === "countdown" ? Math.ceil(ms / 1000) : Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function beep() {
  try {
    const context = new (window.AudioContext || window.webkitAudioContext)();
    for (let i = 0; i < 3; i++) {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.frequency.value = 880;
      gain.gain.value = 0.15;
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(context.currentTime + i * 0.35);
      oscillator.stop(context.currentTime + i * 0.35 + 0.2);
    }
  } catch {}
}

function updateTimerDisplay() {
  const display = root && root.querySelector("#timer-display");
  if (!display) return;
  display.textContent = formatTime(displayMs());
  display.classList.toggle("finished", timer.finished);
  const note = root.querySelector("#timer-note");
  note.textContent = timer.finished ? t("tools.timeUp") : "";
  root.querySelector("#timer-toggle").textContent = timer.running ? t("tools.pause") : t("tools.start");
}

function tick() {
  if (timer.mode === "countdown" && timer.running && elapsedMs() >= totalMs()) {
    timer.elapsed = totalMs();
    timer.running = false;
    timer.finished = true;
    beep();
  }
  updateTimerDisplay();
  if (!timer.running) {
    clearInterval(tickHandle);
    tickHandle = null;
  }
}

function startTicking() {
  if (!tickHandle) tickHandle = setInterval(tick, 100);
}

function toggleTimer() {
  if (timer.running) {
    timer.elapsed = elapsedMs();
    timer.running = false;
  } else {
    if (timer.mode === "countdown" && (timer.finished || timer.elapsed >= totalMs())) resetTimer();
    if (timer.mode === "countdown" && totalMs() === 0) return;
    timer.startedAt = performance.now();
    timer.running = true;
    startTicking();
  }
  updateTimerDisplay();
}

function resetTimer() {
  timer.running = false;
  timer.elapsed = 0;
  timer.finished = false;
  updateTimerDisplay();
}

function playerLabel(player, index) {
  return player.name || t("tools.player", { n: index + 1 });
}

function playersHtml() {
  const top = Math.max(...players.map((player) => player.score));
  return players.map((player, index) => {
    const leader = top > 0 && player.score === top;
    return `
      <div class="score-row${leader ? " leader" : ""}" data-index="${index}">
        <input class="score-name" value="${esc(player.name)}" placeholder="${esc(t("tools.player", { n: index + 1 }))}" aria-label="${esc(t("tools.playerName"))}">
        <div class="score-controls">
          <button class="btn small" data-delta="-1" aria-label="-1">−1</button>
          <span class="score-value">${player.score}</span>
          <button class="btn small" data-delta="1" aria-label="+1">+1</button>
          <button class="btn small" data-delta="5" aria-label="+5">+5</button>
        </div>
        <button class="icon-btn" data-remove aria-label="${esc(t("tools.remove"))}" title="${esc(t("tools.remove"))}"${players.length <= 1 ? " disabled" : ""}>×</button>
        ${leader ? `<span class="leader-badge">${esc(t("tools.leader"))}</span>` : ""}
      </div>`;
  }).join("");
}

function renderPlayers() {
  root.querySelector("#players").innerHTML = playersHtml();
}

function timerHtml() {
  return `
    <section class="panel">
      <h2>${esc(t("tools.timer"))}</h2>
      <div class="segmented" role="tablist">
        <button class="seg${timer.mode === "countdown" ? " active" : ""}" data-mode="countdown">${esc(t("tools.countdown"))}</button>
        <button class="seg${timer.mode === "stopwatch" ? " active" : ""}" data-mode="stopwatch">${esc(t("tools.stopwatch"))}</button>
      </div>
      <div class="timer-display" id="timer-display">00:00</div>
      <p class="timer-note" id="timer-note" role="status"></p>
      <div class="timer-inputs"${timer.mode === "countdown" ? "" : " hidden"}>
        <label class="field"><span>${esc(t("tools.minutes"))}</span><input type="number" id="timer-minutes" min="0" max="999" value="${timer.minutes}"></label>
        <label class="field"><span>${esc(t("tools.seconds"))}</span><input type="number" id="timer-seconds" min="0" max="59" value="${timer.seconds}"></label>
      </div>
      <div class="dialog-actions">
        <button class="btn primary" id="timer-toggle">${esc(t("tools.start"))}</button>
        <button class="btn" id="timer-reset">${esc(t("tools.reset"))}</button>
      </div>
    </section>`;
}

function scoreboardHtml() {
  return `
    <section class="panel">
      <h2>${esc(t("tools.score"))}</h2>
      <div id="players"></div>
      <div class="dialog-actions">
        <button class="btn primary" id="add-player">+ ${esc(t("tools.addPlayer"))}</button>
        <button class="btn" id="reset-scores">${esc(t("tools.resetScores"))}</button>
      </div>
    </section>`;
}

function bindTimer() {
  root.querySelectorAll("[data-mode]").forEach((button) => {
    button.addEventListener("click", () => {
      timer.mode = button.dataset.mode;
      resetTimer();
      root.querySelectorAll("[data-mode]").forEach((item) => item.classList.toggle("active", item === button));
      root.querySelector(".timer-inputs").hidden = timer.mode !== "countdown";
    });
  });
  const readInputs = () => {
    timer.minutes = Math.max(0, Math.min(999, Number(root.querySelector("#timer-minutes").value) || 0));
    timer.seconds = Math.max(0, Math.min(59, Number(root.querySelector("#timer-seconds").value) || 0));
    if (!timer.running) resetTimer();
  };
  root.querySelector("#timer-minutes").addEventListener("input", readInputs);
  root.querySelector("#timer-seconds").addEventListener("input", readInputs);
  root.querySelector("#timer-toggle").addEventListener("click", toggleTimer);
  root.querySelector("#timer-reset").addEventListener("click", resetTimer);
  if (timer.running) startTicking();
  updateTimerDisplay();
}

function bindScoreboard() {
  const list = root.querySelector("#players");
  list.addEventListener("click", (event) => {
    const row = event.target.closest(".score-row");
    if (!row) return;
    const index = Number(row.dataset.index);
    const delta = event.target.closest("[data-delta]");
    if (delta) players[index].score += Number(delta.dataset.delta);
    else if (event.target.closest("[data-remove]") && players.length > 1) players.splice(index, 1);
    else return;
    savePlayers();
    renderPlayers();
  });
  list.addEventListener("input", (event) => {
    if (!event.target.classList.contains("score-name")) return;
    const index = Number(event.target.closest(".score-row").dataset.index);
    players[index].name = event.target.value;
    savePlayers();
  });
  root.querySelector("#add-player").addEventListener("click", () => {
    players.push({ name: "", score: 0 });
    savePlayers();
    renderPlayers();
  });
  root.querySelector("#reset-scores").addEventListener("click", () => {
    players.forEach((player) => {
      player.score = 0;
    });
    savePlayers();
    renderPlayers();
  });
  renderPlayers();
}

export function renderTools(container, embedded = false) {
  root = container;
  const heading = embedded ? "" : `<div class="page-head"><h1>${esc(t("tools.title"))}</h1></div>`;
  container.innerHTML = `
    ${heading}
    <div class="tools-grid">${timerHtml()}${scoreboardHtml()}</div>`;
  bindTimer();
  bindScoreboard();
}
