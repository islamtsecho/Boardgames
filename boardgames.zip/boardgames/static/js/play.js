import { bestMove } from "./ai.js";
import { alias } from "./games/alias.js";
import { battleship } from "./games/battleship.js";
import { checkers } from "./games/checkers.js";
import { chess } from "./games/chess.js";
import { codenames } from "./games/codenames.js";
import { connect4 } from "./games/connect4.js";
import { dominoes } from "./games/dominoes.js";
import { go } from "./games/go.js";
import { ludo } from "./games/ludo.js";
import { mafia } from "./games/mafia.js";
import { mastermind } from "./games/mastermind.js";
import { pictionary } from "./games/pictionary.js";
import { reversi } from "./games/reversi.js";
import { jenga } from "./games/jenga.js";
import { snakes } from "./games/snakes.js";
import { spy } from "./games/spy.js";
import { tictactoe } from "./games/tictactoe.js";
import { esc, getLang, register, t } from "./i18n.js";

register({
  ru: {
    "play.pickTitle": "Выберите игру",
    "play.all": "Все игры",
    "play.pass": "Пас",
    "play.section.board": "Игры для двоих: с компьютером или вдвоём",
    "play.section.party": "Игры компанией и против компьютера",
    "play.players.2": "2 игрока",
    "play.players.party": "2–12 игроков",
    "play.players.solo": "1 игрок",
    "play.players.vs": "против компьютера",
    "play.game.chess": "Шахматы",
    "play.game.go": "Го 9×9",
    "play.game.spy": "Шпион",
    "play.game.alias": "Элиас",
    "play.game.pictionary": "Рисуем и угадываем",
    "play.game.codenames": "Кодовые имена",
    "play.game.mafia": "Мафия",
    "play.game.mastermind": "Мастермайнд",
    "play.game.battleship": "Морской бой",
    "play.game.snakes": "Змеи и лестницы",
    "play.game.jenga": "Дженга",
    "play.game.ludo": "Лудо",
    "play.game.dominoes": "Домино",
    "play.hint.chess": "Выберите фигуру, затем клетку. Рокировка, взятие на проходе и превращение (в ферзя) работают.",
    "play.hint.go": "Ставьте камни на пересечения. Окружённые камни снимаются. Игра заканчивается двумя пасами подряд: побеждает тот, у кого больше территории (у белых компенсация 6,5).",
  },
  en: {
    "play.pickTitle": "Choose a game",
    "play.all": "All games",
    "play.pass": "Pass",
    "play.section.board": "Two-player games: vs the computer or head to head",
    "play.section.party": "Group games and games against the computer",
    "play.players.2": "2 players",
    "play.players.party": "2–12 players",
    "play.players.solo": "1 player",
    "play.players.vs": "vs computer",
    "play.game.chess": "Chess",
    "play.game.go": "Go 9×9",
    "play.game.spy": "Spy",
    "play.game.alias": "Alias",
    "play.game.pictionary": "Pictionary",
    "play.game.codenames": "Codenames",
    "play.game.mafia": "Mafia",
    "play.game.mastermind": "Mastermind",
    "play.game.battleship": "Battleship",
    "play.game.snakes": "Snakes and Ladders",
    "play.game.jenga": "Jenga",
    "play.game.ludo": "Ludo",
    "play.game.dominoes": "Dominoes",
    "play.hint.chess": "Select a piece, then a square. Castling, en passant and promotion (to a queen) are supported.",
    "play.hint.go": "Place stones on intersections. Surrounded stones are captured. Two passes in a row end the game: the player with more territory wins (White gets 6.5 komi).",
  },
});

const ENGINES = [tictactoe, connect4, reversi, checkers, chess, go];
const APPS = [spy, alias, codenames, mafia, pictionary, mastermind, battleship, snakes, ludo, dominoes, jenga];

const ICONS = {
  tictactoe: "✕", connect4: "●", reversi: "◐", checkers: "⛀", chess: "♞", go: "◯",
  spy: "🕵", alias: "💬", codenames: "🔎", mafia: "🌙", pictionary: "🎨", mastermind: "🎯", battleship: "🚢", snakes: "🐍", ludo: "🎲", dominoes: "🁣", jenga: "🧱",
};

const AI_DELAY = 350;
const settings = { mode: "computer", human: 1, level: 1 };

let game = null;
let state = null;
let selected = null;
let busy = false;
let root = null;
let session = 0;
let disposeApp = null;

function select(name, value, options) {
  const items = options.map(([optionValue, label]) => (
    `<option value="${optionValue}"${String(optionValue) === String(value) ? " selected" : ""}>${esc(label)}</option>`
  ));
  return `<select name="${name}">${items.join("")}</select>`;
}

function pickerHtml() {
  const card = (id, note) => `
    <a class="pick-card" href="#/play/${id}">
      <span class="pick-icon" aria-hidden="true">${ICONS[id]}</span>
      <strong>${esc(t("play.game." + id))}</strong>
      <small>${esc(note)}</small>
    </a>`;
  const engines = ENGINES.map((item) => card(item.id, `${t("play.players.2")} · ${t("play.players.vs")}`)).join("");
  const apps = APPS.map((item) => card(item.id, appNote(item.id))).join("");
  return `
    <div class="page-head"><h1>${esc(t("play.pickTitle"))}</h1></div>
    <h3 class="section-title">${esc(t("play.section.board"))}</h3>
    <div class="pick-grid">${engines}</div>
    <h3 class="section-title">${esc(t("play.section.party"))}</h3>
    <div class="pick-grid">${apps}</div>`;
}

function appNote(id) {
  const notes = {
    spy: "3–12", alias: "4–12", codenames: "4–10", mafia: "5–16", pictionary: "4–12",
    mastermind: t("play.players.solo"), battleship: `${t("play.players.solo")} · ${t("play.players.vs")}`,
    snakes: "2–6", jenga: "2–6", ludo: "2–4", dominoes: `${t("play.players.2")} · ${t("play.players.vs")}`,
  };
  return notes[id];
}

function controlsHtml() {
  const isComputer = settings.mode === "computer";
  const mode = select("mode", settings.mode, [["computer", t("play.computer")], ["friend", t("play.friend")]]);
  const side = select("human", settings.human, [[1, t("play.first")], [2, t("play.second")]]);
  const level = select("level", settings.level, [0, 1, 2].map((n) => [n, t("play.level." + n)]));
  return `
    <form class="play-controls" id="play-controls">
      <label class="field"><span>${esc(t("play.mode"))}</span>${mode}</label>
      <label class="field"${isComputer ? "" : " hidden"}><span>${esc(t("play.side"))}</span>${side}</label>
      <label class="field"${isComputer ? "" : " hidden"}><span>${esc(t("play.level"))}</span>${level}</label>
      <button class="btn primary" type="button" id="new-game">${esc(t("play.new"))}</button>
    </form>`;
}

function isHumanTurn() {
  return settings.mode === "friend" || state.turn === settings.human;
}

function playerName(player) {
  return game.names[getLang()][player - 1];
}

function statusText(outcome) {
  if (outcome === "draw") return t("play.draw");
  if (outcome) return t("play.wins", { name: playerName(outcome) });
  if (busy) return t("play.thinking");
  return t("play.turn", { name: playerName(state.turn) });
}

function scoreboardHtml(outcome) {
  const stats = game.stats(state);
  return [1, 2].map((player) => {
    const active = !outcome && state.turn === player;
    const value = stats ? `<strong>${stats[player - 1]}</strong>` : "";
    return `<div class="player${active ? " active" : ""}"><span class="swatch swatch-${game.id}-${player}"></span>${esc(playerName(player))}${value}</div>`;
  }).join("");
}

function refresh() {
  const outcome = game.result(state);
  const interactive = !outcome && !busy && isHumanTurn();
  root.querySelector("#board-holder").innerHTML = game.render(state, { selected, interactive });
  root.querySelector("#scoreboard").innerHTML = scoreboardHtml(outcome);
  const status = root.querySelector("#status");
  status.textContent = statusText(outcome);
  status.classList.toggle("finished", Boolean(outcome));
  const info = root.querySelector("#info");
  info.textContent = !outcome && game.info && isHumanTurn() ? game.info(state, selected) : "";
  const buttons = root.querySelector("#extra-buttons");
  if (buttons) buttons.querySelectorAll("button").forEach((button) => {
    button.disabled = !interactive;
  });
}

function applyMove(move) {
  state = game.play(state, move);
  selected = null;
  refresh();
  scheduleComputer();
}

function scheduleComputer() {
  if (settings.mode !== "computer" || game.result(state) || state.turn === settings.human) return;
  busy = true;
  refresh();
  const current = session;
  setTimeout(() => {
    if (current !== session || !root.querySelector("#board-holder")) return;
    const level = settings.level;
    const move = game.ai ? game.ai(state, level) : bestMove(game, state, game.depths[level]);
    busy = false;
    applyMove(move);
  }, AI_DELAY);
}

function startGame() {
  session++;
  busy = false;
  selected = null;
  state = game.init();
  refresh();
  scheduleComputer();
}

function onBoardClick(event) {
  const target = event.target.closest("[data-cell], [data-extra]");
  if (!target || busy || game.result(state) || !isHumanTurn()) return;
  const cell = target.dataset.extra !== undefined ? target.dataset.extra : Number(target.dataset.cell);
  const action = game.click(state, cell, selected);
  if (!action) return;
  if (action.move !== undefined) {
    applyMove(action.move);
  } else {
    selected = action.selected;
    refresh();
  }
}

function backLink() {
  return `<a class="btn small" href="#/play">← ${esc(t("play.all"))}</a>`;
}

function renderEngine() {
  const extra = (game.buttons || [])
    .map((button) => `<button class="btn" data-extra="${button.id}">${esc(t(button.label))}</button>`)
    .join("");
  root.innerHTML = `
    <div class="page-head"><h1>${esc(t("play.game." + game.id))}</h1>${backLink()}</div>
    ${controlsHtml()}
    <div class="play-area">
      <div class="play-side">
        <div class="status" id="status" role="status"></div>
        <div class="scoreboard" id="scoreboard"></div>
        <p class="hint">${esc(t("play.hint." + game.id))}</p>
        <p class="info" id="info"></p>
        <div class="side-buttons" id="extra-buttons">${extra}</div>
      </div>
      <div class="board-holder" id="board-holder"></div>
    </div>`;

  const form = root.querySelector("#play-controls");
  form.addEventListener("change", () => {
    const data = new FormData(form);
    settings.mode = data.get("mode");
    settings.human = Number(data.get("human"));
    settings.level = Number(data.get("level"));
    renderEngine();
  });
  root.querySelector("#new-game").addEventListener("click", startGame);
  root.querySelector("#board-holder").addEventListener("click", onBoardClick);
  root.querySelector("#extra-buttons").addEventListener("click", onBoardClick);
  startGame();
}

function renderApp(app) {
  root.innerHTML = `
    <div class="page-head"><h1>${esc(t("play.game." + app.id))}</h1>${backLink()}</div>
    <div class="app-host" id="app-host"></div>`;
  disposeApp = app.mount(root.querySelector("#app-host"));
}

export function leavePlay() {
  session++;
  if (disposeApp) disposeApp();
  disposeApp = null;
}

export function renderPlay(container, gameId) {
  leavePlay();
  root = container;
  const engine = ENGINES.find((item) => item.id === gameId);
  const app = APPS.find((item) => item.id === gameId);
  if (engine) {
    game = engine;
    renderEngine();
  } else if (app) {
    renderApp(app);
  } else {
    container.innerHTML = pickerHtml();
  }
}
