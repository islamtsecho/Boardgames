export function shuffle(items) {
  const copy = items.slice();
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function randInt(limit) {
  return Math.floor(Math.random() * limit);
}

export function pickRandom(items) {
  return items[randInt(items.length)];
}

export function formatClock(totalSeconds) {
  const seconds = Math.max(0, Math.ceil(totalSeconds));
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(seconds / 60))}:${pad(seconds % 60)}`;
}

let audio = null;

export function beep(times = 3) {
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    for (let i = 0; i < times; i++) {
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.frequency.value = 880;
      gain.gain.value = 0.15;
      oscillator.connect(gain);
      gain.connect(audio.destination);
      oscillator.start(audio.currentTime + i * 0.35);
      oscillator.stop(audio.currentTime + i * 0.35 + 0.2);
    }
  } catch {}
}

export function createCountdown(seconds, onTick, onDone) {
  let remaining = seconds * 1000;
  let endAt = 0;
  let handle = null;

  function tick() {
    const left = Math.max(0, endAt - Date.now());
    onTick(Math.ceil(left / 1000));
    if (left <= 0) {
      stop();
      remaining = 0;
      onDone();
    }
  }

  function start() {
    if (handle || remaining <= 0) return;
    endAt = Date.now() + remaining;
    handle = setInterval(tick, 200);
  }

  function stop() {
    if (!handle) return;
    remaining = Math.max(0, endAt - Date.now());
    clearInterval(handle);
    handle = null;
  }

  function reset(value = seconds) {
    stop();
    remaining = value * 1000;
    onTick(Math.ceil(remaining / 1000));
  }

  return { start, stop, reset, isRunning: () => handle !== null };
}
