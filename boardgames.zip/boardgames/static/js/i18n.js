const STRINGS = {
  ru: {
    "app.title": "Настольные игры",
    "nav.catalog": "Каталог",
    "nav.play": "Играть",
    "nav.tools": "Инструменты",
    "theme.toggle": "Сменить тему",
    "lang.toggle": "Switch to English",
    "a11y.skip": "Skip to content",

    "genre.abstract": "Абстрактные",
    "genre.strategy": "Стратегии",
    "genre.family": "Семейные",
    "genre.party": "Вечеринка",
    "genre.cooperative": "Кооперативные",
    "genre.economic": "Экономические",
    "genre.detective": "Детективы",
    "genre.word": "Словесные",

    "catalog.title": "Каталог игр",
    "catalog.search": "Поиск по названию и описанию",
    "catalog.allGenres": "Все жанры",
    "catalog.players": "Игроков",
    "catalog.anyPlayers": "Игроков: любое число",
    "catalog.players.n": "{n} игр.",
    "catalog.anyTime": "Любая длительность",
    "catalog.time.n": "до {n} мин",
    "catalog.favorites": "Только избранное",
    "catalog.playable": "Можно сыграть здесь",
    "catalog.sort.name": "По названию",
    "catalog.sort.rating": "По моей оценке",
    "catalog.sort.time": "По длительности",
    "catalog.sort.players": "По числу игроков",
    "catalog.add": "Добавить игру",
    "catalog.found": "Найдено: {n}",
    "catalog.empty": "Ничего не найдено. Попробуйте изменить фильтры.",
    "catalog.reset": "Сбросить фильтры",

    "card.players": "{min}–{max} игр.",
    "card.playersSame": "{n} игр.",
    "card.time": "{n} мин",
    "card.age": "{n}+",
    "card.play": "Играть",
    "card.helper": "Помощник",
    "card.favorite": "В избранное",
    "card.unfavorite": "Убрать из избранного",
    "card.rate": "Оценить на {n}",

    "detail.description": "Описание",
    "detail.rules": "Краткие правила",
    "detail.edit": "Изменить",
    "detail.delete": "Удалить",
    "detail.close": "Закрыть",
    "detail.confirmDelete": "Удалить игру «{name}»?",

    "form.addTitle": "Новая игра",
    "form.editTitle": "Редактирование игры",
    "form.nameRu": "Название (русский)",
    "form.nameEn": "Название (English)",
    "form.descRu": "Описание (русский)",
    "form.descEn": "Описание (English)",
    "form.rulesRu": "Правила (русский)",
    "form.rulesEn": "Правила (English)",
    "form.genre": "Жанр",
    "form.playersMin": "Игроков от",
    "form.playersMax": "Игроков до",
    "form.time": "Время партии, мин",
    "form.age": "Возраст от",
    "form.save": "Сохранить",
    "form.cancel": "Отмена",

    "error.name_required": "Укажите название хотя бы на одном языке.",
    "error.invalid_players": "Минимум игроков не может быть больше максимума.",
    "error.generic": "Не удалось выполнить действие. Проверьте, что сервер запущен.",

    "play.title": "Играть",
    "play.pick": "Выберите игру",
    "play.mode": "Режим",
    "play.friend": "Вдвоём за одним экраном",
    "play.computer": "Против компьютера",
    "play.side": "Ваша сторона",
    "play.first": "Хожу первым",
    "play.second": "Хожу вторым",
    "play.level": "Сложность",
    "play.level.0": "Лёгкая",
    "play.level.1": "Средняя",
    "play.level.2": "Сложная",
    "play.new": "Новая партия",
    "play.turn": "Ход: {name}",
    "play.thinking": "Компьютер думает…",
    "play.wins": "Победа: {name}",
    "play.draw": "Ничья",
    "play.game.tictactoe": "Крестики-нолики",
    "play.game.connect4": "Четыре в ряд",
    "play.game.reversi": "Реверси",
    "play.game.checkers": "Шашки",
    "play.hint.checkers": "Выберите шашку, затем клетку, куда пойти. Бить обязательно.",
    "play.hint.reversi": "Точки показывают допустимые ходы.",
    "play.hint.connect4": "Нажмите на любую клетку колонки, чтобы бросить фишку.",
    "play.hint.tictactoe": "Первым выстройте три знака в ряд.",

    "tools.title": "Инструменты для партии",
    "tools.timer": "Таймер",
    "tools.countdown": "Обратный отсчёт",
    "tools.stopwatch": "Секундомер",
    "tools.minutes": "Минуты",
    "tools.seconds": "Секунды",
    "tools.start": "Старт",
    "tools.pause": "Пауза",
    "tools.reset": "Сброс",
    "tools.timeUp": "Время вышло!",
    "tools.score": "Счёт",
    "tools.addPlayer": "Добавить игрока",
    "tools.player": "Игрок {n}",
    "tools.playerName": "Имя игрока",
    "tools.remove": "Убрать игрока",
    "tools.resetScores": "Обнулить счёт",
    "tools.leader": "Лидирует",
  },

  en: {
    "app.title": "Board Games",
    "nav.catalog": "Catalogue",
    "nav.play": "Play",
    "nav.tools": "Tools",
    "theme.toggle": "Toggle theme",
    "lang.toggle": "Переключить на русский",
    "a11y.skip": "К содержимому",

    "genre.abstract": "Abstract",
    "genre.strategy": "Strategy",
    "genre.family": "Family",
    "genre.party": "Party",
    "genre.cooperative": "Cooperative",
    "genre.economic": "Economic",
    "genre.detective": "Detective",
    "genre.word": "Word",

    "catalog.title": "Game catalogue",
    "catalog.search": "Search by name and description",
    "catalog.allGenres": "All genres",
    "catalog.players": "Players",
    "catalog.anyPlayers": "Players: any",
    "catalog.players.n": "{n} players",
    "catalog.anyTime": "Any length",
    "catalog.time.n": "up to {n} min",
    "catalog.favorites": "Favourites only",
    "catalog.playable": "Playable here",
    "catalog.sort.name": "By name",
    "catalog.sort.rating": "By my rating",
    "catalog.sort.time": "By length",
    "catalog.sort.players": "By player count",
    "catalog.add": "Add game",
    "catalog.found": "Found: {n}",
    "catalog.empty": "Nothing found. Try changing the filters.",
    "catalog.reset": "Reset filters",

    "card.players": "{min}–{max} players",
    "card.playersSame": "{n} players",
    "card.time": "{n} min",
    "card.age": "{n}+",
    "card.play": "Play",
    "card.helper": "Assistant",
    "card.favorite": "Add to favourites",
    "card.unfavorite": "Remove from favourites",
    "card.rate": "Rate {n}",

    "detail.description": "Description",
    "detail.rules": "Quick rules",
    "detail.edit": "Edit",
    "detail.delete": "Delete",
    "detail.close": "Close",
    "detail.confirmDelete": "Delete the game \"{name}\"?",

    "form.addTitle": "New game",
    "form.editTitle": "Edit game",
    "form.nameRu": "Name (Russian)",
    "form.nameEn": "Name (English)",
    "form.descRu": "Description (Russian)",
    "form.descEn": "Description (English)",
    "form.rulesRu": "Rules (Russian)",
    "form.rulesEn": "Rules (English)",
    "form.genre": "Genre",
    "form.playersMin": "Players from",
    "form.playersMax": "Players up to",
    "form.time": "Play time, min",
    "form.age": "Age from",
    "form.save": "Save",
    "form.cancel": "Cancel",

    "error.name_required": "Enter a name in at least one language.",
    "error.invalid_players": "Minimum players cannot exceed the maximum.",
    "error.generic": "The action failed. Make sure the server is running.",

    "play.title": "Play",
    "play.pick": "Choose a game",
    "play.mode": "Mode",
    "play.friend": "Two players, one screen",
    "play.computer": "Against the computer",
    "play.side": "Your side",
    "play.first": "I move first",
    "play.second": "I move second",
    "play.level": "Difficulty",
    "play.level.0": "Easy",
    "play.level.1": "Medium",
    "play.level.2": "Hard",
    "play.new": "New game",
    "play.turn": "Turn: {name}",
    "play.thinking": "Computer is thinking…",
    "play.wins": "Winner: {name}",
    "play.draw": "Draw",
    "play.game.tictactoe": "Tic-Tac-Toe",
    "play.game.connect4": "Connect Four",
    "play.game.reversi": "Reversi",
    "play.game.checkers": "Checkers",
    "play.hint.checkers": "Select a piece, then a square to move to. Captures are mandatory.",
    "play.hint.reversi": "Dots mark legal moves.",
    "play.hint.connect4": "Click any cell of a column to drop a disc.",
    "play.hint.tictactoe": "Be the first to line up three marks.",

    "tools.title": "Game-night tools",
    "tools.timer": "Timer",
    "tools.countdown": "Countdown",
    "tools.stopwatch": "Stopwatch",
    "tools.minutes": "Minutes",
    "tools.seconds": "Seconds",
    "tools.start": "Start",
    "tools.pause": "Pause",
    "tools.reset": "Reset",
    "tools.timeUp": "Time is up!",
    "tools.score": "Scoreboard",
    "tools.addPlayer": "Add player",
    "tools.player": "Player {n}",
    "tools.playerName": "Player name",
    "tools.remove": "Remove player",
    "tools.resetScores": "Reset scores",
    "tools.leader": "Leading",
  },
};

function detectLang() {
  try {
    const saved = localStorage.getItem("lang");
    if (saved === "ru" || saved === "en") return saved;
  } catch {}
  return (navigator.language || "ru").startsWith("en") ? "en" : "ru";
}

let lang = detectLang();

export function register(strings) {
  Object.assign(STRINGS.ru, strings.ru);
  Object.assign(STRINGS.en, strings.en);
}

export function getLang() {
  return lang;
}

export function setLang(value) {
  lang = value;
  try {
    localStorage.setItem("lang", value);
  } catch {}
  if (typeof document !== "undefined") document.documentElement.lang = value;
}

export function t(key, params = {}) {
  const template = STRINGS[lang][key] ?? STRINGS.ru[key] ?? key;
  return template.replace(/\{(\w+)\}/g, (_, name) => params[name] ?? "");
}

export function pick(game, field) {
  const other = lang === "ru" ? "en" : "ru";
  return game[`${field}_${lang}`] || game[`${field}_${other}`] || "";
}

export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]
  ));
}

if (typeof document !== "undefined") document.documentElement.lang = lang;
